"""Version 2 horizon pilot: explicit SciPy demand stream and verified PPO diagnostics."""
from pathlib import Path
import argparse,json,time,hashlib
import torch,cloudpickle
import horizon_supply as h
from scale_control import vector
from instrumented_ppo import InstrumentedPPO,RolloutDiagnostics
ARMS={'null':'linear','curvature':'B','lambda7':'A'}
class InstrumentedHorizon(InstrumentedPPO):
 def train(self):
  super().train()
  for checkpoint in self.protocol['checkpoints']:
   if checkpoint<=self.num_timesteps and checkpoint not in self.completed:
    self.completed.append(checkpoint);out=Path(self.output)
    if self.protocol.get('evaluate',True):
     report=h.evaluate(self,self.protocol,10)
     if checkpoint in [900000,1800000,3600000]:report['sensitivity_50']=h.evaluate(self,self.protocol,50)
     report.update(requested_checkpoint=checkpoint,actual_agent_transitions=self.num_timesteps,joint_ticks=self.num_timesteps//5,elapsed_seconds=time.monotonic()-self.started)
     (out/f'evaluation_{checkpoint}.json').write_text(json.dumps(report,indent=2))
    h.HorizonPPO.checkpoint(self,out/f'checkpoint_{checkpoint}')
  if getattr(self,'stop_after',0) and self.num_timesteps>=self.stop_after:raise h.StageComplete()

def create(cfg,out):
 torch.set_num_threads(1);out=Path(out);out.mkdir(parents=True,exist_ok=False)
 m=InstrumentedHorizon('MlpPolicy',vector(cfg['w'],ARMS[cfg['condition']],cfg['seed']),n_steps=128,batch_size=256,seed=cfg['seed'],verbose=0,device='cpu')
 m.verify_upstream();m.protocol=cfg;m.output=str(out);m.completed=[];m.started=time.monotonic();m.diagnostics_dir=str(out/'diagnostics');return m

def resume(path,out):
 torch.set_num_threads(1);path=Path(path);out=Path(out);out.mkdir(parents=True,exist_ok=False)
 with (path/'environment.pkl').open('rb') as f:env=cloudpickle.load(f)
 m=InstrumentedHorizon.load(path/'model.zip',env=env,device='cpu',force_reset=False)
 with (path/'rng.pkl').open('rb') as f:state=cloudpickle.load(f)
 h.restore_rng(state);m.verify_upstream();m.output=str(out);m.diagnostics_dir=str(out/'diagnostics');m.started=time.monotonic();return m

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--index',type=int);p.add_argument('--resume');p.add_argument('--stop-after',type=int,default=900000);p.add_argument('--smoke',action='store_true');a=p.parse_args();out=Path(a.out)
 if a.smoke:
  cfg=dict(w=.6,condition='curvature',seed=103,checkpoints=[640,1280],total_budget=1280,phase='smoke',evaluate=True)
  m=create(cfg,out/'continuous');m.learn(total_timesteps=1280,callback=RolloutDiagnostics());expected={k:v.detach().clone() for k,v in m.policy.state_dict().items()}
  r=resume(out/'continuous/checkpoint_640',out/'resumed');r.learn(total_timesteps=1280-r.num_timesteps,reset_num_timesteps=False,callback=RolloutDiagnostics())
  assert all(torch.equal(v,r.policy.state_dict()[k]) for k,v in expected.items())
  cfg=dict(w=.6,condition='null',seed=103,checkpoints=[],total_budget=20000,phase='timing',evaluate=False);t=create(cfg,out/'timing');start=time.monotonic();t.learn(total_timesteps=20000,callback=RolloutDiagnostics());elapsed=time.monotonic()-start
  (out/'test_result.json').write_text(json.dumps(dict(instrumented_resume_exact=True,transitions=t.num_timesteps,seconds=elapsed,transitions_per_second=t.num_timesteps/elapsed,diagnostic_overhead_included=True,evaluation_checkpoint_overhead_excluded=True),indent=2));print('PASS resume and timing',flush=True);return
 if a.resume:m=resume(a.resume,out)
 else:
  assert a.index is not None and 0<=a.index<105
  from scale_control import WS
  cfg=dict(w=WS[a.index//15],condition=['null','curvature','lambda7'][(a.index%15)//5],seed=100+a.index%5,checkpoints=list(range(150000,3600001,150000)),total_budget=3600000,phase='pilot',evaluate=True,version='explicit-demand-v2')
  m=create(cfg,out)
 m.stop_after=a.stop_after
 (out/'protocol.json').write_text(json.dumps(m.protocol,indent=2));manifest=h.manifest();manifest['v2_sources']={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in ['horizon_instrumented.py','scale_control.py','instrumented_ppo.py','reward_diagnostics.py']};(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
 try:m.learn(total_timesteps=m.protocol['total_budget']-m.num_timesteps,reset_num_timesteps=not bool(a.resume),callback=RolloutDiagnostics())
 except h.StageComplete:print('STAGED',m.num_timesteps,flush=True);return
 print('COMPLETE',m.num_timesteps,flush=True)
if __name__=='__main__':main()
