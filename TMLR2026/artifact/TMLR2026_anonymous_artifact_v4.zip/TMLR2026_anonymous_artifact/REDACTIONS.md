# Redactions for double-blind review

Identifying strings (institution, cluster node, user name, local paths) were replaced in the files below after the
experiments ran. Three of them are covered by the pre-launch hash record `TMLR2026/v4_prereg/HASHES.sha256`; their
original SHA-256 (which matches that record) and the redacted SHA-256 are both listed. No other byte was changed.

## `TMLR2026/v4_prereg/PHASE0_REPORT.md`
- original sha256: `790dd8ad9f88456336d7c651cda76db947d47c19fcb4bbde8ddc8054776e77d1`
- redacted sha256: `5f36885b71d10e96ff0360cd387986932a6750fc1eea9702a9f31b246b07b900`
- substitutions: [cluster working-directory path] -> `<workdir>` (1x); [environment path] -> `<env>` (1x); [local repository path] -> `<repo>` (1x); [institution name] -> `[cluster]` (11x)

## `TMLR2026/v4_prereg/PREREGISTRATION_v4.md` (in HASHES.sha256)
- original sha256: `38f87bef624143415d44c416be66f5e360707695b4a31de04a426efbd0baa276`
- redacted sha256: `e0a03636b9b1055ecb8ff6bd92fd498cac3e92391262f50f5f9a58aee025333e`
- substitutions: [cluster node name] -> `<node>` (1x); [institution name] -> `[cluster]` (1x)

## `TMLR2026/v4_prereg/DEVIATIONS.md` (in HASHES.sha256)
- original sha256: `fa990dd33b3bfc1ae0937170df64cee5882bfa0600ed967a76c255be3bbced5f`
- redacted sha256: `e1f164982da118dcbd1b012a8f23498f2900a54d3a512d536e98c6e15895c7dd`
- substitutions: [institution name] -> `[cluster]` (1x)

## `v4/executed_source/orchestration_v4_e3/design.json` (in HASHES.sha256)
- original sha256: `11d3526922c5404c5c58eae27e8663fe89a8f94289f881e634cfcc9d74d14dff`
- redacted sha256: `4a2114e18c8b59fd6c136a7f61311a9e7191f018832e24a8a13990b692352f62`
- substitutions: [institution name] -> `[cluster]` (1x)

## `v4/extraction/extract.py`
- original sha256: `5e6eddc2f386c99fc9f367079cf7613d6a190296f470953330d24811201be69c`
- redacted sha256: `087ae09250ac0fe4cd9c549256dd032a8547f574a7c445d224013a54471cecf1`
- substitutions: [cluster working-directory path] -> `<workdir>` (1x); [institution name] -> `[cluster]` (1x)

