# Redactions for double-blind review

Identifying strings (institution, cluster node, user name, local paths) were replaced in the files below after the
experiments ran. For each file the original and redacted SHA-256 are listed, together with whether the original
matches the pre-launch record in `TMLR2026/v4_prereg/HASHES.sha256`. `DEVIATIONS.md` is an append-only log, so
entries added after a freeze change its hash; its frozen hash covers the text up to that freeze. Only the listed
substitutions were made.

## `TMLR2026/v4_prereg/PHASE0_REPORT.md`
- original sha256: `790dd8ad9f88456336d7c651cda76db947d47c19fcb4bbde8ddc8054776e77d1` (not in the frozen record)
- redacted sha256: `5f36885b71d10e96ff0360cd387986932a6750fc1eea9702a9f31b246b07b900`
- substitutions: [cluster working-directory path] -> `<workdir>` (1x); [environment path] -> `<env>` (1x); [local repository path] -> `<repo>` (1x); [institution name] -> `[cluster]` (11x)

## `TMLR2026/v4_prereg/PREREGISTRATION_v4.md`
- original sha256: `38f87bef624143415d44c416be66f5e360707695b4a31de04a426efbd0baa276` (matches the frozen record)
- redacted sha256: `e0a03636b9b1055ecb8ff6bd92fd498cac3e92391262f50f5f9a58aee025333e`
- substitutions: [cluster node name] -> `<node>` (1x); [institution name] -> `[cluster]` (1x)

## `TMLR2026/v4_prereg/DEVIATIONS.md`
- original sha256: `7901878aa6257cdb11d178420ce4b3e8df7b198527b4650bcdd40f8150217cc7` (the frozen record `fa990dd33b3bfc1a…` equals the SHA-256 of this file's first 966 bytes, i.e. of the text before the later appended entries; verified)
- redacted sha256: `14758e706331f59aa46baead2e7270e25add09d28da3b86577af5519b04004e6`
- substitutions: [institution name] -> `[cluster]` (1x)

## `v4/executed_source/orchestration_v4_e3/design.json`
- original sha256: `11d3526922c5404c5c58eae27e8663fe89a8f94289f881e634cfcc9d74d14dff` (matches the frozen record)
- redacted sha256: `4a2114e18c8b59fd6c136a7f61311a9e7191f018832e24a8a13990b692352f62`
- substitutions: [institution name] -> `[cluster]` (1x)

## `v4/extraction/extract.py`
- original sha256: `5e6eddc2f386c99fc9f367079cf7613d6a190296f470953330d24811201be69c` (not in the frozen record)
- redacted sha256: `087ae09250ac0fe4cd9c549256dd032a8547f574a7c445d224013a54471cecf1`
- substitutions: [cluster working-directory path] -> `<workdir>` (1x); [institution name] -> `[cluster]` (1x)

