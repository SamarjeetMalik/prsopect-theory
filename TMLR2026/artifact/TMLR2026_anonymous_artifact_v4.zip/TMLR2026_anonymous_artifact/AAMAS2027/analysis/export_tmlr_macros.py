"""Export every quantitative abstract value from checked analysis records."""

from pathlib import Path
import json
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
AAMAS = ROOT / "AAMAS2027"
OUT = ROOT / "TMLR2026" / "generated" / "tmlr_numbers.tex"

fits = pd.read_csv(AAMAS / "generated" / "boundary_estimates.csv")
contrasts = pd.read_csv(AAMAS / "generated" / "endpoint_differences.csv")
design = json.loads((AAMAS / "orchestration_deadline_v1" / "design.json").read_text())

primary = fits[(fits.setting == "supply_horizon") & (fits.budget == 300_000)].iloc[0]
shift = contrasts[
    (contrasts.setting == "supply_ppo")
    & contrasts.low.eq("lambda1")
    & contrasts.high.eq("lambda7")
    & contrasts.pairing.eq("paired")
].iloc[0]
max_budget = max(design["checkpoints"])

lines = [
    rf"\newcommand{{\AbstractCrossing}}{{${primary.wcrit:.3f}$ $[{primary.ci_low:.3f},{primary.ci_high:.3f}]$}}",
    r"\newcommand{\AbstractCrossingProbability}{50\%}",
    r"\newcommand{\PrimaryBudget}{300k}",
    rf"\newcommand{{\LossMultiplierShift}}{{${shift.difference:+.3f}$ $[{shift.ci_low:+.3f},{shift.ci_high:+.3f}]$}}",
    rf"\newcommand{{\MaxConfirmationBudget}}{{{max_budget / 1_000_000:g}M}}",
]
OUT.write_text("\n".join(lines) + "\n")
print(OUT)
