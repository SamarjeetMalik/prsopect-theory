"""Analyze only genuine longitudinal new-run evaluations, never legacy CSVs."""
from pathlib import Path
import argparse,json,sys
import numpy as np,pandas as pd
from boundary import firth

def wilson(k,n):
 if not n:return (None,None)
 z=1.959963984540054;p=k/n;den=1+z*z/n
 center=(p+z*z/(2*n))/den;half=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
 return max(0.,center-half),min(1.,center+half)

def read_runs(root):
 rows=[];seen=set()
 roots=root if isinstance(root,(list,tuple)) else [root]
 paths=[p for base in roots for p in Path(base).rglob('evaluation_*.json')]
 for p in paths:
  protocol=p.parent/'protocol.json'
  if not protocol.exists():continue
  cfg=json.loads(protocol.read_text());record=json.loads(p.read_text())
  if cfg.get('version') not in [None,'explicit-demand-v2']:raise ValueError(f'Unsupported source version: {p}')
  key=(cfg['phase'],cfg['condition'],cfg['w'],cfg['seed'],record['requested_checkpoint'])
  if key in seen:raise ValueError(f'Duplicate longitudinal checkpoint: {key}')
  seen.add(key)
  rows.append(dict(condition=cfg['condition'],w=cfg['w'],seed=cfg['seed'],phase=cfg['phase'],requested=record['requested_checkpoint'],actual=record['actual_agent_transitions'],**record['summary']))
 return pd.DataFrame(rows)
def analyze(root,out,grid=(0.,.4,.5,.6,.7,.85,1.),confirmation_seeds=tuple(range(42,62))):
 d=read_runs(root);out=Path(out);out.mkdir(parents=True,exist_ok=True)
 if d.empty:
  (out/'status.json').write_text(json.dumps({'status':'no longitudinal evaluations available; no recovery/stability result inferred'}));return
 d.to_csv(out/'checkpoint_metrics.csv',index=False);sequences=[];events=[]
 sensitivity=[]
 for base in (root if isinstance(root,(list,tuple)) else [root]):
  for path in Path(base).rglob('evaluation_*.json'):
   r=json.loads(path.read_text());cfg=json.loads((path.parent/'protocol.json').read_text())
   if 'sensitivity_50' not in r:continue
   sensitivity.append(dict(phase=cfg['phase'],condition=cfg['condition'],w=cfg['w'],seed=cfg['seed'],requested=r['requested_checkpoint'],collapsed_10=r['summary']['collapsed'],collapsed_50=r['sensitivity_50']['summary']['collapsed'],label_changed=r['summary']['collapsed']!=r['sensitivity_50']['summary']['collapsed'],profit_10=r['summary']['profit'],profit_50=r['sensitivity_50']['summary']['profit']))
 pd.DataFrame(sensitivity).to_csv(out/'evaluation_sensitivity.csv',index=False)
 for key,g in d.groupby(['phase','condition','w','seed']):
  g=g.sort_values('requested');base=g[g.requested==300000]
  if len(base)!=1:continue
  initial=bool(base.collapsed.iloc[0]);streak=0;previous=None;first=None
  for r in g[g.requested>300000].itertuples():
   contiguous=previous is None or r.requested-previous==150000
   streak=(streak+1 if contiguous else 1) if not r.collapsed else 0
   if streak==3 and first is None:first=r.requested
   events.append(dict(phase=key[0],condition=key[1],w=key[2],seed=key[3],requested=r.requested,initial_collapsed=initial,collapsed=bool(r.collapsed),recovered=initial and not r.collapsed,relapsed=not initial and bool(r.collapsed)))
   previous=r.requested
  sequences.append(dict(phase=key[0],condition=key[1],w=key[2],seed=key[3],initial_collapsed=initial,first_three_checkpoint_recovery=first if initial else None,sequence=json.dumps(list(zip(g.requested.astype(int),g.collapsed.astype(bool))))))
 pd.DataFrame(sequences).to_csv(out/'recovery_sequences.csv',index=False)
 e=pd.DataFrame(events);e.to_csv(out/'recovery_events.csv',index=False)
 summaries=[]
 if not e.empty:
  for key,g in e.groupby(['phase','condition','w','requested']):
   nc=int(g.initial_collapsed.sum());nn=len(g)-nc
   recovery_ci=wilson(int(g.recovered.sum()),nc);relapse_ci=wilson(int(g.relapsed.sum()),nn)
   summaries.append(dict(zip(['phase','condition','w','requested'],key),collapsed_at_300k=nc,noncollapsed_at_300k=nn,recovery_ci_low=recovery_ci[0],recovery_ci_high=recovery_ci[1],relapse_ci_low=relapse_ci[0],relapse_ci_high=relapse_ci[1],interval='Wilson 95%; conditional on observed baseline group; per cell',recovery_fraction=float(g.recovered.sum()/nc) if nc else None,relapse_fraction=float(g.relapsed.sum()/nn) if nn else None))
 pd.DataFrame(summaries).to_csv(out/'recovery_rates.csv',index=False)
 # Use only confirmation for claims; pilots remain descriptive, separate.
 boundaries=[];saved={};points={};incomplete=[];rng=np.random.default_rng(20260926)
 for phase,pd_ in d.groupby('phase'):
  seeds=list(confirmation_seeds) if phase=='confirmation' else list(range(100,105));weights=rng.multinomial(len(seeds),np.ones(len(seeds))/len(seeds),size=2000)
  for (condition,t),g in pd_.groupby(['condition','requested']):
   actual=set(zip(g.w,g.seed));expected={(w,s) for w in grid for s in seeds}
   if actual!=expected:
    incomplete.append(dict(phase=phase,condition=condition,requested=int(t),missing=sorted(expected-actual),unexpected=sorted(actual-expected)));continue
   w=np.sort(g.w.unique())
   if len(w)<2:continue
   n=np.zeros((len(seeds),len(w)));k=n.copy()
   for r in g.itertuples():i=seeds.index(r.seed);j=np.searchsorted(w,r.w);n[i,j]+=1;k[i,j]+=int(r.collapsed)
   f=firth(w,k.sum(0),n.sum(0));b=firth(w,weights@k,weights@n);good=np.isfinite(b['wcrit']);ci=np.percentile(b['wcrit'][good],[2.5,97.5]) if good.any() else [np.nan,np.nan]
   boundaries.append(dict(phase=phase,condition=condition,requested=t,wcrit=f['wcrit'][0],ci_low=ci[0],ci_high=ci[1],usable=int(good.sum()),status=f['status'][0],in_grid=f['in_grid'][0],empirical_bracket=bool(np.min(k.sum(0)/n.sum(0))<=.5<=np.max(k.sum(0)/n.sum(0)))));saved[phase,condition,t]=b['wcrit'];points[phase,condition,t]=f['wcrit'][0]
 pd.DataFrame(boundaries).to_csv(out/'longitudinal_boundaries.csv',index=False)
 contrasts=[]
 for phase in d.phase.unique():
  for t in [300000,900000,1800000,3600000]:
   for low,high in [('curvature','lambda7'),('null','curvature')]:
    a=(phase,low,t);b=(phase,high,t)
    if a not in saved or b not in saved:continue
    z=saved[b]-saved[a];good=np.isfinite(z);ci=np.percentile(z[good],[2.5,97.5]) if good.any() else [np.nan,np.nan]
    contrasts.append(dict(phase=phase,requested=t,contrast=high+'-'+low,difference=points[b]-points[a],ci_low=ci[0],ci_high=ci[1],usable=int(good.sum())))
  for c in ['null','curvature','lambda7']:
   a=(phase,c,1800000);b=(phase,c,3600000)
   if a not in saved or b not in saved:continue
   z=saved[b]-saved[a];good=np.isfinite(z);ci=np.percentile(z[good],[2.5,97.5]) if good.any() else [np.nan,np.nan]
   contrasts.append(dict(phase=phase,requested=3600000,contrast=c+':3.6M-1.8M',difference=points[b]-points[a],ci_low=ci[0],ci_high=ci[1],usable=int(good.sum()),within_002=bool(ci[0]>=-.02 and ci[1]<=.02)))
 pd.DataFrame(contrasts).to_csv(out/'longitudinal_contrasts.csv',index=False)
 (out/'completeness.json').write_text(json.dumps(dict(incomplete_cells=incomplete,grid=list(grid),interpretation='Only full planned seed-by-grid panels fitted; pilots descriptive, confirmation separate'),indent=2))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--root',action='append',required=True);a.add_argument('--out',required=True);a.add_argument('--grid',default='0,.4,.5,.6,.7,.85,1');a.add_argument('--design');p=a.parse_args()
 if p.design:
  design=json.loads(Path(p.design).read_text());analyze(p.root,p.out,design['horizon_grid'],design['seeds'])
 else:analyze(p.root,p.out,[float(x) for x in p.grid.split(',')])
