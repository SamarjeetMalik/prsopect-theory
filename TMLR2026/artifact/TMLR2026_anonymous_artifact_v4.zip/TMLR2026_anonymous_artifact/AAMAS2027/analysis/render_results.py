from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/aamas-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np,pandas as pd,json
from scipy.special import expit
from scipy.optimize import minimize_scalar
OUT=Path(__file__).resolve().parents[1]/'generated'
read=lambda f:pd.read_csv(OUT/f,keep_default_na=False)
fits=read('boundary_estimates.csv');cells=read('collapse_cells.csv');diff=read('endpoint_differences.csv');sens=read('estimator_sensitivity.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
LABEL={'supply_ppo':'Supply PPO','supply_mappo':'Supply MAPPO','mpe_mappo':'MPE MAPPO (provisional)','lbf_mappo':'LBF MAPPO'}
def get(s,c,t=None):
 d=fits[(fits.setting==s)&(fits.condition==c)]
 if t is not None:d=d[d.budget==t]
 return d.iloc[0]
def panel(ax,s,c,t=None):
 r=get(s,c,t);d=cells[(cells.setting==s)&(cells.condition==c)&(cells.budget==r.budget)]
 ax.errorbar(d.w,d.proportion,yerr=[d.proportion-d.ci_low,d.ci_high-d.proportion],fmt='o',ms=3,capsize=2,color='#184e77',label='Observed; 95% Wilson')
 x=np.linspace(d.w.min(),d.w.max(),250);ax.plot(x,expit(r.b0+r.b1*x),color='#b33f32',lw=1.3,label='Firth fit')
 ax.axhline(.5,color='.5',ls=':',lw=.7);ax.axvspan(r.ci_low,r.ci_high,color='#b33f32',alpha=.12);ax.axvline(r.wcrit,color='#b33f32',ls='--',lw=.8)
 ax.set_ylim(-.04,1.04);ax.set_xlim(d.w.min()-.025,d.w.max()+.025);ax.set_xlabel('Team-reward weight w');ax.set_ylabel('Collapse proportion')
 ax.set_title(f'{c.replace("lambda", "λ=")} · n={r.n}' if s!='supply_horizon' else f'{r.budget//1000}k requested agent transitions')
 ax.text(.03,.06,f'w₅₀={r.wcrit:.3f} [{r.ci_low:.3f}, {r.ci_high:.3f}]',transform=ax.transAxes,fontsize=7)
def save(fig,name):fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight');fig.savefig(OUT/(name+'.png'),dpi=180,bbox_inches='tight');plt.close(fig)
fig,axes=plt.subplots(3,1,figsize=(3.35,6.1),layout='constrained')
for ax,t in zip(axes[:2],[150000,300000]):panel(ax,'supply_horizon','null',t)
h=fits[fits.setting=='supply_horizon'].sort_values('budget');ax=axes[2]
ax.errorbar(h.budget/1000,h.wcrit,yerr=[h.wcrit-h.ci_low,h.ci_high-h.wcrit],fmt='o-',capsize=3,color='#184e77');ax.set_xlabel('Requested agent transitions (thousands)');ax.set_ylabel('Fitted midpoint');ax.set_title('Finite-budget boundary movement')
save(fig,'boundary_observed')
fig,axes=plt.subplots(2,2,figsize=(7,4.5),layout='constrained')
for ax,c in zip(axes.flat,['null','lambda1','lambda3','lambda7']):panel(ax,'supply_ppo',c)
save(fig,'decomposition_observed')
fig,axes=plt.subplots(4,2,figsize=(7,9),layout='constrained')
for ax,c in zip(axes.flat,['null']+[f'lambda{i}' for i in range(1,8)]):panel(ax,'supply_ppo',c)
save(fig,'all_lambda_observed')
fig,axes=plt.subplots(2,2,figsize=(7,4.6),layout='constrained')
for ax,t in zip(axes.flat,[150000,300000,450000,900000]):panel(ax,'supply_horizon','null',t)
save(fig,'all_horizons_observed')
fig,ax=plt.subplots(figsize=(6.8,3.6),layout='constrained')
for s,color,marker in zip(LABEL,['#187b37','#2072ac','#ad4dad','#ca7920'],['o','s','D','^']):
 d=fits[(fits.setting==s)&(fits.condition!='null')].sort_values('lambda_loss');valid=d[(d.in_grid==True)&(d.ci_low>=d.w_min)&(d.ci_high<=d.w_max)]
 # Full unmodified estimates shown; beyond-grid points separately marked, no clipping.
 ax.plot(d.lambda_loss,d.wcrit,':',color=color,alpha=.7)
 ax.errorbar(d.lambda_loss,d.wcrit,yerr=[d.wcrit-d.ci_low,d.ci_high-d.wcrit],fmt=marker,ms=4,capsize=2,color=color,label=LABEL[s])
 ax.scatter(d.loc[d.in_grid==False,'lambda_loss'],d.loc[d.in_grid==False,'wcrit'],s=85,facecolors='none',edgecolors=color)
ax.axhline(.95,color='.6',lw=.7,ls='--');ax.text(1.05,.98,'LBF sampled upper w = .95',fontsize=7,color='.4')
ax.set_xlabel('Loss multiplier λ');ax.set_ylabel('Fitted midpoint (unclipped)');ax.legend(fontsize=7,loc='upper left');ax.set_xticks(range(1,8));save(fig,'generalization_revised')
# Updated summary curve, descriptive fit only.
d=fits[(fits.setting=='supply_ppo')&(fits.condition!='null')].sort_values('lambda_loss');lam=d.lambda_loss.to_numpy();v=d.wcrit.to_numpy();gc=(1-v[0])/v[0]
fun=lambda rho:(1+rho*(lam-1))/(1+rho*(lam-1)+gc)
rho=minimize_scalar(lambda r:np.mean((fun(r)-v)**2),bounds=(0,1),method='bounded').x;rmse=np.sqrt(np.mean((fun(rho)-v)**2))
(OUT/'summary_curve.json').write_text(json.dumps(dict(rho=rho,g_over_c=gc,rmse=rmse,observed=v.tolist(),predicted=fun(rho).tolist()),indent=2))
fig,ax=plt.subplots(figsize=(3.3,2.5),layout='constrained');ax.errorbar(lam,v,yerr=[v-d.ci_low,d.ci_high-v],fmt='o',capsize=2);x=np.linspace(1,7,200);ax.plot(x,(1+rho*(x-1))/(1+rho*(x-1)+gc));ax.set_xlabel('λ');ax.set_ylabel('Fitted midpoint');save(fig,'affine_revised')
# Generated LaTeX uses the exact same exports as plots.
def ci(r):return f"${r.wcrit:.3f}$ $[{r.ci_low:.3f},{r.ci_high:.3f}]$"
def dci(r):return f"${r.difference:+.3f}$ $[{r.ci_low:+.3f},{r.ci_high:+.3f}]$"
def table(name,caption,label,head,rows,spec,wide=False):
 env='table*' if wide else 'table'
 text='\\begin{'+env+'}[t]\n\\caption{'+caption+'}\n\\label{'+label+'}\n\\centering\\small\n\\begin{tabular}{'+spec+'}\n\\toprule\n'+head+r' \\'+'\n\\midrule\n'+'\n'.join(x+r' \\' for x in rows)+'\n\\bottomrule\n\\end{tabular}\n\\end{'+env+'}\n'
 (OUT/(name+'.tex')).write_text(text)
rows=[]
for s,end in [('supply_ppo','lambda7'),('supply_mappo','lambda7'),('mpe_mappo','lambda7'),('lbf_mappo','lambda4')]:
 a=get(s,'lambda1');b=get(s,end);r=diff[(diff.setting==s)&(diff.low=='lambda1')&(diff.high==end)&(diff.pairing=='paired')].iloc[0];u=diff[(diff.setting==s)&(diff.low=='lambda1')&(diff.high==end)&(diff.pairing=='independent')].iloc[0]
 rows.append(f'{LABEL[s]} & {ci(a)} & {ci(b)} & {dci(r)} & {r.usable}/{r.requested}')
table('endpoint_table','Selected endpoint comparisons using Firth fits and 2,000 seed-block bootstrap replicates, conditional on fixed labels. Endpoints are $\\lambda=7$ except LBF ($\\lambda=4$, retained for comparability with the submitted contrast; not a newly selected last-interior endpoint). MPE is descriptive only because its historical configurations are unresolved.','tab:generalization',r'Setting & $\lambda=1$ & Selected endpoint & Paired difference & Usable',rows,'@{}llllr@{}',True)
rows=[]
for r in diff.itertuples():
 if r.low=='lambda1' and r.high in ['lambda7','lambda4']:rows.append(f'{LABEL[r.setting]} & {r.pairing} & {dci(r)} & {r.usable}/{r.requested}')
table('difference_sensitivity','Paired and independently resampled endpoint differences. Intervals condition on fixed labels and do not incorporate calibration uncertainty.','tab:paired_sensitivity','Setting & Resampling & Difference and 95\\% CI & Usable',rows,'@{}llll@{}',True)
rows=[]
for c in ['null','lambda1','lambda3','lambda7']:
 r=get('supply_ppo',c); contrasts=[]
 for low in ['null','lambda1']:
  a=diff[(diff.setting=='supply_ppo')&(diff.low==low)&(diff.high==c)&(diff.pairing=='paired')]
  contrasts.append(dci(a.iloc[0]) if len(a) else '--')
 rows.append(f'{c.replace("lambda", "$\\lambda=$")} & {ci(r)} & '+ ' & '.join(contrasts))
table('decomposition_table','Supply PPO reward-transform decomposition at 300k requested agent transitions. Null: linear; all lambda conditions: $\\alpha=\\beta=.88$. Differences use the same seed-block draws.','tab:decomposition','Condition & Midpoint and 95\\% CI & Versus null & Versus curvature',rows,'@{}llll@{}',True)
rows=[f'{int(r.lambda_loss)} & {r.n} & {ci(r)} & ${r.b1:.2f}$ & {r.bootstrap_usable}/{r.bootstrap_requested}' for r in d.itertuples()]
table('lambda_table','Full supply PPO sweep after inclusion of all 120 completed refinement runs. Slopes are Firth estimates; no legacy Wald significance claims are retained.','tab:lambda_sweep',r'$\lambda$ & Runs & Midpoint and 95\% CI & Slope & Usable',rows,'@{}rrlrr@{}')
rows=[f'{r.budget//1000}k & {r.n} & {ci(r)}' for r in h.itertuples()]
table('horizon_table','Supply PPO linear-reward horizons, recomputed with Firth fits and seed-block intervals. Budgets are requested agent transitions.','tab:horizons','Budget & Runs & Midpoint and 95\\% CI',rows,'@{}rrl@{}')
rows=[]
for c in ['null']+[f'lambda{i}' for i in range(1,8)]:
 a=cells[(cells.setting=='supply_ppo')&(cells.condition==c)]
 rows.append(c.replace('lambda',r'$\lambda=$')+' & '+', '.join(f'{r.w:.2f}: {r.k}/{r.n}' for r in a.itertuples()))
table('supply_cells','Observed supply PPO collapse counts at 300k. Entries are $w:k/n$; Wilson intervals and all-setting cell records are exported in collapse\\_cells.csv.','tab:observed_cells','Condition & Observed cells',rows,'@{}lp{0.84\\textwidth}@{}',True)
# Compare estimators only when each is localized in the observed w range.
comparison=[]
for key,g in sens.groupby(['setting','budget','condition']):
 r=get(key[0],key[2],key[1]);vals=[]
 for a in g.itertuples():
  try:v=float(a.wcrit)
  except ValueError:continue
  if a.status in ['ok','plateau'] and r.w_min<=v<=r.w_max:vals.append(v)
 comparison.append(dict(setting=key[0],budget=key[1],condition=key[2],identified_estimators=len(vals),spread=max(vals)-min(vals) if len(vals)>1 else np.nan))
cmp=pd.DataFrame(comparison);cmp.to_csv(OUT/'estimator_agreement.csv',index=False)
macros=[]
for s,c,t,name in [('supply_horizon','null',300000,'Headline'),('supply_ppo','lambda7',300000,'HighLambda'),('supply_ppo','null',300000,'RepeatedNull')]:
 r=get(s,c,t);macros.append('\\newcommand{\\'+name+'}{'+ci(r)+'}')
macros+=['\\newcommand{\\EstimatorMaxSpread}{'+f'{cmp.spread.max():.3f}'+'}','\\newcommand{\\SummaryRho}{'+f'{rho:.3f}'+'}','\\newcommand{\\SummaryRMSE}{'+f'{rmse:.3f}'+'}']
(OUT/'numbers.tex').write_text('\n'.join(macros)+'\n')
print('Rendered figures, tables and numeric macros; max localized estimator spread:',cmp.spread.max())
rows=[]
for s,g in cmp.groupby('setting'):
 good=g.dropna(subset=['spread']);r=good.loc[good.spread.idxmax()]
 rows.append(f'{LABEL.get(s,"Supply horizons")} & {r.condition} & {r.spread:.3f} & {int(r.identified_estimators)}')
table('estimator_summary','Maximum within-grid point-estimator spread by setting, comparing available Firth, logistic, probit and isotonic fits. Unidentified or extrapolated estimators do not enter the spread; full statuses and isotonic plateau intervals are exported.','tab:estimator_summary','Setting & Condition & Maximum spread & Estimators',rows,'@{}llrr@{}',True)
rows=[]
for r in fits.itertuples():
 bs=json.loads(r.brackets)
 bracket='not bracketed' if not bs else '; '.join(f'{x:.2f}/{y:.2f}' for x,y in bs)
 rows.append(f'{LABEL.get(r.setting,"Supply horizon")} & {r.condition} & {"unverified" if r.budget<0 else str(r.budget//1000)+"k"} & {bracket}')
table('bracketing_table','Observed adjacent cells bracketing probability .5 (lower-$w$ proportion at least .5, upper-$w$ at most .5). All such adjacent pairs are retained; a fitted midpoint need not lie in the empirically bracketing pair.','tab:bracketing','Setting & Condition & Budget & Observed $w$ pair(s)',rows,'@{}llll@{}',True)
