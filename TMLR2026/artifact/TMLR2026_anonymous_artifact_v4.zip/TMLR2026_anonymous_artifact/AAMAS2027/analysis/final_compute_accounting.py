from pathlib import Path
import re,json,datetime,csv,hashlib
root=Path(__file__).resolve().parents[1];out=root/'audit/accounting';rows=[];parents={}
groups={'132627':'horizon_confirmation','132628':'direct_controls','132666':'diagnostic_audit','132625':'validation_smoke','132589':'pilot_initial_900k','132590':'base_calibration','132591':'calibration_freeze','132592':'pilot_continuation','132593':'pilot_gate','132610':'pilot_refinement_and_calibration'}
def seconds(s):
 h,m,v=map(int,s.split(':'));return 3600*h+60*m+v
def date(s):return datetime.datetime.strptime(s,'%a %b %d %H:%M:%S %Y')
for path in out.glob('*scheduler.txt'):
 for block in re.split(r'(?=^Job Id:)',path.read_text(),flags=re.M):
  if not block.startswith('Job Id:'):continue
  job=block.splitlines()[0].split(': ',1)[1];base=job.split('[')[0].split('.')[0];fields={}
  for line in block.splitlines()[1:]:
   m=re.match(r'^    ([\w.]+) = (.*)$',line)
   if m:fields[m[1]]=m[2]
  if '[]' in job:parents[base]=fields;continue
  assert fields['job_state']=='F' and int(fields['Exit_status'])==0,(job,fields.get('job_state'),fields.get('Exit_status'))
  cpu=seconds(fields['resources_used.cput']);wall=seconds(fields['resources_used.walltime']);start=date(fields['stime']);end=start+datetime.timedelta(seconds=wall)
  assert fields['resources_used.mem'].endswith('kb')
  group=groups[base]
  if base=='132610':group='pilot_refinement' if int(re.search(r'\[(\d+)\]',job)[1])<15 else 'refinement_calibration'
  rows.append(dict(job=job,group=group,cpu_seconds=cpu,worker_wall_seconds=wall,cpus=int(fields['resources_used.ncpus']),scheduler_peak_kb=int(fields['resources_used.mem'][:-2]),start=start.isoformat(),end_from_walltime=end.isoformat(),exit_status=0))
assert len({r['job'] for r in rows})==len(rows)
for base,expected in [('132627',32),('132628',16),('132666',32),('132625',1),('132589',8),('132590',4),('132591',1),('132592',32),('132593',1),('132610',20)]:assert sum(r['job'].split('[')[0].split('.')[0]==base for r in rows)==expected
summary=[]
for group in sorted({r['group'] for r in rows}):
 g=[r for r in rows if r['group']==group];summary.append(dict(group=group,workers=len(g),cpu_hours=sum(r['cpu_seconds'] for r in g)/3600,worker_wall_hours=sum(r['worker_wall_seconds'] for r in g)/3600,elapsed_span_hours=(datetime.datetime.fromisoformat(max(r['end_from_walltime'] for r in g))-datetime.datetime.fromisoformat(min(r['start'] for r in g))).total_seconds()/3600,max_worker_memory_mib=max(r['scheduler_peak_kb'] for r in g)/1024))
for name,data in [('job_accounting',rows),('group_accounting',summary)]:
 with (out/(name+'.csv')).open('w') as f:w=csv.DictWriter(f,fieldnames=data[0]);w.writeheader();w.writerows(data)
# Reconcile the worker stride schedules against every completed trajectory.
reconciled=[]
for kind,total,stride,base in [('horizon',150,32,'132627'),('control',240,16,'132628')]:
 completed=0;actual=0;requested=0
 for i in range(total):
  folder=root/f'new_runs/deadline_confirmation_v1/{kind}/run_{i:03d}';d=json.loads((folder/'COMPLETE.json').read_text());c=json.loads((folder/'protocol.json').read_text());assert d['requested']==c['total_budget'];job=f'{base}[{i%stride}].master';assert any(r['job']==job for r in rows);completed+=1;actual+=d['actual_transitions'];requested+=d['requested']
 reconciled.append(dict(kind=kind,completed_runs=completed,requested_transitions=requested,actual_transitions=actual,joint_ticks=actual//5))
(out/'run_reconciliation.json').write_text(json.dumps(reconciled,indent=2));(out/'source_hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*scheduler.txt')},indent=2));print(json.dumps(summary,indent=2));print(json.dumps(reconciled,indent=2))
