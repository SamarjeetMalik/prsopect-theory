"""Map transform crossings to a descriptive equivalent linear-training budget.

The mapping fits w50 = a + b log(T/1000) to the four cross-sectional
linear-reward horizon estimates. Bootstrap intervals refit the mapping on each
seed-block replicate and invert it for the matching transform replicate.
"""

from pathlib import Path
import json
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
GEN = ROOT / "AAMAS2027" / "generated"
OUT = ROOT / "TMLR2026" / "generated"
OUT.mkdir(parents=True, exist_ok=True)

draws = pd.read_csv(GEN / "bootstrap_draws.csv")
fits = pd.read_csv(GEN / "boundary_estimates.csv")
contrasts = pd.read_csv(GEN / "endpoint_differences.csv")

budgets = np.array([150_000, 300_000, 450_000, 900_000], dtype=int)
x = np.log(budgets / 1000.0)
horizon = (
    draws[draws.setting.eq("supply_horizon")]
    .pivot(index="replicate", columns="budget", values="wcrit")
    .reindex(columns=budgets)
)
Y = horizon.to_numpy()
x_centered = x - x.mean()
b_boot = ((Y - Y.mean(axis=1, keepdims=True)) * x_centered).sum(axis=1) / (x_centered**2).sum()
a_boot = Y.mean(axis=1) - b_boot * x.mean()

horizon_points = fits[fits.setting.eq("supply_horizon")].sort_values("budget")
b_point, a_point = np.polyfit(np.log(horizon_points.budget / 1000.0), horizon_points.wcrit, 1)


def condition_rows(condition: str) -> tuple[pd.Series, np.ndarray]:
    labels = draws.condition.fillna("null")
    sample = draws[(draws.setting == "supply_ppo") & labels.eq(condition)].sort_values("replicate")
    point_labels = fits.condition.fillna("null")
    point = fits[(fits.setting == "supply_ppo") & point_labels.eq(condition)].iloc[0]
    return point, sample.wcrit.to_numpy()


def contrast(low: str, high: str) -> str:
    lows = contrasts.low.fillna("null")
    highs = contrasts.high.fillna("null")
    rows = contrasts[
        contrasts.setting.eq("supply_ppo")
        & lows.eq(low)
        & highs.eq(high)
        & contrasts.pairing.eq("paired")
    ]
    if rows.empty:
        return "--"
    r = rows.iloc[0]
    return f"${r.difference:+.3f}$ $[{r.ci_low:+.3f},{r.ci_high:+.3f}]$"


records = []
for condition in ["null", "lambda1", "lambda3", "lambda7"]:
    point, target_boot = condition_rows(condition)
    equivalent_boot = np.exp((target_boot - a_boot) / b_boot)
    usable = np.isfinite(equivalent_boot) & (b_boot < 0) & (equivalent_boot > 0)
    interval = np.percentile(equivalent_boot[usable], [2.5, 50, 97.5])
    equivalent_point = float(np.exp((point.wcrit - a_point) / b_point))
    records.append(
        dict(
            condition=condition,
            w50=point.wcrit,
            ci_low=point.ci_low,
            ci_high=point.ci_high,
            equivalent_budget_k=equivalent_point,
            equivalent_ci_low_k=interval[0],
            equivalent_ci_median_k=interval[1],
            equivalent_ci_high_k=interval[2],
            usable=int(usable.sum()),
            extrapolated=bool(equivalent_point < budgets.min() / 1000 or equivalent_point > budgets.max() / 1000),
        )
    )

result = pd.DataFrame(records)
result.to_csv(OUT / "equivalent_budget.csv", index=False)
(OUT / "equivalent_budget_model.json").write_text(
    json.dumps(
        {
            "model": "w50 = a + b * log(T/1000)",
            "a": a_point,
            "b": b_point,
            "observed_budget_range_k": [150, 900],
            "bootstrap_replicates": int(len(a_boot)),
            "interpretation": "descriptive inversion; not a causal equivalence",
        },
        indent=2,
    )
    + "\n"
)

labels = {"null": "Linear null", "lambda1": r"Curvature ($\lambda=1$)", "lambda3": r"$\lambda=3$", "lambda7": r"$\lambda=7$"}
rows = []
for r in result.itertuples():
    w = f"${r.w50:.3f}$ $[{r.ci_low:.3f},{r.ci_high:.3f}]$"
    null_delta = "--" if r.condition == "null" else contrast("null", r.condition)
    curvature_delta = contrast("lambda1", r.condition) if r.condition in {"lambda3", "lambda7"} else "--"
    marker = r"$^{\dagger}$" if r.extrapolated else ""
    eq = f"${r.equivalent_budget_k:.0f}$ $[{r.equivalent_ci_low_k:.0f},{r.equivalent_ci_high_k:.0f}]${marker}"
    rows.append(f"{labels[r.condition]} & {w} & {null_delta} & {curvature_delta} & {eq}")

tex = r"""\begin{table*}[t]
\caption{Supply-PPO reward-transform decomposition at 300k requested agent transitions and descriptive equivalent linear-training budgets. Differences use paired seed-block draws. Equivalent budgets invert the four-point cross-sectional fit $w_{50}=1.4824-0.13748\log(T/1000)$ and propagate the same 2,000 bootstrap replicates; they are descriptive, not causal. $\dagger$ denotes extrapolation below the observed 150k--900k horizon range.}
\label{tab:decomposition}
\centering\small
{\setlength{\tabcolsep}{4pt}
\begin{tabular}{@{}lllll@{}}
\toprule
Condition & Crossing and 95\% CI & Versus null & Versus curvature & Equivalent budget, k \\
\midrule
""" + (" " + chr(92) * 2 + "\n").join(rows) + r""" \\
\bottomrule
\end{tabular}
}
\end{table*}
"""
(OUT / "equivalent_budget_table.tex").write_text(tex)
print(result.to_string(index=False))
