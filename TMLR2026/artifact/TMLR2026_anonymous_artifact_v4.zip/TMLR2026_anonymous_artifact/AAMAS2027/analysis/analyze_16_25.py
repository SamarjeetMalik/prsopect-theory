from pathlib import Path
import sys,json,hashlib,csv
import numpy as np,pandas as pd
from boundary import firth
from reanalyze import matrices
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'AAMAS2027/generated/pointers16_25';OUT.mkdir(exist_ok=True)
D=pd.read_csv(ROOT/'AAMAS2027/generated/canonical_runs.csv',keep_default_na=False)
SEEDS=list(range(42,62));B=2000;rng=np.random.default_rng(20260926);weights=rng.multinomial(20,np.full(20,.05),size=B)
records=[];differences=[];draws=[]
for setting,thresholds,end in [('mpe_mappo',[.1152,.1296,.144,.1584,.1728,.164],'lambda7'),('lbf_mappo',[.5008,.5634,.626,.6886,.7512],'lambda4')]:
 for theta in thresholds:
  fits={}
  for cond in ['lambda1',end]:
   g=D[(D.setting==setting)&(D.condition==cond)].copy();g['y']=(g.metric<theta).astype(int);w,k,n=matrices(g,SEEDS)
   p=firth(w,k.sum(0),n.sum(0));b=firth(w,weights@k,weights@n);valid=np.isfinite(b['wcrit']);ci=np.percentile(b['wcrit'][valid],[2.5,97.5]) if valid.any() else [np.nan,np.nan]
   prop=k.sum(0)/n.sum(0);bracket=bool((prop>=.5).any() and (prop<=.5).any())
   records.append(dict(setting=setting,threshold=theta,condition=cond,n=len(g),wcrit=p['wcrit'][0],ci_low=ci[0],ci_high=ci[1],status=p['status'][0],in_grid=p['in_grid'][0],observed_bracket=bracket,usable=int(valid.sum()),failed=int((~b['converged']).sum()),outside_grid=int((valid&~b['in_grid']).sum())))
   fits[cond]=(p,b)
   for i in range(B):draws.append(dict(setting=setting,threshold=theta,condition=cond,replicate=i,wcrit=b['wcrit'][i],status=b['status'][i],in_grid=b['in_grid'][i]))
  a,bb=fits['lambda1'],fits[end];delta=bb[1]['wcrit']-a[1]['wcrit'];valid=np.isfinite(delta);ci=np.percentile(delta[valid],[2.5,97.5]) if valid.any() else [np.nan,np.nan]
  differences.append(dict(setting=setting,threshold=theta,endpoint=end,difference=bb[0]['wcrit'][0]-a[0]['wcrit'][0],ci_low=ci[0],ci_high=ci[1],usable=int(valid.sum()),both_point_crossings_in_grid=bool(a[0]['in_grid'][0] and bb[0]['in_grid'][0])))
pd.DataFrame(records).to_csv(OUT/'label_sensitivity_boundaries.csv',index=False);pd.DataFrame(differences).to_csv(OUT/'label_sensitivity_differences.csv',index=False);pd.DataFrame(draws).to_csv(OUT/'label_sensitivity_draws.csv',index=False)
# Restore all actually recorded continuous metrics, rather than invent missing fields.
rawcache={};metricrows=[];missing=[]
for row in D.itertuples():
 if row.setting=='supply_horizon' and row.budget!=300000:continue
 if row.condition not in ['null','lambda1',('lambda4' if row.setting=='lbf_mappo' else 'lambda7')]:continue
 if row.source not in rawcache:rawcache[row.source]=list(csv.DictReader((ROOT/row.source).open()))
 original=rawcache[row.source][row.source_line-2]
 names=['profit','lost_sales','mean_order','mean_S'] if row.setting.startswith('supply') else (['mean_reward','mean_occupancy'] if row.setting=='mpe_mappo' else ['mean_reward'])
 for metric in names:
  if original.get(metric) in ['',None]:missing.append(dict(setting=row.setting,condition=row.condition,metric=metric,source=row.source));continue
  metricrows.append(dict(setting=('supply_structural_ppo' if row.setting=='supply_horizon' else row.setting),condition=row.condition,budget=row.budget,w=row.w,seed=row.seed,metric=metric,value=float(original[metric]),source=row.source))
metrics=pd.DataFrame(metricrows);metrics.to_csv(OUT/'performance_runs.csv',index=False);pd.DataFrame(missing).drop_duplicates().to_csv(OUT/'missing_performance_fields.csv',index=False)
summary=[]
for key,g in metrics.groupby(['setting','condition','budget','w','metric']):
 vals=g.sort_values('seed').value.to_numpy();draw=rng.integers(0,len(vals),(B,len(vals)));ci=np.percentile(vals[draw].mean(1),[2.5,97.5])
 summary.append(dict(zip(['setting','condition','budget','w','metric'],key),mean=vals.mean(),ci_low=ci[0],ci_high=ci[1],n=len(vals)))
pd.DataFrame(summary).to_csv(OUT/'performance_cells.csv',index=False)
# Control diagnostics: equal-weight across policy seeds, never pooled variances.
controls=[];hashes={}
for name,folder,arm in [('A','expControlA_refpoint_figures','z0_arm'),('B','expControlB_scalematch_figures','match_arm'),('C','expControlC_rewardunit_figures','scale_arm')]:
 path=next((ROOT/'docs'/folder).glob('*raw_data.csv'));hashes[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest();df=pd.read_csv(path,keep_default_na=False)
 df['control']=name;df['arm']=df[arm];df['reference']=df.get('z0_value',0.0);df['input_local_scale']=df.get('local_scale',1.0);df['input_global_scale']=df.get('global_scale',1.0);df['transform_output_scale']=df.get('output_scale',1.0)
 controls.append(df)
C=pd.concat(controls,ignore_index=True);C.to_csv(OUT/'control_diagnostic_runs.csv',index=False);stats=[]
for key,g in C.groupby(['control','arm','reference','input_local_scale','input_global_scale','transform_output_scale','lambda_loss','w']):
 row=dict(zip(['control','arm','reference','local_scale','global_scale','output_scale','lambda_loss','w'],key));row['n']=len(g)
 for m in ['frac_gain','frac_loss','mean_cpt_reward','reward_std','return_std']:
  row[m+'_mean']=g[m].mean();row[m+'_median']=g[m].median();row[m+'_sd_across_policies']=g[m].std()
 stats.append(row)
S=pd.DataFrame(stats);S.to_csv(OUT/'control_diagnostics_by_cell.csv',index=False)
# Adjacent cells nearest each control arm's fitted crossing, using all saved policy labels.
near=[]
for key,g in C.groupby(['control','arm','lambda_loss']):
 g=g.copy();g['y']=((g.mean_S<10)&(g.profit<=-127.1)).astype(int);w,k,n=matrices(g,SEEDS);fit=firth(w,k.sum(0),n.sum(0));wc=fit['wcrit'][0]
 j=int(np.clip(np.searchsorted(w,wc),1,len(w)-1));selected=[w[j-1],w[j]]
 h=S[(S.control==key[0])&(S.arm==key[1])&(S.lambda_loss==key[2])&(S.w.isin(selected))].copy();h['diagnostic_boundary']=wc;near.append(h)
pd.concat(near).to_csv(OUT/'control_diagnostics_near_boundary.csv',index=False)
(OUT/'input_hashes.json').write_text(json.dumps(hashes,indent=2));(OUT/'analysis_metadata.json').write_text(json.dumps(dict(seed=20260926,bootstrap=2000,label_sensitivity='post-review; conditional on each fixed threshold; MPE provisional',performance='policy-seed resampled mean; evaluation uncertainty not separately estimated',signs='frac_gain means nonnegative; zero not separately logged; five final-policy evaluation episodes'),indent=2))
print(pd.DataFrame(differences).to_string(index=False));print('Control B raw nonnegative fractions:',C[(C.control=='B')&(C.arm=='raw')].groupby('lambda_loss').frac_gain.mean().to_dict())
