from pathlib import Path
import json,math
import pandas as pd,numpy as np
root=Path(__file__).resolve().parents[1];out=root/'audit/final_diagnostics';records=[json.loads(p.read_text()) for p in (out/'remote').glob('*.json')]
assert len(records)==390 and len({(r['kind'],r['run']) for r in records})==390
errors=[(r['kind'],r['run'],r['errors']) for r in records if r['errors']]
(out/'training_failures.json').write_text(json.dumps(errors,indent=2));assert not errors,errors
rows=[];updates=[]
for r in records:
 c=r['config'];base=dict(kind=r['kind'],arm=c.get('arm',c.get('condition')),w=c['w'],seed=c['seed'])
 rows.extend(dict(**base,**m) for m in r['metrics'])
 updates.extend(dict(**base,window=window,**m) for window,m in r['optimizer'].items())
f=pd.DataFrame(rows);f.to_csv(out/'training_moments_by_run.csv',index=False);u=pd.DataFrame(updates);u.to_csv(out/'optimizer_by_run.csv',index=False)
def pool(g):
 n=g['count'].sum();mean=(g['count']*g['mean']).sum()/n;second=(g['count']*g.rms**2).sum()/n
 return dict(count=int(n),mean=mean,std=math.sqrt(max(0,second-mean**2)),rms=math.sqrt(second),**{k:float((g['count']*g[k]).sum()/n) for k in ['positive','zero','negative']})
agg=[]
for key,g in f.groupby(['kind','arm','window','agent','metric']):agg.append(dict(zip(['kind','arm','window','agent','metric'],key),**pool(g)))
a=pd.DataFrame(agg);a.to_csv(out/'training_moments_by_arm.csv',index=False)
agg=[]
for key,g in f.groupby(['kind','arm','w','window','agent','metric']):agg.append(dict(zip(['kind','arm','w','window','agent','metric'],key),**pool(g)))
pd.DataFrame(agg).to_csv(out/'training_moments_by_cell.csv',index=False)
optimizer=[]
for key,g in u.groupby(['kind','arm','window']):
 optimizer.append(dict(zip(['kind','arm','window'],key),batches=int(g.n.sum()),clipping_fraction=g.clipped.sum()/g.n.sum(),max_normalized_mean=g.max_normalized_mean.max(),max_normalized_std_error=g.max_normalized_std_error.max(),constant_normalized=int(g.constant_normalized.sum()),**{k:float(g[k].sum()/g.n.sum()) for k in ['value_loss','approx_kl','clip_fraction','entropy','actor_grad_norm','critic_grad_norm','total_grad_norm']}))
o=pd.DataFrame(optimizer);o.to_csv(out/'optimizer_by_arm.csv',index=False)
report=dict(training_runs_audited=390,errors=errors,rollout_records=sum(r['actual']//640 for r in records),optimizer_updates=sum(r['actual']//640 for r in records),optimizer_minibatches=int(u[u.window=='all'].n.sum()),nonfinite_explained_variance=sum(r['explained_variance_nonfinite'] for r in records),max_normalized_advantage_mean=float(u.max_normalized_mean.max()),max_normalized_advantage_std_error=float(u.max_normalized_std_error.max()),constant_normalized_batches=int(u[u.window=='all'].constant_normalized.sum()),scope='Full compressed rollout/update streams, both arms and horizons; all/late moments are descriptive and pooled with sample counts. No assumption that optimizer minibatches or rollout samples are independent statistical replicates.')
(out/'training_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
print(a[(a.kind=='control')&(a.window=='all')&(((a.agent=='pooled')&a.metric.isin(['centered','transformed','advantages_buffer']))|((a.agent=='optimizer')&(a.metric=='normalized_advantage')))][['arm','metric','std','rms','positive','negative']].to_string(index=False))
print(o[(o.kind=='control')&(o.window=='all')][['arm','clipping_fraction','actor_grad_norm','critic_grad_norm','approx_kl']].to_string(index=False))
