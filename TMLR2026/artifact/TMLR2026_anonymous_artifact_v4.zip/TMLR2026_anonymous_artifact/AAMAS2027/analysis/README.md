# Reanalysis for checklist items 6–15

Run from the repository root:

```
AAMAS2027/.venv/bin/python AAMAS2027/analysis/test_boundary.py
AAMAS2027/.venv/bin/python AAMAS2027/analysis/reanalyze.py
AAMAS2027/.venv/bin/python AAMAS2027/analysis/render_results.py
AAMAS2027/.venv/bin/python AAMAS2027/analysis/validate_outputs.py
make -C AAMAS2027 all
```

The local environment is isolated from training dependencies. Its exact analysis versions are recorded in `requirements.lock`. All outputs go to `AAMAS2027/generated`; legacy data, figures, experiment drivers and frozen submitted sources are unchanged.

`boundary.py` implements grouped-binomial Firth logistic fitting with the Jeffreys log-determinant penalty, adjusted scores, bounded scoring steps and likelihood ascent checks. Its formulation follows the [brglm2 adjusted-score documentation](https://github.com/ikosmidis/brglm2). The independent test checks agreement with direct numerical maximization, explicit Bernoulli expansion, complete separation, degenerate labels and batched fits.

`reanalyze.py` records input hashes, source rows, excluded records and configuration keys. Exact duplicate cells would be deduplicated; conflicting duplicates stop execution. Scheduled counts come from the declared grids; valid saved results are distinguished from scheduler completion records, which were not recovered. Null is a literal condition name: consumers of exported CSVs must use `keep_default_na=False` to prevent pandas treating it as missing.

The main seed bootstrap draws 20 seed identifiers with replacement 2,000 times, with random seed 20260926. Shared multiplicities are reused across conditions and horizons. This is pairing by training-seed identifier, not a claim of identical realized environment randomness. Independent-endpoint sensitivity uses separately generated seed-block draws. Every replicate's coefficients/status/crossing is exported; percentile intervals include out-of-grid finite draws. This execution had no failed or unidentified bootstrap fits. Curves are displayed only across observed grids. MPE is explicitly provisional: a computed descriptive contrast cannot resolve the historical 2M/4M or wrapper-scale provenance issues.

Labels: supply uses reset-action mean_S < 10 AND reported five-node profit <= -127.1; MPE uses occupancy < .144; LBF uses native team return < .626. Transfer calibration is retrospective and LBF treatment-informed. Intervals condition on these fixed rounded thresholds; they do not include threshold-calibration uncertainty. Unpenalized logistic and probit separation is reported rather than hidden behind large coefficients. Isotonic is decreasing weighted PAVA with linear interpolation and explicit .5 plateau intervals; the midpoint tie convention is used only in the estimator comparison.

All 120 supply refinement rows are included. LBF has one excluded malformed line and missing cell: lambda 2, w=.2, seed 47. The attempted cluster log recovery found no file at the expected path; no rounded or guessed result was substituted. LBF lambda 4 is retained as the historically selected contrast, not newly claimed to be the last interior point.

`evaluate_supply.py` is an opt-in adapter for future training drivers. It preserves the legacy evaluator's return metrics and collapse label and adds an agent-step-weighted trajectory mean of predicted base-stock actions, excluding the final reset predictions. Its recording contract is tested with a synthetic evaluator; it has not been exercised in a new training run or wired into legacy experiment drivers.

`generated_artifact_manifest.json` links generated outputs to their hashes, generator scripts and complete input hashes. The historical `audit/submission_evidence_manifest.csv` remains a record of the submitted manuscript's provisional lineage, not the new generated-artifact map.
