"""Check new scope exports, source claims, referenced assets, and compiler diagnostics."""
from pathlib import Path
import csv,hashlib,json,re
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'generated/pointers36_40'
f=pd.read_csv(OUT/'scope_boundaries.csv');c=pd.read_csv(OUT/'scope_contrasts.csv');assert len(f)==13 and len(c)==8
assert f.usable.eq(2000).all() and c.usable.eq(2000).all() and f.status.eq('ok').all()
for row in c.itertuples():
 expected=f.set_index('arm').loc[row.single,'wcrit']-f.set_index('arm').loc[row.baseline,'wcrit'];assert abs(row.difference-expected)<1e-12
 z=pd.read_csv(OUT/f'difference_{row.single}_{row.baseline}_{row.resampling}.csv').difference.to_numpy();assert np.allclose(np.percentile(z,[2.5,97.5]),[row.ci_low,row.ci_high])
# Algebraic counterexample to the removed blanket equal-gain assertion.
a=4.;alpha=.7;beta=.9;lam=7.;assert np.isclose(lam*a**beta/a**alpha,lam*a**(beta-alpha)) and not np.isclose(lam*a**beta/a**alpha,lam)
assert np.isclose(-np.log(.5),np.log(2)) and not np.isclose(np.log(2),1)
s=(ROOT/'content/supplement-body.tex').read_text();m=(ROOT/'content/main-body.tex').read_text()
for bad in ['under a checked local premise','empirically raises the escape SNR','mechanism fixes sign','matching the \\emph{fully}']:
 assert bad not in s+m,bad
for name in ['main','supplement']:
 log=(ROOT/f'build/{name}.log').read_text();assert 'Overfull' not in log and 'undefined references' not in log and not re.search(r'LaTeX Warning: (Reference|Citation).*undefined',log)
visited=set();assets=[]
def read(path):
 path=path.resolve()
 if path in visited:return
 visited.add(path);text=path.read_text()
 for match in re.finditer(r'\\input\{([^}]+)\}',text):
  child=ROOT/(match[1]+('' if match[1].endswith('.tex') else '.tex'));assert child.exists(),child;read(child)
 for block in re.finditer(r'\\begin\{(figure\*?|table\*?)\}(.*?)\\end\{\1\}',text,re.S):
  typ,body=block[1],block[2];label=re.search(r'\\label\{([^}]+)\}',body);refs=re.findall(r'\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}',body);paths=[]
  for ref in refs:
   options=[ROOT/ref]+[ROOT/(ref+ext) for ext in ['.pdf','.png','.jpg']];p=next((x for x in options if x.is_file()),None);assert p,ref;paths.append(p)
  rel=str(path.relative_to(ROOT));current=rel.startswith('generated/') or bool(paths) and all('generated' in p.parts for p in paths)
  category='current generated analysis; inspect named pipeline exports' if current else 'historical/source-audited display; numerical regeneration not certified by asset check'
  assets.append(dict(source=rel,line=text[:block.start()].count('\n')+1,kind=typ,label=label[1] if label else '',assets=';'.join(str(p.relative_to(ROOT)) for p in paths),sha256=';'.join(hashlib.sha256(p.read_bytes()).hexdigest() for p in paths),evidence_status=category))
for name in ['main.tex','supplement.tex']:read(ROOT/name)
with (ROOT/'audit/asset_inventory.csv').open('w') as file:
 w=csv.DictWriter(file,fieldnames=assets[0]);w.writeheader();w.writerows(assets)
report=dict(scope_fits=13,paired_and_independent_contrasts=8,usable_draws_per_fit=2000,duplicate_endpoint_policy='identical recorded node2 endpoint outcomes kept separate, never treated as independent replication',referenced_tex_files=len(visited),display_count=len(assets),historical_or_source_audited_displays=sum(x['evidence_status'].startswith('historical') for x in assets),build_checks='no undefined references/citations or overfull boxes',scope='Verifies new exports, mathematical corrections and asset existence; does not certify historical numeric lineage or complete pending experiments.')
(OUT/'validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
