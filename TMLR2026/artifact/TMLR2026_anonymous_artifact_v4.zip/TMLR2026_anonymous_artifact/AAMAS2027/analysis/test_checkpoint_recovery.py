"""Exercise real longitudinal sequences and the missing-data guard."""
import json,tempfile
from pathlib import Path
import pandas as pd
from analyze_checkpoint_recovery import analyze
with tempfile.TemporaryDirectory() as temp:
 root=Path(temp);analyze(root/'absent',root/'empty')
 assert 'no longitudinal' in (root/'empty/status.json').read_text()
 for seed,sequence in [(100,[True,False,False,False,True]),(101,[False,True,False,False,False])]:
  folder=root/'runs'/str(seed);folder.mkdir(parents=True)
  (folder/'protocol.json').write_text(json.dumps(dict(condition='null',w=.5,seed=seed,phase='pilot')))
  for t,c in zip([300000,450000,600000,750000,900000],sequence):
   (folder/f'evaluation_{t}.json').write_text(json.dumps(dict(requested_checkpoint=t,actual_agent_transitions=t,summary={'collapsed':c})))
 analyze(root/'runs',root/'out')
 seq=pd.read_csv(root/'out/recovery_sequences.csv');rates=pd.read_csv(root/'out/recovery_rates.csv')
 assert seq.loc[seq.seed==100,'first_three_checkpoint_recovery'].iloc[0]==750000
 assert rates.loc[rates.requested==450000,'recovery_fraction'].iloc[0]==1
 assert rates.loc[rates.requested==450000,'relapse_fraction'].iloc[0]==1
 assert rates.loc[rates.requested==900000,'recovery_fraction'].iloc[0]==0
print('PASS: missing-data guard, recovery, sustained recovery and relapse sequences')
