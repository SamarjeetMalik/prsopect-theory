import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from boundary import firth
# Independent direct maximization of the penalized binomial likelihood.
w=np.array([.2,.4,.6,.8]);n=np.array([20,20,20,20]);k=np.array([20,17,3,0])
f=firth(w,k,n)
X=np.column_stack([np.ones(4),w])
def objective(b):
 e=X@b;p=expit(e);I=X.T@((n*p*(1-p))[:,None]*X)
 return -((k*e-n*np.logaddexp(0,e)).sum()+.5*np.linalg.slogdet(I)[1])
r=minimize(objective,[8,-16],method='BFGS',tol=1e-9)
assert f['status'][0]=='ok'
assert abs(objective([f['b0'][0],f['b1'][0]])-r.fun)<1e-7
# Fully separated data must produce a finite fit, not an infinite MLE surrogate.
s=firth(w,[20,20,0,0],n);assert s['status'][0]=='ok' and abs(s['wcrit'][0]-.5)<1e-6
# Frequency weighting matches an explicitly expanded Bernoulli dataset.
we=np.repeat(w,n);ye=np.concatenate([np.r_[np.ones(a),np.zeros(b-a)] for a,b in zip(k,n)])
e=firth(we,ye,np.ones(len(we)));assert abs(e['wcrit'][0]-f['wcrit'][0])<1e-7
# Degenerate labels cannot be represented as identified crossings.
assert firth(w,[20]*4,n)['status'][0]=='single_outcome'
# Multiple bootstrap fits equal independent fits, with zero-weight cells allowed.
ks=np.array([k,[10,4,1,0]]);ns=np.array([n,[10,5,5,0]])
b=firth(w,ks,ns)
for i in range(2):assert np.allclose(b['wcrit'][i],firth(w,ks[i],ns[i])['wcrit'][0])
print('PASS: direct objective, separation, frequency weights, degeneracy and batched fits')
