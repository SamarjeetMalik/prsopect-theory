from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from boundary import firth
root=Path(__file__).resolve().parents[1];out=root/'audit/final_diagnostics';d=pd.read_csv(out/'validated_evaluations.csv',keep_default_na=False);seeds=list(range(42,52));rows=[];leave={}
for (kind,t,arm),g in d[(d.episodes==10)&d.budget.isin([300000,900000,1800000,3600000])].groupby(['kind','budget','arm']):
 pivot=g.pivot(index='seed',columns='w',values='y');w=pivot.columns.to_numpy(float);k=pivot.sum(0).to_numpy();n=np.full(len(w),10);f=firth(w,k,n);x=np.column_stack([np.ones(len(w)),w]);start=[f['b0'][0],f['b1'][0]]
 def obj(b):
  eta=x@b;prob=expit(eta);info=x.T@((n*prob*(1-prob))[:,None]*x);sgn,ld=np.linalg.slogdet(info)
  return np.sum(n*np.logaddexp(0,eta)-k*eta)-.5*ld if sgn>0 else 1e100
 opt=minimize(obj,start,method='Nelder-Mead',options={'maxiter':3000,'xatol':1e-9,'fatol':1e-10});wc=-opt.x[0]/opt.x[1];assert opt.success and abs(wc-f['wcrit'][0])<1e-5
 values=[]
 for seed in seeds:
  data=pivot.drop(index=seed);b=firth(w,data.sum(0).to_numpy(),np.full(len(w),9));v=b['wcrit'][0];values.append(v);leave[kind,t,arm,seed]=v
 rows.append(dict(kind=kind,budget=t,arm=arm,w50=f['wcrit'][0],independent_solver_w50=wc,solver_difference=wc-f['wcrit'][0],leave_one_seed_min=min(values),leave_one_seed_max=max(values)))
pd.DataFrame(rows).to_csv(out/'solver_and_seed_sensitivity.csv',index=False)
contrasts=[]
for kind,t in sorted(set((k[0],k[1]) for k in leave)):
 pairs=[('A','S'),('A','B'),('S','B')] if kind=='control' else [('lambda7','curvature')]
 for hi,lo in pairs:
  v=[leave[kind,t,hi,s]-leave[kind,t,lo,s] for s in seeds];contrasts.append(dict(kind=kind,budget=t,contrast=hi+'-'+lo,leave_one_seed_min=min(v),leave_one_seed_max=max(v)))
pd.DataFrame(contrasts).to_csv(out/'contrast_seed_sensitivity.csv',index=False)
fits=pd.read_csv(out/'fit_diagnostics.csv');result=dict(independent_optimizer_point_checks=len(rows),max_solver_difference=max(abs(r['solver_difference']) for r in rows),bootstrap_outside_grid_total=int(fits.outside_grid.sum()),zero_width_intervals=int(np.isclose(fits.ci_low,fits.ci_high).sum()),note='Outside-grid bootstrap estimates are retained, not clipped or dropped. Leave-one-seed ranges are influence diagnostics, not confidence intervals.')
(out/'fit_sensitivity_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));print(pd.DataFrame(contrasts).to_string(index=False))
