from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'experiments'))
from reward_diagnostics import moments,phi,transform,scale_constant
import numpy as np
u=np.array([-4.,-1.,0.,1.,4.]);b=phi(u);a=transform(u,'A')
np.testing.assert_allclose(a[:2],7*b[:2]);np.testing.assert_allclose(a[2:],b[2:]);assert a[2]==0
neg=-np.geomspace(.001,1000,100);np.testing.assert_allclose(transform(neg,'A'),7*phi(neg));assert abs(scale_constant(neg)-7)<1e-12
np.testing.assert_allclose(transform(neg,'N',7),phi(neg));np.testing.assert_allclose(transform(neg,'S',7),transform(neg,'A'))
c=scale_constant(u);assert 1<c<7
np.testing.assert_allclose(np.mean(transform(u,'S',c)**2),np.mean(a*a))
p= moments(u);assert p['positive']==.4 and p['negative']==.4 and p['zero']==.2
state=np.random.get_state();moments(u);post=np.random.get_state();assert np.array_equal(state[1],post[1]) and state[2:]==post[2:]
print('PASS: signed/zero transforms, exact negative-support scalar equivalence, RMS calibration, sign fractions and RNG independence')
