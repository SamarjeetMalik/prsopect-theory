"""Scope-study reanalysis; fixed-label seed-block Firth fits, no new training."""
from pathlib import Path
import hashlib,json,os
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/aamas-matplotlib')
import numpy as np,pandas as pd
from boundary import firth
from reanalyze import matrices
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'AAMAS2027/generated/pointers36_40';OUT.mkdir(parents=True,exist_ok=True)
a=ROOT/'docs/expCascade_continuous_figures/cascade_continuous_raw_data.csv';b=ROOT/'AAMAS2027/generated/canonical_runs.csv'
c=pd.read_csv(a);d=pd.read_csv(b);c['y']=((c.mean_S<10)&(c.profit<=-127.1)).astype(int)
assert len(c)==1100 and not c.duplicated(['cell_tag','w','seed']).any()
assert (c.y==c.collapsed.astype(int)).all()
h=d[(d.setting=='supply_ppo')&(d.condition=='lambda7')].copy();grid=sorted(c.w.unique());seeds=list(range(42,62))
rng=np.random.default_rng(20260928);weights=rng.multinomial(20,np.full(20,.05),size=2000);ind=rng.multinomial(20,np.full(20,.05),size=2000)
rows=[];draws={};points={};observations=[]
sets={tag:g for tag,g in c.groupby('cell_tag')};sets['homogeneous_full']=h;sets['homogeneous_common']=h[h.w.isin(grid)]
for name,g in sets.items():
 assert set(g.seed)==set(seeds) and all(g.groupby('w').size()==20)
 w,k,n=matrices(g,seeds);p=firth(w,k.sum(0),n.sum(0));z=firth(w,weights@k,weights@n);ok=np.isfinite(z['wcrit']);ci=np.percentile(z['wcrit'][ok],[2.5,97.5]);points[name]=float(p['wcrit'][0]);draws[name]=z['wcrit']
 rows.append(dict(arm=name,n=len(g),wcrit=points[name],ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum()),status=p['status'][0],in_grid=bool(p['in_grid'][0])))
 pd.DataFrame(z).to_csv(OUT/f'bootstrap_{name}.csv',index=False)
 observations.extend(dict(arm=name,w=float(x),k=int(kk),n=int(nn)) for x,kk,nn in zip(w,k.sum(0),n.sum(0)))
results=pd.DataFrame(rows);results.to_csv(OUT/'scope_boundaries.csv',index=False);pd.DataFrame(observations).to_csv(OUT/'scope_cells.csv',index=False)
contrasts=[]
for single in ['posA_node_2','lamB_node_2_L7']:
 for base in ['homogeneous_full','homogeneous_common']:
  g=sets[base];w,k,n=matrices(g,seeds);indboot=firth(w,ind@k,ind@n)['wcrit']
  for mode,z in [('paired',draws[single]-draws[base]),('independent',draws[single]-indboot)]:
   good=np.isfinite(z);ci=np.percentile(z[good],[2.5,97.5]);contrasts.append(dict(single=single,baseline=base,resampling=mode,difference=points[single]-points[base],ci_low=ci[0],ci_high=ci[1],usable=int(good.sum())))
   pd.DataFrame({'difference':z}).to_csv(OUT/f'difference_{single}_{base}_{mode}.csv',index=False)
contrast=pd.DataFrame(contrasts);contrast.to_csv(OUT/'scope_contrasts.csv',index=False)
r=contrast[(contrast.single=='posA_node_2')&(contrast.baseline=='homogeneous_full')&(contrast.resampling=='paired')].iloc[0]
s=results[results.arm=='posA_node_2'].iloc[0]
(OUT/'numbers.tex').write_text('\\newcommand{\\MinorityDifference}{$%+.3f$ $[%+.3f,%+.3f]$}\n\\newcommand{\\MinorityMidpoint}{$%.3f$ $[%.3f,%.3f]$}\n'%(r.difference,r.ci_low,r.ci_high,s.wcrit,s.ci_low,s.ci_high))
lines=[r'\begin{table}[t]',r'\caption{Single node 2 minus homogeneous $\lambda=7$: revised Firth differences with 2,000 seed-block draws. Other nodes have $\lambda=1$, $\alpha=\beta=.88$. Full uses all homogeneous refinement cells; common uses only the five shared $w$ cells. Same integer seeds do not establish matched historical simulator streams; independent resampling is a sensitivity check. Intervals are not equivalence tests.}',r'\label{tab:minority_difference}',r'\centering\small',r'\begin{tabular}{llcc}',r'\toprule Grid & Resampling & Difference [95\% CI] & Usable \\',r'\midrule']
for x in contrast[contrast.single=='posA_node_2'].itertuples():lines.append(f"{x.baseline.replace('homogeneous_','')} & {x.resampling} & ${x.difference:+.3f}$ $[{x.ci_low:+.3f},{x.ci_high:+.3f}]$ & {x.usable} \\\\")
lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}'];(OUT/'minority_difference.tex').write_text('\n'.join(lines)+'\n')
plt.rcParams.update({'font.size':8,'pdf.fonttype':42})
fig,axes=plt.subplots(2,1,figsize=(3.35,4.3),layout='constrained')
p=results[results.arm.str.startswith('posA')].copy();x=np.arange(len(p));axes[0].errorbar(x,p.wcrit,yerr=[p.wcrit-p.ci_low,p.ci_high-p.wcrit],fmt='o',capsize=3);axes[0].set_xticks(x,[n.replace('posA_','') for n in p.arm]);axes[0].set_title('Single-node position (shared actor)')
p=results[results.arm.str.startswith('lamB')].copy();x=[int(n.split('_L')[-1]) for n in p.arm];axes[1].errorbar(x,p.wcrit,yerr=[p.wcrit-p.ci_low,p.ci_high-p.wcrit],fmt='o-',capsize=3);hh=results[results.arm=='homogeneous_full'].iloc[0];axes[1].axhline(hh.wcrit,ls='--',color='gray');axes[1].axhspan(hh.ci_low,hh.ci_high,color='gray',alpha=.15);axes[1].set_xlabel('Node 2 loss multiplier λ');axes[1].set_title('Dose sweep; dashed = homogeneous λ=7')
for ax in axes:ax.set_ylabel('Fitted midpoint w₅₀')
fig.savefig(OUT/'minority_revised.pdf',bbox_inches='tight');plt.close(fig)
(OUT/'provenance.json').write_text(json.dumps(dict(bootstrap_seed=20260928,replicates=2000,inputs={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [a,b]},scope='Post-review descriptive scope study. Separate posA and lamB replicates are not pooled. Historical stream matching unverified; no equivalence margin or test.',fit_count=len(rows)),indent=2))
print(contrast.to_string(index=False))
