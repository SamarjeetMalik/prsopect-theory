"""Fixed-design retrospective decimation and nominal-unit coordinate checks."""
from pathlib import Path
import json,hashlib,time
import numpy as np,pandas as pd
from boundary import firth
from reanalyze import matrices
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'generated/pointers26_35';OUT.mkdir(exist_ok=True)
SEED=20260927;B=500;REPEATS=200
D=pd.read_csv(ROOT/'generated/canonical_runs.csv',keep_default_na=False)
rng=np.random.default_rng(SEED);rows=[];start=time.time()
for setting,end in [('supply_ppo','lambda7'),('supply_mappo','lambda7'),('mpe_mappo','lambda7'),('lbf_mappo','lambda4')]:
 for condition in ['lambda1',end]:
  g=D[(D.setting==setting)&(D.condition==condition)];seeds=sorted(g.seed.unique());w,k,n=matrices(g,seeds);full=firth(w,k.sum(0),n.sum(0))['wcrit'][0]
  choices={s:([np.arange(len(seeds))] if s==len(seeds) else [np.sort(rng.choice(len(seeds),s,replace=False)) for _ in range(REPEATS)]) for s in [5,10,20]}
  for name,idx in [('full',np.arange(len(w))),('even',np.unique(np.r_[0,np.arange(1,len(w)-1,2),len(w)-1])),('odd',np.unique(np.r_[0,np.arange(2,len(w)-1,2),len(w)-1]))]:
   for ns,subsets in choices.items():
    # Batch 20 independent subsets at a time; CI resamples selected seed blocks.
    for begin in range(0,len(subsets),20):
     batch=subsets[begin:begin+20];kk=[];nn=[];points=[]
     for sub in batch:
      ks=k[sub][:,idx];nt=n[sub][:,idx];weights=rng.multinomial(ns,np.ones(ns)/ns,size=B)
      kk.append(weights@ks);nn.append(weights@nt);points.append((ks.sum(0),nt.sum(0)))
     fit=firth(w[idx],np.vstack(kk),np.vstack(nn));point=firth(w[idx],np.stack([p[0] for p in points]),np.stack([p[1] for p in points]))
     for j,sub in enumerate(batch):
      z=fit['wcrit'][j*B:(j+1)*B];ok=np.isfinite(z);ci=np.percentile(z[ok],[2.5,97.5]) if ok.any() else [np.nan,np.nan];counts=points[j][1];prop=np.divide(points[j][0],counts,out=np.full(len(counts),np.nan),where=counts>0)
      bracket=bool(np.nanmin(prop)<=.5<=np.nanmax(prop))
      rows.append(dict(setting=setting,condition=condition,rule=name,seeds=ns,replicate=begin+j,seed_ids=json.dumps([int(seeds[x]) for x in sub]),grid=json.dumps(w[idx].tolist()),runs=int(counts.sum()),full_runs=len(g),reduction=1-counts.sum()/len(g),wcrit=point['wcrit'][j],full_wcrit=full,absolute_error=abs(point['wcrit'][j]-full),ci_low=ci[0],ci_high=ci[1],ci_width=ci[1]-ci[0],usable_bootstrap=int(ok.sum()),bootstrap_outside_grid=int((ok&~fit['in_grid'][j*B:(j+1)*B]).sum()),bracket=bracket,status=point['status'][j],in_grid=point['in_grid'][j]))
   print(setting,condition,name,'done',round(time.time()-start),flush=True)
  pd.DataFrame(rows).to_csv(OUT/'decimation_replicates.csv',index=False)
R=pd.DataFrame(rows);summ=[]
for key,g in R.groupby(['setting','condition','rule','seeds']):
 row=dict(zip(['setting','condition','rule','seeds'],key),replicates=len(g),median_runs=g.runs.median(),run_reduction=g.reduction.mean(),failure_to_bracket=1-g.bracket.mean(),invalid_fit=(g.status!='ok').mean(),point_outside_grid=1-g.in_grid.mean(),median_error=g.absolute_error.median(),p90_error=g.absolute_error.quantile(.9),median_ci_width=g.ci_width.median(),median_usable_bootstrap=g.usable_bootstrap.median());summ.append(row)
pd.DataFrame(summ).to_csv(OUT/'decimation_summary.csv',index=False)
# Common q coordinate, bootstrap within arm and paired across seed identifiers.
C=pd.read_csv(ROOT/'generated/pointers16_25/control_diagnostic_runs.csv',keep_default_na=False);C=C[C.control=='C'].copy();C['y']=((C.mean_S<10)&(C.profit<=-127.1)).astype(int)
seeds=list(range(42,62));rng=np.random.default_rng(SEED);weights=rng.multinomial(20,np.full(20,.05),size=2000);qr=[];qd=[];saved={}
for (arm,lam),g in C.groupby(['arm','lambda_loss']):
 w,k,n=matrices(g,seeds);p=firth(w,k.sum(0),n.sum(0));b=firth(w,weights@k,weights@n);cl=float(g.input_local_scale.iloc[0]);cg=float(g.input_global_scale.iloc[0])
 def q(v):return v*cg/((1-v)*cl+v*cg)
 # Out-of-[0,1] fits remain recorded and are not clipped; count explicitly.
 z=q(b['wcrit']);ok=np.isfinite(z);ci=np.percentile(z[ok],[2.5,97.5]);saved[arm,lam]=(q(p['wcrit'][0]),z)
 qr.append(dict(arm=arm,lambda_loss=lam,c_local=cl,c_global=cg,wcrit=p['wcrit'][0],q=q(p['wcrit'][0]),ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum()),bootstrap_outside_unit=int(((z<0)|(z>1)).sum())))
 for i,v in enumerate(z):qd.append(dict(arm=arm,lambda_loss=lam,replicate=i,q=v))
contr=[]
for lam in [1,3,7]:
 for arm in ['local2x','global2x']:
  p,z=saved[arm,lam];p0,z0=saved['baseline',lam];delta=z-z0;ok=np.isfinite(delta);ci=np.percentile(delta[ok],[2.5,97.5]);contr.append(dict(arm=arm,lambda_loss=lam,difference=p-p0,ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum())))
pd.DataFrame(qr).to_csv(OUT/'unit_coordinate.csv',index=False);pd.DataFrame(qd).to_csv(OUT/'unit_coordinate_draws.csv',index=False);pd.DataFrame(contr).to_csv(OUT/'unit_coordinate_differences.csv',index=False)
(OUT/'analysis_protocol.json').write_text(json.dumps(dict(seed=SEED,subset_repeats=REPEATS,bootstrap_per_subset=B,unit_bootstrap=2000,rules='retain endpoints and alternating ordered interior cells; even starts interior index1, odd index2; fixed before outcomes',seed_sampling='without replacement; same subsets across rules; 20 seeds has one possible subset',interpretation='descriptive agreement with full-data estimate, not ground-truth coverage or validation of adaptive grids',source_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'generated/canonical_runs.csv',ROOT/'generated/pointers16_25/control_diagnostic_runs.csv']}),indent=2))
print('Complete',len(R),'subset fits',flush=True)
