from pathlib import Path
import json,hashlib,math
import numpy as np,pandas as pd
from boundary import firth
root=Path(__file__).resolve().parents[1];out=root/'audit/final_diagnostics';out.mkdir(exist_ok=True)
dp=root/'orchestration_deadline_v1/design.json';design=json.loads(dp.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();frozen=json.loads((root/'instrumented_source_v2/SOURCE_MANIFEST.json').read_text())
assert sha(root/'instrumented_source_v2/SOURCE_MANIFEST.json')==design['source_manifest_sha256']
for p,digest in design['calibration_hashes'].items():assert sha(root/p)==digest
rows=[];inputs={};packages=[];sources=[];recordcount=0
for kind,nruns in [('control',240),('horizon',150)]:
 runs=sorted((root/f'new_runs/deadline_confirmation_v1/{kind}').glob('run_*'));assert len(runs)==nruns
 keys=[]
 for folder in runs:
  c=json.loads((folder/'protocol.json').read_text());lineage=json.loads((folder/'lineage.json').read_text());manifest=json.loads((folder/'manifest.json').read_text());done=json.loads((folder/'COMPLETE.json').read_text());arm=c['arm'] if kind=='control' else c['condition'];keys.append((arm,c['w'],c['seed']))
  assert c['phase']=='confirmation' and c['seed'] in design['seeds'];assert lineage['design_sha256']==sha(dp) and lineage['source_manifest_sha256']==design['source_manifest_sha256'];assert lineage['orchestrator_sha256']==sha(root/'orchestration_deadline_v1/run.py')
  packages.append(manifest['packages']);sources.append(manifest['sources'])
  for name,digest in manifest['sources'].items():assert frozen[name]==digest
  budget=design[kind+'_budget'];assert c['total_budget']==budget;assert c['checkpoints']==([budget] if kind=='control' else design['checkpoints']);assert done['requested']==budget and done['actual_transitions']==math.ceil(budget/640)*640
  if kind=='control':assert c['reference']==design['reference'] and c['c']==(7 if arm=='S' else 1)
  expected=[300000] if kind=='control' else design['checkpoints'];files=list(folder.glob('evaluation_*.json'));assert len(files)==len(expected)
  for t in expected:
   p=folder/f'evaluation_{t}.json';inputs[str(p.relative_to(root))]=sha(p);r=json.loads(p.read_text());recordcount+=1
   assert r['requested_checkpoint']==t and r['actual_agent_transitions']==math.ceil(t/640)*640
   for n in [10]+([50] if kind=='horizon' and t in [900000,1800000,3600000] else []):
    x=r if n==10 else r['sensitivity_50'];s=x['summary'];eps=x['episodes'];assert len(eps)==n
    assert [e['evaluation_seed'] for e in eps]==list(range(c['seed']*10,c['seed']*10+n))
    assert all(math.isfinite(v) for k,v in s.items() if isinstance(v,(float,int)))
    assert s['collapsed']==(s['mean_S']<10 and s['profit']<=-127.1)
    for metric in ['profit','mean_order','lost_sales','trajectory_mean_S']:assert math.isclose(np.mean([e[metric] for e in eps]),s[metric],rel_tol=1e-9,abs_tol=1e-9)
    rows.append(dict(kind=kind,arm=arm,w=c['w'],seed=c['seed'],budget=t,episodes=n,y=int(s['collapsed']),profit=s['profit']))
  for name in ['protocol.json','manifest.json','lineage.json','COMPLETE.json']:inputs[str((folder/name).relative_to(root))]=sha(folder/name)
 arms=design['control_arms'] if kind=='control' else design['horizon_conditions'];grid=design[kind+'_grid'];assert len(keys)==len(set(keys));assert set(keys)=={(a,w,s) for a in arms for w in grid for s in design['seeds']}
assert all(p==packages[0] for p in packages);assert all(s==sources[0] for s in sources)
f=pd.DataFrame(rows);f.to_csv(out/'validated_evaluations.csv',index=False);(out/'input_hashes.json').write_text(json.dumps(inputs,indent=2))
weights=np.random.default_rng(20260927).multinomial(10,np.full(10,.1),size=2000);fits={};boundaries=[];cells=[]
for key,g in f.groupby(['kind','budget','episodes','arm']):
 kind,t,ne,arm=key;weights=np.random.default_rng(20260927 if kind=='control' else 20260926).multinomial(10,np.full(10,.1),size=2000);grid=design[kind+'_grid'];k=g.pivot(index='seed',columns='w',values='y').reindex(index=design['seeds'],columns=grid).to_numpy();assert np.isfinite(k).all();n=np.ones_like(k);fit=firth(grid,k.sum(0),n.sum(0));boot=firth(grid,weights@k,weights@n);v=boot['wcrit'];ok=np.isfinite(v);ci=np.percentile(v[ok],[2.5,97.5]);prop=k.mean(0);brackets=[(a,b) for a,b,x,y in zip(grid[:-1],grid[1:],prop[:-1],prop[1:]) if min(x,y)<=.5<=max(x,y)]
 boundaries.append(dict(kind=kind,budget=t,episodes=ne,arm=arm,w50=fit['wcrit'][0],ci_low=ci[0],ci_high=ci[1],slope=fit['b1'][0],status=fit['status'][0],brackets=json.dumps(brackets),usable=int(ok.sum()),nonconverged=int((boot['status']=='nonconverged').sum()),outside_grid=int((ok&~boot['in_grid']).sum())))
 fits[key]=(fit['wcrit'][0],v)
 cells.extend(dict(kind=kind,budget=t,episodes=ne,arm=arm,w=w,k=int(z),n=10) for w,z in zip(grid,k.sum(0)))
contrasts=[]
for kind,t,ne in f[['kind','budget','episodes']].drop_duplicates().itertuples(index=False,name=None):
 if kind=='horizon' and t not in design['primary_budgets']:continue
 pairs=[('A','S'),('A','B'),('S','B')] if kind=='control' else [('lambda7','curvature'),('curvature','null')]
 for hi,lo in pairs:
  p,v=fits[kind,t,ne,hi];q,u=fits[kind,t,ne,lo];delta=v-u;ok=np.isfinite(delta);ci=np.percentile(delta[ok],[2.5,97.5]);contrasts.append(dict(kind=kind,budget=t,episodes=ne,contrast=hi+'-'+lo,difference=p-q,ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum())))
pd.DataFrame(boundaries).to_csv(out/'fit_diagnostics.csv',index=False);pd.DataFrame(cells).to_csv(out/'observed_cells.csv',index=False);pd.DataFrame(contrasts).to_csv(out/'checked_contrasts.csv',index=False)
h=f[f.kind=='horizon'];p=h.pivot(index=['arm','w','seed','budget'],columns='episodes',values='y').dropna();changed=int((p[10]!=p[50]).sum())
report=dict(runs=390,evaluation_files=recordcount,evaluations_including_50=len(f),configuration_and_calibration_hashes='PASS',paired_seed_panels='PASS',counters_labels_episode_seeds_and_aggregates='PASS',matching_package_and_source_records='PASS',sensitivity_comparisons=len(p),sensitivity_labels_changed=changed,fit_count=len(boundaries),point_fit_failures=sum(r['status']!='ok' for r in boundaries),unbracketed_point_fits=sum(r['brackets']=='[]' for r in boundaries),bootstrap_nonconverged=sum(r['nonconverged'] for r in boundaries))
(out/'evaluation_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
