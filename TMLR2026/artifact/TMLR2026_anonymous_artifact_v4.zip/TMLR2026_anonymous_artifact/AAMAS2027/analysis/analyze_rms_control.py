from pathlib import Path
import numpy as np,pandas as pd,json,hashlib
from boundary import firth
from reanalyze import matrices
root=Path(__file__).resolve().parents[1];out=root/'generated/pointers26_35'
p=root/'generated/pointers16_25/control_diagnostic_runs.csv';d=pd.read_csv(p,keep_default_na=False);d=d[d.control=='B'].copy();d['y']=((d.mean_S<10)&(d.profit<=-127.1)).astype(int)
weights=np.random.default_rng(20260927).multinomial(20,np.full(20,.05),size=2000);fits={};rows=[];diffs=[]
for (arm,lam),g in d.groupby(['arm','lambda_loss']):
 w,k,n=matrices(g,list(range(42,62)));point=firth(w,k.sum(0),n.sum(0));boot=firth(w,weights@k,weights@n);v=boot['wcrit'];ok=np.isfinite(v);ci=np.percentile(v[ok],[2.5,97.5]);fits[arm,lam]=(point['wcrit'][0],v)
 rows.append(dict(arm=arm,lambda_loss=lam,wcrit=point['wcrit'][0],ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum()),mean_pretransform_reward_sd=g.reward_std.mean(),mean_within_policy_return_sd=g.return_std.mean(),nonnegative_fraction=g.frac_gain.mean()))
for arm in ['raw','stdmatched']:
 a,x=fits[arm,1];b,y=fits[arm,7];delta=y-x;ok=np.isfinite(delta);ci=np.percentile(delta[ok],[2.5,97.5]);diffs.append(dict(arm=arm,difference=b-a,ci_low=ci[0],ci_high=ci[1],usable=int(ok.sum())))
pd.DataFrame(rows).to_csv(out/'rms_control_refits.csv',index=False);pd.DataFrame(diffs).to_csv(out/'rms_control_differences.csv',index=False)
(out/'rms_control_interpretation.json').write_text(json.dumps(dict(verdict='residual under fixed per-lambda pilot divisors; achieved on-policy RMS/advantage match and unique asymmetry attribution not established',pilot='separate lambda1/3/7 policies;20k;w=.5,.95;seed42;300 samples/lambda',divisors=[1,2.1511233456527563,4.0188992038279],sd_fields='means of per-policy pre-transform blend SD and within-policy return SD; not pooled variances',source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2))
print(pd.DataFrame(diffs).to_string(index=False))
