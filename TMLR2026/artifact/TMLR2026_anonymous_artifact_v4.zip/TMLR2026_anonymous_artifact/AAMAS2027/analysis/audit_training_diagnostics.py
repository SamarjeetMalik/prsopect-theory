"""Read-only full-stream audit and sufficient-statistic aggregation of completed training."""
from pathlib import Path
import argparse,json,gzip,math,collections
p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--worker',type=int,required=True);a=p.parse_args();root=Path(a.root)
paths=sorted((root/'new_runs/deadline_confirmation_v1/control').glob('run_*'))+sorted((root/'new_runs/deadline_confirmation_v1/horizon').glob('run_*'))
assert len(paths)==390
out=root/'audit/final_diagnostics/remote';out.mkdir(parents=True,exist_ok=True)
def add(acc,key,m):
 n=m['count'];v=[n,n*m['mean'],n*m['rms']**2,n*m['positive'],n*m['zero'],n*m['negative']]
 assert all(math.isfinite(x) for x in v) and math.isfinite(m['std'])
 assert abs(m['positive']+m['zero']+m['negative']-1)<1e-6
 z=acc.setdefault(key,[0.]*6)
 for i,x in enumerate(v):z[i]+=x
for idx in range(a.worker,len(paths),32):
 folder=paths[idx];cfg=json.loads((folder/'protocol.json').read_text());done=json.loads((folder/'COMPLETE.json').read_text());total=done['actual_transitions'];acc={};updates={};evnan=0;errors=[]
 try:
  for kind in ['rollouts','updates']:
   count=0
   with gzip.open(folder/f'diagnostics/{kind}.jsonl.gz','rt') as f:
    for line in f:
     r=json.loads(line);count+=1;t=r['actual_transitions'];assert t==count*640
     windows=['all']+(['late'] if t>total/2 else [])
     if kind=='rollouts':
      assert len(r['groups'])==6
      for g in r['groups']:
       assert g['rewards']['centered']['count']==(640 if g['agent']=='pooled' else 128)
       for metric in ['centered','transformed','advantages_buffer','returns_buffer']:
        m=g[metric] if metric.endswith('_buffer') else g['rewards'][metric]
        for window in windows:add(acc,(window,g['agent'],metric),m)
     else:
      assert r['n_updates']==count*10 and len(r['minibatches'])==30
      if not math.isfinite(r['explained_variance']):evnan+=1
      for b in r['minibatches']:
       for window in windows:
        for metric in ['raw_advantage','normalized_advantage','return_target']:add(acc,(window,'optimizer',metric),b[metric])
        z=updates.setdefault(window,dict(n=0,clipped=0,max_normalized_mean=0.,max_normalized_std_error=0.,constant_normalized=0,**{k:0. for k in ['value_loss','approx_kl','clip_fraction','entropy','actor_grad_norm','critic_grad_norm','total_grad_norm']}));z['n']+=1;z['clipped']+=int(b['gradient_clipped'])
        m=b['normalized_advantage'];z['max_normalized_mean']=max(z['max_normalized_mean'],abs(m['mean']))
        if m['std']<1e-6:z['constant_normalized']+=1
        else:z['max_normalized_std_error']=max(z['max_normalized_std_error'],abs(m['std']-math.sqrt((m['count']-1)/m['count'])))
        for k in ['value_loss','approx_kl','clip_fraction','entropy','actor_grad_norm','critic_grad_norm','total_grad_norm']:
         assert math.isfinite(b[k]);z[k]+=b[k]
   assert count==total//640,(kind,count,total)
 except Exception as e:errors.append(repr(e))
 rows=[]
 for (window,agent,metric),v in acc.items():
  n,sm,ss,pos,zero,neg=v;mean=sm/n;rows.append(dict(window=window,agent=agent,metric=metric,count=int(n),mean=mean,std=math.sqrt(max(0,ss/n-mean*mean)),rms=math.sqrt(ss/n),positive=pos/n,zero=zero/n,negative=neg/n))
 result=dict(kind=folder.parent.name,run=folder.name,config=cfg,actual=total,errors=errors,explained_variance_nonfinite=evnan,metrics=rows,optimizer=updates)
 (out/f'{folder.parent.name}_{folder.name}.json').write_text(json.dumps(result,indent=2));print(idx,folder.parent.name,folder.name,'PASS' if not errors else errors,flush=True)
