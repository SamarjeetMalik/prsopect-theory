from pathlib import Path
import json,datetime
import pandas as pd
r=Path(__file__).resolve().parents[1];p=r/'audit/final_diagnostics';e=json.loads((p/'evaluation_audit.json').read_text());t=json.loads((p/'training_audit.json').read_text());assert t['training_runs_audited']==390 and not t['errors'];m=pd.read_csv(p/'training_moments_by_arm.csv');o=pd.read_csv(p/'optimizer_by_arm.csv');cells=pd.read_csv(p/'training_moments_by_cell.csv');fit=pd.read_csv(p/'fit_diagnostics.csv',keep_default_na=False)
text=f'''# Final diagnostic checks

Completed {datetime.datetime.now().astimezone().isoformat()}.

## Scope and outcome

The 150 frozen-design horizon trajectories and 240 direct-control runs pass the configuration, evaluation and full training-log integrity checks. This audit does not certify old AAAI runs or supply-MAPPO/LBF training-sign fractions. No training outcomes were dropped or altered.

## Integrity and statistical checks

- All390 run configurations, source/package records, frozen-design hashes, calibration-input hashes and disjoint confirmation seed panels agree. The empirical reference recomputes to -2.6281398333333335 from60,000 independent calibration samples.
- All3,840 evaluation files pass actual-transition counters, evaluation seeds, label definitions, finite summaries and episode-to-summary aggregation. The450 additional50-episode evaluations have one label change: curvature-only,w=.4,seed51,900k. The1.8M and3.6M labels are unchanged.
- All84 point fits converge and have observed cells bracketing .5. All2,000 bootstrap fits per panel are identified and converged. The original primary confidence intervals reproduce exactly with their original random seeds.
- An independent numerical optimizer reproduces all15 primary-budget/control point estimates within4e-9. Removing one seed leaves the3.6M loss-multiplier-minus-curvature point difference positive, ranging+.116 to+.163. The asymmetric-minus-symmetric point difference remains negative, from-.086 to-.034; these influence ranges are not confidence intervals.
- All150 longitudinal label sequences and three-checkpoint sustained-recovery endpoints were independently checked.
- Full training logs: {t['rollout_records']:,} rollout records, {t['optimizer_updates']:,} updates and {t['optimizer_minibatches']:,} optimizer minibatches. No missing counter sequence or invalid finite reward/advantage/loss/gradient statistic was found. Nonfinite explained-variance entries: {t['nonfinite_explained_variance']}.

## Required qualifications

1. Eleven horizon fit/episode-count combinations have zero-width seed-bootstrap intervals because all ten seeds have identical cell labels. These are lambda7 checkpoints at600k,750k,900k,1.05M,1.2M,1.35M,1.5M,1.8M and2.55M (900k/1.8M also appear under50-episode evaluation). Their empirical crossing bracket is[.6,.85]; zero bootstrap width is not zero location uncertainty. Show the bracket and flag degeneracy in manuscript displays.
2. Bootstrap draws outside the sampled grid are retained:743/2,000 at the150k lambda7 checkpoint,4/2,000 for the symmetric control, and four other single-draw occurrences. The150k checkpoint is outside the four primary-budget comparisons. Do not clip these intervals.
3. Logistic/probit maximum-likelihood fits encounter separation for some cells. Isotonic point comparisons retain the key directions:3.6M loss-multiplier minus curvature+.160; asymmetric minus symmetric-.043. Across estimators the largest primary-budget spread is .080 at linear-null1.8M. This is model sensitivity, not an alternative calibrated confidence interval.
4. Ordinary95% intervals are pointwise, not a simultaneous band across budgets. None of the conditions meets the declared late-change equivalence criterion of an entire interval inside[-.02,.02]. No asymptote or convergence is established.

## Observed training distributions

These are descriptive, count-weighted pooled moments across the eight control mixture cells and ten seeds over300,160 actual transitions per run. Optimizer minibatches are repeated observations, not independent inferential replicates. Per-agent, per-cell and late-half summaries are in the accompanying CSVs.

| Control | Loss-branch fraction | Gain fraction | Transformed reward RMS | Raw GAE SD | Normalized optimizer advantage SD | Gradient-clipped batches |
|---|---:|---:|---:|---:|---:|---:|
'''
for arm,label in [('B','Curvature-only'),('A','Losses ×7'),('S','Both branches ×7')]:
 g=m[(m.kind=='control')&(m.arm==arm)&(m.window=='all')];center=g[(g.agent=='pooled')&(g.metric=='centered')].iloc[0];reward=g[(g.agent=='pooled')&(g.metric=='transformed')].iloc[0];gae=g[(g.agent=='pooled')&(g.metric=='advantages_buffer')].iloc[0];norm=g[(g.agent=='optimizer')&(g.metric=='normalized_advantage')].iloc[0];opt=o[(o.kind=='control')&(o.arm==arm)&(o.window=='all')].iloc[0]
 text+=f'| {label} | {center.negative:.3%} | {center.positive:.3%} | {reward.rms:.3f} | {gae["std"]:.3f} | {norm["std"]:.6f} | {opt.clipping_fraction:.3%} |\n'
text+='\nNear-crossing loss/gain coverage is measured separately for each arm using its empirical bracketing cells:\n\n'
for arm in ['B','A','S']:
 b=fit[(fit.kind=='control')&(fit.arm==arm)].iloc[0];ws=sorted(set(w for pair in json.loads(b.brackets) for w in pair));g=cells[(cells.kind=='control')&(cells.arm==arm)&cells.w.isin(ws)&(cells.window=='all')&(cells.agent=='pooled')&(cells.metric=='centered')];n=g['count'].sum();neg=(g['count']*g.negative).sum()/n;pos=(g['count']*g.positive).sum()/n;text+=f'- {arm},w={ws}: losses{neg:.3%},gains{pos:.3%}.\n'
text+='''
Every recorded control minibatch triggered global gradient clipping. Mean critic gradient norms were approximately 1,305 (B), 3,622 (A), and 12,267 (S), versus actor norms of 2.04, 1.73, and 1.50. Because the frozen learner clips the combined gradient norm, critic magnitude can affect the actor update even when advantages are normalized. This is a plausible optimizer-scaling pathway, not a causal isolation of why the boundary moved. No optimizer settings were changed during the audit.

## Scientific conclusion and remaining work

The finite-budget crossing shift persists in independent confirmation at3.6M: +.146[.072,.229] relative to curvature-only. It is unchanged by50-episode evaluation. The direct asymmetric-minus-symmetric contrast remains -.062[-.157,.028]: no asymmetry-specific effect is established and equivalence is not established either. Both reward RMS and raw advantage distributions must be reported alongside the near-unit normalized advantages; normalization alone is not a reward-scaling control.

Manuscript integration and the separate LBF/supply-MAPPO loss-branch measurements remain open. They are not marked completed by this audit.
'''
(p/'FINAL_DIAGNOSTIC_REPORT.md').write_text(text)
print(text[text.index('## Observed training distributions'):])
