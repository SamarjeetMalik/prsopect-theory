"""Render deadline revision from saved estimates; do not change fitted results."""
from pathlib import Path
import os,json
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/aamas-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
root=Path(__file__).resolve().parents[1]; out=root/'generated'; dest=out/'deadline_revision'
f=pd.read_csv(out/'boundary_estimates.csv',keep_default_na=False)
plt.rcParams.update({'font.size':8,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(6.8,3.3),layout='constrained')
for setting,label,color,marker in [('supply_ppo','Supply PPO','#187b37','o'),('supply_mappo','Supply MAPPO','#2072ac','s'),('lbf_mappo','LBF MAPPO','#ca7920','^')]:
 d=f[(f.setting==setting)&(f.condition!='null')].sort_values('lambda_loss')
 if setting=='lbf_mappo':d=d[d.lambda_loss<=6]
 ax.errorbar(d.lambda_loss,d.wcrit,yerr=[d.wcrit-d.ci_low,d.ci_high-d.wcrit],fmt=marker+'-',lw=.8,ms=4,capsize=2,color=color,label=label)
ax.axhline(.95,color='.6',ls=':',lw=.7)
ax.set(xlabel='Loss multiplier λ',ylabel='Finite-budget crossing w₅₀',xticks=range(1,8),ylim=(.1,1.04));ax.legend(loc='lower right')
for ext in ['pdf','png']:fig.savefig(out/f'generalization_main.{ext}',dpi=180,bbox_inches='tight')
plt.close(fig)
s=(out/'endpoint_table.tex').read_text();s='\n'.join(l for l in s.splitlines() if not l.startswith('MPE MAPPO'))+'\n'
s=s.replace(' MPE is descriptive only because its historical configurations are unresolved.','')
(out/'endpoint_table_main.tex').write_text(s)
p=pd.read_csv(dest/'pilot_analysis/longitudinal_contrasts.csv');p=p[p.contrast=='lambda7-curvature']
rows=[f'{int(r.requested)//1000}k & ${r.difference:+.3f}$ & $[{r.ci_low:+.3f},{r.ci_high:+.3f}]$ '+r'\\' for r in p.itertuples()]
s=r'''\begin{table}[t]
\centering\small
\caption{Descriptive pilot contrasts: loss-multiplier 7 minus curvature-only crossing, with 2,000 paired seed-block bootstrap draws. Five pilot seeds; not independent confirmation.}
\label{tab:extended_pilot}
\begin{tabular}{rrl}\toprule
Budget & Difference & 95\% interval \\\midrule
'''+ '\n'.join(rows)+r'''
\bottomrule\end{tabular}\end{table}
The positive pilot contrast at 1.8M is attenuated at 3.6M, where its interval includes zero (Table~\ref{tab:extended_pilot}). None of the three conditions meets the prespecified criterion that the entire interval for the 3.6M-minus-1.8M boundary change lies within $[-.02,.02]$. These observations establish neither a plateau nor a persistent transformation effect across budgets. Five-seed bootstrap intervals are descriptive; coincident label patterns can produce zero-width intervals and do not imply zero population uncertainty.
'''
(dest/'pilot_summary.tex').write_text(s)
g=json.loads((root/'new_runs/pilot_v2_sign_gate.json').read_text())['pooled_and_per_agent']['pooled']
s=(r'In the curvature-only supply PPO pilot at reference zero, the two cells $w=.6,.7$ over training through 300k contribute '+f'{g["count"]:,}'+r' agent rewards: '+f'{100*g["negative"]:.3f}'+r'\% fall below the reference, '+f'{100*g["positive"]:.3f}'+r'\% above, and '+f'{100*g["zero"]:.3f}'+r'\% equal it. This is measured training support for this pilot cohort, not a loss-branch estimate for other algorithms or transformations. '+'\n\n'+r'LBF native food rewards are nonnegative, but the local training reward subtracts $.02$ for a LOAD action. An unsuccessful LOAD with no food collected gives blended reward $-.02(1-w)$, so the loss branch can be active for $w<1$. Training sign counts were not retained in the available LBF or supply MAPPO aggregate records; their fractions cannot be inferred from episode returns. The MPE reward construction is nonpositive at reference zero, making its loss multiplier a scalar control. Actual zero-versus-negative frequencies are not reconstructed from aggregate returns.'+'\n')
(dest/'loss_support.tex').write_text(s)
body=root/'content/main-body.tex';s=body.read_text().replace('A historical five-cell','A five-cell');body.write_text(s)
supp=root/'content/supplement-body.tex';s=supp.read_text();label='fig:full_exploratory_endpoints'
if label not in s:s+='\n'+r'''\begin{figure*}[t]
\centering\includegraphics[width=.85\textwidth]{generated/generalization_revised.pdf}
\caption{Full exploratory endpoint display, including the MPE scaling-only comparison and the extrapolated LBF $\lambda=7$ crossing. Estimates and intervals are untruncated. The LBF $\lambda=7$ midpoint lies outside the sampled mixture range and is excluded from the main comparison figure. MPE configuration limitations are described in the exploratory transfer section.}
\label{fig:full_exploratory_endpoints}
\end{figure*}
'''
supp.write_text(s)
print('Rendered main figure, main endpoint table, pilot contrasts and reward-sign disclosure.')
