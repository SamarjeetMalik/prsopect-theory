import json,tempfile
from pathlib import Path
from pilot_grid_gate import inspect,WS,CONDITIONS
with tempfile.TemporaryDirectory() as temp:
 root=Path(temp)
 assert inspect([root])['status'].startswith('incomplete')
 for c in CONDITIONS:
  for w in WS:
   for s in range(100,105):
    folder=root/f'{c}_{w}_{s}';folder.mkdir()
    cfg=dict(condition=c,w=w,seed=s,phase='pilot',version='explicit-demand-v2',checkpoints=list(range(150000,3600001,150000)))
    (folder/'protocol.json').write_text(json.dumps(cfg));(folder/'manifest.json').write_text(json.dumps({'v2_sources':{'test':'constant'}}))
    for t in cfg['checkpoints']:
     collapsed=w>=.4;profit=-128 if collapsed else -100
     summary=dict(profit=profit,mean_order=0,lost_sales=0,trajectory_mean_S=0,mean_S=0,collapsed=collapsed)
     def report(n):return dict(summary=summary,episodes=[dict(evaluation_seed=10*s+i,profit=profit,mean_order=0,lost_sales=0,trajectory_mean_S=0) for i in range(n)])
     r=dict(**report(10),requested_checkpoint=t,actual_agent_transitions=((t+639)//640)*640,elapsed_seconds=1)
     if t in [900000,1800000,3600000]:r['sensitivity_50']=report(50)
     (folder/f'evaluation_{t}.json').write_text(json.dumps(r))
 result=inspect([root]);assert result['added_w']==.2 and result['selected_bracket']['condition']=='null' and result['selected_bracket']['budget']==150000
 assert result['validated_records']==2520 and result['required_refinement_trajectories']==15
 try:inspect([root,root])
 except ValueError as e:assert 'Duplicate' in str(e)
 else:raise AssertionError('duplicate not rejected')
 p=next(root.rglob('evaluation_300000.json'));r=json.loads(p.read_text());r['actual_agent_transitions']=300000;p.write_text(json.dumps(r))
 try:inspect([root])
 except ValueError as e:assert 'Counter mismatch' in str(e)
 else:raise AssertionError('bad counter not rejected')
print('PASS missing, complete, widest-bracket tie-breaking, duplicates, and counter guards')
