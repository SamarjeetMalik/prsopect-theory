"""Read-only scan; emits only timing/provenance fields, not arbitrary log contents."""
from pathlib import Path
import re,json,hashlib,subprocess
root=Path.home()/'prospect-theory';paths=sorted(set([p for p in root.glob('*') if p.is_file() and re.search(r'\.[oe]\d',p.name)]+[p for p in (root/'logs').glob('*') if p.is_file()]))
rows=[];counts=dict(files=len(paths),nonempty=0,with_progress_timing=0)
for p in paths:
 if not p.stat().st_size:continue
 counts['nonempty']+=1
 with p.open('rb') as f:
  f.seek(max(0,p.stat().st_size-2000000));data=f.read()
 s=data.decode(errors='replace');times=re.findall(r'time_elapsed\s*\|\s*(\d+)',s);steps=re.findall(r'total_timesteps\s*\|\s*(\d+)',s)
 if times:
  counts['with_progress_timing']+=1
  rows.append(dict(path=str(p.relative_to(root)),sha256_of_scanned_tail=hashlib.sha256(data).hexdigest(),tail_bytes=len(data),file_bytes=p.stat().st_size,elapsed_last_seconds=int(times[-1]),transitions_last=int(steps[-1]) if steps else None,scope='last printed PPO progress checkpoint; excludes initialization/final evaluation and may precede final update',ncpus_verified=None,peak_memory=None))
account=[]
for job in ['132575.master','132576.master','132577.master','132580[0].master']:
 r=subprocess.run(['/opt/pbs/bin/qstat','-xf',job],capture_output=True,text=True);fields={}
 for line in r.stdout.splitlines():
  m=re.match(r'\s*(Job_Name|job_state|Exit_status|resources_used\.\w+|Resource_List.ncpus)\s*=\s*(.*)',line)
  if m:fields[m.group(1)]=m.group(2)
 account.append(dict(job=job,fields=fields,available=bool(fields)))
print(json.dumps(dict(scan=counts,progress_records=rows,accounting=account),indent=2))
