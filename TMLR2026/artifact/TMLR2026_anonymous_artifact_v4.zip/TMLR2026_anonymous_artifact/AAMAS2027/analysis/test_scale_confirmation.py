import tempfile,json
from pathlib import Path
import pandas as pd,numpy as np
from analyze_scale_confirmation import analyze
with tempfile.TemporaryDirectory() as temp:
 root=Path(temp);grid=[0.,.4,.5,.6,.7,.85,1.]
 analyze(root/'absent',root/'empty',grid);assert 'no complete confirmation' in (root/'empty/status.json').read_text()
 for arm in ['A','B','S','N']:
  for w in grid:
   for seed in range(42,62):
    p=root/'runs'/f'{arm}_{w}_{seed}';p.mkdir(parents=True)
    (p/'protocol.json').write_text(json.dumps(dict(phase='confirmation',arm=arm,w=w,seed=seed,reference=0.)))
    (p/'evaluation_300000.json').write_text(json.dumps(dict(summary={'collapsed':w<.6},actual_agent_transitions=300160)))
 analyze(root/'runs',root/'complete',grid)
 d=pd.read_csv(root/'complete/contrasts.csv');assert len(d)==3;np.testing.assert_allclose(d[['difference','ci_low','ci_high']],0,atol=1e-12)
 (root/'runs/A_0.0_42/evaluation_300000.json').unlink()
 analyze(root/'runs',root/'partial',grid);assert (root/'partial/incomplete_reference_0.0.json').exists()
 assert json.loads((root/'partial/status.json').read_text())['complete_reference_sets']==0
print('PASS: empty/incomplete guards and paired identity contrasts across complete synthetic arms')
