"""Opt-in future-run evaluator; preserves the historical label statistic.
Use evaluate_with_trajectory_metric(model, eval_env, ...) in new run drivers.
No legacy driver or archived result is modified.
"""
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'experiments'))

def evaluate_with_trajectory_metric(model, eval_env, num_episodes=10, base_seed=42):
    from expA_interior_w import evaluate_and_extract_metrics, LOW_BOUND, HIGH_BOUND
    predictions=[]
    class Recorder:
        def predict(self, observation, deterministic=True):
            action,state=model.predict(observation,deterministic=deterministic)
            predictions.append(float(LOW_BOUND+.5*(np.asarray(action)[0]+1)*(HIGH_BOUND-LOW_BOUND)))
            return action,state
    metrics=evaluate_and_extract_metrics(Recorder(),eval_env,num_episodes=num_episodes,base_seed=base_seed)
    # Legacy evaluator's final seeded reset contributes one prediction per active
    # agent to mean_S. Exclude those predictions from the trajectory statistic.
    reset_count=len(eval_env.agents)
    trajectory=predictions[:-reset_count] if reset_count else predictions
    names=['mean_S','mean_order','mean_inventory','lost_sales','profit','bullwhip']
    result=dict(zip(names,map(float,metrics)))
    result.update(trajectory_mean_S=float(np.mean(trajectory)) if trajectory else None,
                  trajectory_action_count=len(trajectory),
                  trajectory_weighting='equal weight per evaluated agent-step',
                  collapsed=bool(metrics[0]<10 and metrics[4]<=-127.1))
    return result
