"""Reduce X3 run directories (runs/X3/idx_*) to a per-run CSV: E6's per-run summary (labels, gradient diagnostics, per-step
update norms, which now include the actor's and the critic's Adam moments).

Usage: extract_x3.py BASE OUTDIR
"""
import csv, json, sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract_e5e6 import e6  # noqa: E402

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)


def x(p):
    row = e6(p); pr = json.loads((p / "protocol.json").read_text())
    row.update(experiment="X3", mode=pr["mode"], clip_actor=pr["clip_actor"], clip_critic=pr["clip_critic"])
    return row


if __name__ == "__main__":
    with Pool(8) as pool:
        rows = pool.map(x, sorted((BASE / "runs/X3").glob("idx_*")), chunksize=8)
    keys = sorted({k for r in rows for k in r})
    with open(OUT / "X3_runs.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print("X3_runs.csv", len(rows), flush=True)
