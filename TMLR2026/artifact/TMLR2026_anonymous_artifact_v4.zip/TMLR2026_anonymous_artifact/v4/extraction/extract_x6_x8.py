"""Reduce X6, X7 and X8 run directories (runs/X6/idx_*, runs/X7/idx_*, runs/X8/idx_*) to one per-run CSV each:
E1's per-run summary (labels, gradient diagnostics), the X4-style advantage-quality log averaged over rollouts 1..end,
and per-run medians of the per-minibatch pre-clip critic and actor gradient norms and the applied (post-clip) actor norm.

Usage: extract_x6_x8.py BASE OUTDIR
"""
import csv, gzip, json, sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import one_300k  # noqa: E402

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
Q = ["ev_sb3", "ev_train_mc", "ev_ref_mc", "ev_ref_insample", "verr_train", "verr_ref", "gae_err", "adv_pearson", "adv_spearman",
     "sign_dis", "sign_dis_raw", "ev_post_insample", "n_valid"]


def x(p):
    row = one_300k(p); pr = json.loads((p / "protocol.json").read_text())
    row.update(experiment=pr["experiment"], part=pr["part"], execution=pr.get("execution"), critic_mode=pr.get("critic_mode"),
               critic_output_scale=pr.get("critic_output_scale"), critic_lr_multiplier=pr.get("critic_lr_multiplier"), x_arm=pr["arm"])
    f = p / "diagnostics/x4.jsonl.gz"
    if row["complete"] and f.exists():
        r = [json.loads(l) for l in gzip.open(f, "rt")]; row["x_records"] = len(r); body = r[1:]
        for q in Q:
            if q in body[0]:
                row["x_" + q] = float(np.nanmean(np.array([b[q] for b in body], float)))
    u = p / "diagnostics/updates.jsonl.gz"
    if row["complete"] and u.exists():
        mb = [m for l in gzip.open(u, "rt") for m in json.loads(l)["minibatches"]]
        for k in ["critic_grad_norm", "actor_grad_norm", "post_actor_grad_norm", "post_critic_grad_norm"]:
            v = [m[k] for m in mb if k in m]
            row["med_" + k] = float(np.median(v)) if v else float("nan")
        row["clip_freq"] = float(np.mean([m["gradient_clipped"] for m in mb]))
    return row


if __name__ == "__main__":
    for exp in ["X6", "X7", "X8"]:
        dirs = sorted((BASE / f"runs/{exp}").glob("idx_*"))
        if not dirs:
            continue
        with Pool(8) as pool:
            rows = pool.map(x, dirs, chunksize=8)
        keys = sorted({k for r in rows for k in r})
        with open(OUT / f"{exp}_runs.csv", "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
        print(f"{exp}_runs.csv", len(rows), flush=True)
