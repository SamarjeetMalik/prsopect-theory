"""Per-minibatch test of the shared-clip formula (Eq. 2): applied actor norm = kappa * ||g_a||, with
kappa = min(1, tau / ||g||). Read-only over raw run directories.

Runs: E1 global_clip/raw arms B and S, and every E6 run. Per run, from diagnostics/updates.jsonl.gz:
  measured  mean post-clip actor norm (as logged)
  predicted mean of tau * ||g_a|| / max(||g||, tau) per minibatch (shared clip) or tau * ||g_a|| / max(||g_a||, tau)
            (per-group clip) or ||g_a|| (no clip)
  critic share of ||g||^2 (mean, median), fraction of minibatches clipped, mean ||g_a||, mean ||g_c||.

Usage: eq2_minibatch.py BASE OUTDIR
"""
import csv, gzip, json, sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
TAU = 0.5


def one(p):
    pr = json.loads((p / "protocol.json").read_text())
    exp = p.parent.name
    mode = pr.get("optimizer_mode")
    if exp == "E1" and not (mode == "global_clip" and pr.get("reward_mode") == "raw" and pr.get("arm") in ("B", "S")):
        return None
    ga, gc, gt, post, clip = [], [], [], [], []
    with gzip.open(p / "diagnostics/updates.jsonl.gz", "rt") as f:
        for line in f:
            for m in json.loads(line)["minibatches"]:
                if m.get("actor_grad_norm") is None or m.get("post_actor_grad_norm") is None:
                    continue
                ga.append(float(m["actor_grad_norm"])); gc.append(float(m["critic_grad_norm"]))
                gt.append(float(m.get("total_grad_norm") or np.hypot(m["actor_grad_norm"], m["critic_grad_norm"])))
                post.append(float(m["post_actor_grad_norm"])); clip.append(bool(m.get("gradient_clipped", m.get("actor_group_clipped", False))))
    ga, gc, gt, post = map(np.array, (ga, gc, gt, post))
    if mode == "global_clip":
        pred = TAU * ga / np.maximum(gt, TAU)
    elif mode == "groupwise_clip":
        pred = TAU * ga / np.maximum(ga, TAU)
    else:
        pred = ga
    share = gc ** 2 / np.maximum(gt ** 2, 1e-300)
    return dict(exp=exp, dir=p.name, optimizer_mode=mode, arm=pr["arm"], w=pr["w"], seed=pr["seed"], n_mb=len(ga),
                measured_post_actor=float(post.mean()), predicted_post_actor=float(pred.mean()),
                max_abs_rel_err=float(np.max(np.abs(pred - post) / np.maximum(post, 1e-12))),
                critic_share_mean=float(share.mean()), critic_share_median=float(np.median(share)), clip_frac=float(np.mean(clip)),
                actor_norm=float(ga.mean()), critic_norm=float(gc.mean()))


if __name__ == "__main__":
    dirs = sorted((BASE / "runs/E1").glob("idx_*")) + sorted((BASE / "runs/E6").glob("idx_*"))
    with Pool(8) as pool:
        rows = [r for r in pool.map(one, dirs, chunksize=8) if r]
    with open(OUT / "E1E6_eq2_minibatch.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print("E1E6_eq2_minibatch.csv", len(rows), flush=True)
