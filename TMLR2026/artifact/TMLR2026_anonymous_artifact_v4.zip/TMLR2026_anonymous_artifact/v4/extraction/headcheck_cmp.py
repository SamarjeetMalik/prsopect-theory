import gzip, json, sys
from pathlib import Path
import numpy as np
G = Path(sys.argv[1])
def mb(d):
    return np.array([[m["actor_grad_norm"], m["critic_grad_norm"]] for l in gzip.open(d / "diagnostics/updates.jsonl.gz", "rt") for m in json.loads(l)["minibatches"]])
def first(a, b, tol):
    r = np.abs(a / b - 1) > tol; return int(r.argmax()) if r.any() else -1
def ev(d): return json.load(open(d / "evaluation_300000.json"))
print("arch seed n_minibatches | first minibatch with actor-gradient relative difference >1e-3: M-S vs B, M-S vs B(eps/49) | same at >1e-6 | median rel diff in the first 100 minibatches, both | final median rel diff, both")
out = []
for arch in ["x4", "x6"]:
    for s in [42, 43, 44, 45]:
        a, b, c = [mb(G / f"{arch}_{k}_{s}") for k in ["MS", "B", "Beps"]]; n = len(a); assert len(b) == n == len(c)
        A, B, C = a[:, 0], b[:, 0], c[:, 0]
        row = [first(A, B, 1e-3), first(A, C, 1e-3), first(A, B, 1e-6), first(A, C, 1e-6)]
        d = lambda x, y, sl: float(np.median(np.abs(x[sl] / y[sl] - 1)))
        print(arch, s, n, "|", row[0], row[1], "|", row[2], row[3], "|", f"{d(A, B, slice(0, 100)):.2e} {d(A, C, slice(0, 100)):.2e}", "|", f"{d(A, B, slice(-500, None)):.2e} {d(A, C, slice(-500, None)):.2e}", flush=True)
        out.append((arch, s, *row))
print("HEADCHECK_CMP_DONE")
