"""Reduce E8 run directories to a per-run CSV (labels, evaluation, diagnostics, online-affine tracking).

Usage: extract_e8.py BASE OUTDIR
"""
import csv, json, sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import one_300k  # noqa: E402

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)


def e8(p):
    row = one_300k(p); pr = json.loads((p / "protocol.json").read_text())
    row.update(critic_mode=pr["critic_mode"], part=pr["part"], static_affine=pr["static_affine"])
    if row["complete"]:
        c = json.loads((p / "COMPLETE.json").read_text())
        for k, v in (c.get("M_reward_moments") or {}).items(): row["M_" + k] = v
        f = p / "diagnostics/popart.json"
        if f.exists():
            pa = json.loads(f.read_text()); row.update(popart_sigma_final=pa[-1]["sigma"], popart_max_drift=max(r["max_output_drift"] for r in pa))
        f = p / "diagnostics/online_affine.json"
        if f.exists():
            L = json.loads(f.read_text()); m = np.array([[r["m_mean"], r["target_mean"], r["m_sd"], r["target_sd"], r["a"]] for r in L])
            row.update(online_rollouts=len(L), track_mean_mae=float(np.abs(m[:, 0] - m[:, 1]).mean()), track_sd_mae=float(np.abs(m[:, 2] - m[:, 3]).mean()),
                       online_a_min=float(m[:, 4].min()), online_a_max=float(m[:, 4].max()), target_mean_avg=float(m[:, 1].mean()), target_sd_rms=float(np.sqrt((m[:, 3] ** 2).mean())))
    return row


if __name__ == "__main__":
    with Pool(8) as pool:
        rows = pool.map(e8, sorted((BASE / "runs/E8").glob("idx_*")), chunksize=8)
    keys = sorted({k for r in rows for k in r})
    with open(OUT / "E8_runs.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print("E8_runs.csv", len(rows), flush=True)
