"""Reduce v4 run directories on [cluster] to compact per-run CSVs (labels, evaluation, optimizer diagnostics).

Usage: extract.py BASE OUTDIR   (BASE = <workdir>)
"""
import csv, gzip, json, sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
MB_KEYS = ["actor_grad_norm", "critic_grad_norm", "total_grad_norm", "actor_grad_energy_share",
           "post_actor_grad_norm", "post_critic_grad_norm", "value_loss", "approx_kl", "clip_fraction"]


def diag(d):
    out = {}
    up, ro = d / "updates.jsonl.gz", d / "rollouts.jsonl.gz"
    if up.exists():
        acc = {k: [] for k in MB_KEYS}; clipped = []; ev = []
        with gzip.open(up, "rt") as f:
            for line in f:
                r = json.loads(line); ev.append(r.get("explained_variance", np.nan))
                for m in r["minibatches"]:
                    for k in MB_KEYS:
                        if k in m and m[k] is not None: acc[k].append(float(m[k]))
                    clipped.append(bool(m.get("gradient_clipped", m.get("actor_group_clipped", False))))
        for k, v in acc.items(): out["mb_" + k] = float(np.mean(v)) if v else np.nan
        out["mb_clip_freq"] = float(np.mean(clipped)) if clipped else np.nan
        out["explained_variance_last"] = float(ev[-1]) if ev else np.nan
        out["n_updates"] = len(ev)
    if ro.exists():
        acc = {}
        with gzip.open(ro, "rt") as f:
            for line in f:
                r = json.loads(line)
                g = next(x for x in r["groups"] if x.get("agent") == "pooled")
                for key, mom in g["rewards"].items():
                    if isinstance(mom, dict) and "rms" in mom:
                        acc.setdefault(key, []).append((mom["rms"], mom.get("negative", np.nan), mom["mean"]))
        for key, v in acc.items():
            a = np.array(v, float)
            out[f"reward_{key}_rms"] = float(np.sqrt(np.mean(a[:, 0] ** 2)))
            out[f"reward_{key}_neg"] = float(np.nanmean(a[:, 1]))
            out[f"reward_{key}_mean"] = float(np.mean(a[:, 2]))
    return out


def one_300k(p):
    pr = json.loads((p / "protocol.json").read_text())
    row = {k: pr.get(k) for k in ["design", "index", "optimizer_mode", "reward_mode", "adam_eps", "arm", "arm_scale", "w", "seed", "condition", "reference"]}
    row["dir"] = p.name
    comp = p / "COMPLETE.json"; ev = p / "evaluation_300000.json"
    row["complete"] = comp.exists() and ev.exists()
    if row["complete"]:
        c = json.loads(comp.read_text()); e = json.loads(ev.read_text()); s = e["summary"]
        row.update(actual=c["actual_transitions"], collapsed=int(s["collapsed"]), profit=s["profit"], mean_S=s["mean_S"],
                   n_eps=len(e["episodes"]), eval_seeds_ok=[x["evaluation_seed"] for x in e["episodes"]] == list(range(pr["seed"] * 10, pr["seed"] * 10 + 10)))
    row.update(diag(p / "diagnostics"))
    return row


def one_e3(p):
    pr = json.loads((p / "protocol.json").read_text())
    rows = []
    for ck in pr["checkpoints"]:
        f = p / f"evaluation_{ck}.json"
        if not f.exists(): rows.append(dict(run=p.name, w=pr["w"], condition=pr["condition"], seed=pr["seed"], checkpoint=ck, present=False)); continue
        e = json.loads(f.read_text()); s = e["summary"]
        rows.append(dict(run=p.name, w=pr["w"], condition=pr["condition"], seed=pr["seed"], checkpoint=ck, present=True,
                         actual=e.get("actual_agent_transitions"), collapsed=int(s["collapsed"]), profit=s["profit"], mean_S=s["mean_S"],
                         n_eps=len(e["episodes"]), complete=(p / "COMPLETE.json").exists()))
    return rows


def write(name, rows):
    keys = sorted({k for r in rows for k in r})
    with open(OUT / name, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print(name, len(rows), flush=True)


if __name__ == "__main__":
    with Pool(8) as pool:
        for kind in ["E1", "E2"]:
            dirs = sorted((BASE / "runs" / kind).glob("idx_*"))
            write(f"{kind}_runs.csv", pool.map(one_300k, dirs, chunksize=8))
        dirs = sorted((BASE / "e3root/new_runs/v4_e3_horizon/horizon").glob("run_*"))
        write("E3_checkpoints.csv", [r for rs in pool.map(one_e3, dirs) for r in rs])
