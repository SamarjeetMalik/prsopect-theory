"""Reduce E4 (LBF) run directories to one CSV: protocol, evaluation, optimizer and reward diagnostics."""
import csv, gzip, json, sys
from multiprocessing import Pool
from pathlib import Path
import numpy as np
BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
MB = ["actor_grad_norm", "critic_grad_norm", "post_actor_grad_norm", "actor_grad_energy_share", "value_loss"]
def one(p):
    pr = json.loads((p / "protocol.json").read_text())
    row = {k: pr.get(k) for k in ["design", "index", "optimizer_mode", "arm", "alpha", "beta", "lambda_loss", "symmetric_scale", "w", "seed", "budget"]}
    row["complete"] = (p / "COMPLETE.json").exists() and (p / "evaluation.json").exists()
    if row["complete"]:
        e = json.loads((p / "evaluation.json").read_text())
        row.update(team_return=e["team_return"], collapsed=int(e["collapsed"]), n_eps=len(e["episodes"]), actual=e["actual_transitions"], elapsed=e["elapsed_seconds"])
    up = p / "diagnostics/updates.jsonl.gz"
    if up.exists():
        acc = {k: [] for k in MB}; clipped = []
        with gzip.open(up, "rt") as f:
            for line in f:
                for m in json.loads(line)["minibatches"]:
                    for k in MB:
                        if m.get(k) is not None: acc[k].append(float(m[k]))
                    clipped.append(bool(m.get("gradient_clipped", False)))
        for k, v in acc.items(): row["mb_" + k] = float(np.mean(v)) if v else np.nan
        row["mb_clip_freq"] = float(np.mean(clipped)) if clipped else np.nan
    ro = p / "diagnostics/rollouts.jsonl.gz"
    if ro.exists():
        b, t = [], []
        with gzip.open(ro, "rt") as f:
            for line in f:
                r = json.loads(line); b.append((r["blend"]["rms"], r["blend"]["negative"])); t.append((r["transformed"]["rms"], r["transformed"]["negative"]))
        b, t = np.array(b), np.array(t)
        row.update(reward_blend_rms=float(np.sqrt(np.mean(b[:, 0] ** 2))), reward_blend_neg=float(b[:, 1].mean()),
                   reward_transformed_rms=float(np.sqrt(np.mean(t[:, 0] ** 2))), reward_transformed_neg=float(t[:, 1].mean()))
    return row
if __name__ == "__main__":
    dirs = sorted((BASE / "runs/E4").glob("idx_*"))
    with Pool(8) as pool: rows = pool.map(one, dirs, chunksize=8)
    keys = sorted({k for r in rows for k in r})
    with open(OUT / "E4_runs.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print("E4_runs.csv", len(rows), flush=True)
