"""Audit extraction (read-only on run directories).

1. Per-rollout training-reward and critic-target (rollout-buffer return) distributions for E1 separate_no_clip/raw
   B, A, S and all E7 runs: mean, std, quantiles, fraction negative. M's logged reward is B's reward before the affine
   map; the map is applied in the analysis.
2. E4 label audit: for each run, recompute the mean of the ten stored per-episode native team returns and compare it
   with the stored team_return and the stored label.

Usage: audit_dist_e4.py BASE OUTDIR
"""
import csv, gzip, json, sys
from multiprocessing import Pool
from pathlib import Path

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
Q = ["p01", "p10", "p25", "p50", "p75", "p90", "p99"]


def traj(p):
    pr = json.loads((p / "protocol.json").read_text())
    if pr.get("design", "").startswith("optimizer-factorial") or "critic_mode" not in pr:
        if not (pr.get("optimizer_mode") == "separate_no_clip" and pr.get("reward_mode") == "raw" and pr.get("arm") in ("B", "A", "S")):
            return []
    key = dict(src=p.parent.name, dir=p.name, critic_mode=pr.get("critic_mode", "plain"), arm=pr["arm"], w=pr["w"], seed=pr["seed"])
    rows = []
    with gzip.open(p / "diagnostics/rollouts.jsonl.gz", "rt") as fh:
        for i, line in enumerate(fh):
            r = json.loads(line); g = next(x for x in r["groups"] if x["agent"] == "pooled")
            t, ret = g["rewards"]["transformed"], g["returns_buffer"]
            row = dict(key, rollout=i, t=r["actual_transitions"], r_mean=t["mean"], r_std=t["std"], r_neg=t["negative"],
                       ret_mean=ret["mean"], ret_std=ret["std"])
            row.update({"r_" + q: t["quantiles"][q] for q in Q}); row.update({"ret_" + q: ret["quantiles"][q] for q in Q})
            rows.append(row)
    return rows


def e4(p):
    pr = json.loads((p / "protocol.json").read_text()); e = json.loads((p / "evaluation.json").read_text())
    eps = [float(x) for x in e["episodes"]]; m = sum(eps) / len(eps)
    return dict(dir=p.name, optimizer_mode=pr["optimizer_mode"], arm=pr["arm"], w=pr["w"], seed=pr["seed"], n_eps=len(eps),
                stored_team_return=e["team_return"], recomputed_mean=m, abs_diff=abs(m - e["team_return"]), stored_collapsed=int(e["collapsed"]),
                ep_min=min(eps), ep_max=max(eps), episodes=" ".join(f"{x:.6g}" for x in eps))


def write(name, rows, gz=False):
    keys = list(rows[0].keys())
    fh = gzip.open(OUT / name, "wt", newline="") if gz else open(OUT / name, "w", newline="")
    with fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print(name, len(rows), flush=True)


if __name__ == "__main__":
    dirs = sorted((BASE / "runs/E1").glob("idx_*")) + sorted((BASE / "runs/E7").glob("idx_*"))
    with Pool(8) as pool:
        write("E1E7_rollout_distributions.csv.gz", [r for rs in pool.map(traj, dirs, chunksize=8) for r in rs], gz=True)
        write("E4_label_audit.csv", pool.map(e4, sorted((BASE / "runs/E4").glob("idx_*")), chunksize=8))
