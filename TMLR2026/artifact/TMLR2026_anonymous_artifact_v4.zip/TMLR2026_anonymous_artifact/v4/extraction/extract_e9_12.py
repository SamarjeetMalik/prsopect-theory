"""Reduce E9/E10 (runs/E910), E11 (runs/E11) and E12 (runs/E12) run directories to per-run CSVs.

Usage: extract_e9_12.py BASE OUTDIR
"""
import csv, json, sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import one_300k  # noqa: E402

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)


def e910(p):
    row = one_300k(p); pr = json.loads((p / "protocol.json").read_text())
    row.update(experiment=pr["experiment"], max_grad_norm=pr["max_grad_norm"], critic_mode=pr["critic_mode"])
    return row


def e11(p):
    pr = json.loads((p / "protocol.json").read_text()); row = {k: pr.get(k) for k in ["design", "index", "condition_name", "arm", "w", "seed"]}
    row["dir"] = p.name; comp, ev = p / "COMPLETE.json", p / "evaluation_300000.json"; row["complete"] = comp.exists() and ev.exists()
    if row["complete"]:
        c = json.loads(comp.read_text()); e = json.loads(ev.read_text()); s = e["summary"]
        row.update(actual=c["actual_transitions"], collapsed=int(s["collapsed"]), profit=s["profit"], mean_S=s["mean_S"], n_eps=len(e["episodes"]),
                   eval_seeds_ok=[x["evaluation_seed"] for x in e["episodes"]] == list(range(pr["seed"] * 10, pr["seed"] * 10 + 10)), **c["diagnostics"])
    return row


def e12(p):
    row = one_300k(p); pr = json.loads((p / "protocol.json").read_text()); row.update(learner=pr["learner"], observation=pr["observation"])
    return row


def write(name, rows):
    keys = sorted({k for r in rows for k in r})
    with open(OUT / name, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print(name, len(rows), flush=True)


if __name__ == "__main__":
    with Pool(8) as pool:
        for sub, fn, name in [("E910", e910, "E9E10_runs.csv"), ("E11", e11, "E11_runs.csv"), ("E12", e12, "E12_runs.csv")]:
            dirs = sorted((BASE / "runs" / sub).glob("idx_*"))
            if dirs:
                write(name, pool.map(fn, dirs, chunksize=8))
