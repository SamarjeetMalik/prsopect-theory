"""Reduce X1 and X2 run directories (runs/X12/idx_*) to per-run CSVs.

X1 rows: E6's per-run summary (labels, gradient diagnostics, per-step update norms, which now include the actor's Adam
moments) plus the per-minibatch shared-clip factor kappa = min(1, 0.5 / ||g||): mean, median, 10th/90th percentiles and
coefficient of variation. X2 rows: E11's per-run summary.

Usage: extract_x1x2.py BASE OUTDIR
"""
import csv, gzip, json, sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract_e5e6 import e6  # noqa: E402
from extract_e9_12 import e11  # noqa: E402

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
TAU = 0.5


def x(p):
    pr = json.loads((p / "protocol.json").read_text())
    if pr["experiment"] == "X2":
        row = e11(p)
    else:
        row = e6(p); tot = []
        f = p / "diagnostics/updates.jsonl.gz"
        if f.exists():
            with gzip.open(f, "rt") as fh:
                for line in fh:
                    tot += [m["total_grad_norm"] for m in json.loads(line)["minibatches"] if m.get("total_grad_norm") is not None]
        if tot:
            k = np.minimum(1.0, TAU / np.maximum(np.array(tot, float), 1e-300))
            row.update(kappa_mean=float(k.mean()), kappa_median=float(np.median(k)), kappa_p10=float(np.quantile(k, .1)),
                       kappa_p90=float(np.quantile(k, .9)), kappa_cv=float(k.std() / k.mean()), kappa_n=len(k))
    row.update(experiment=pr["experiment"], mode=pr["mode"])
    return row


if __name__ == "__main__":
    dirs = sorted((BASE / "runs/X12").glob("idx_*"))
    with Pool(8) as pool:
        rows = pool.map(x, dirs, chunksize=8)
    for exp in ["X1", "X2"]:
        rs = [r for r in rows if r["experiment"] == exp]; keys = sorted({k for r in rs for k in r})
        with open(OUT / f"{exp}_runs.csv", "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rs)
        print(f"{exp}_runs.csv", len(rs), flush=True)
