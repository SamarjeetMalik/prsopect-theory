"""Diagnostic (read-only): in X4 and X5, per seed x cell, the S/B ratio of PopArt's sigma over rollouts."""
import json, sys
from collections import defaultdict
from pathlib import Path
import numpy as np
B = Path(sys.argv[1])
for exp, part in [("X4", "D-pop"), ("X5", "popart")]:
    runs = defaultdict(dict)
    for d in sorted((B / "runs" / exp).glob("idx_*")):
        p = json.loads((d / "protocol.json").read_text())
        if p["part"] != part: continue
        f = d / "diagnostics/popart.json"
        if f.exists(): runs[(p["seed"], p["w"])][p["arm"]] = np.array([r["sigma"] for r in json.loads(f.read_text())])
    pairs = [v for v in runs.values() if len(v) == 2]; n = min(min(len(v["S"]), len(v["B"])) for v in pairs)
    R = np.array([v["S"][:n] / v["B"][:n] for v in pairs])
    print(exp, "pairs", len(pairs), "rollouts", n)
    for k in [0, 1, 2, 5, 10, 25, 50, 100, 200, n - 1]:
        q = np.percentile(R[:, k], [5, 50, 95]); print(f"  rollout {k + 1:4d}  sigma_S/sigma_B  p5 {q[0]:6.2f}  median {q[1]:6.2f}  p95 {q[2]:6.2f}", flush=True)
print("POPART_DONE")
