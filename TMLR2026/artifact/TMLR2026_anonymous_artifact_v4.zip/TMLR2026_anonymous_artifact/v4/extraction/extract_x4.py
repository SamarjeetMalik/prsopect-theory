"""Reduce X4 run directories (runs/X4/idx_*) to a per-run CSV: E1's per-run summary (labels, gradient diagnostics) plus
the X4 advantage-quality log averaged over the run (rollouts 1..end; rollout 0 has no reference) and over its quarters.

Usage: extract_x4.py BASE OUTDIR
"""
import csv, gzip, json, sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import one_300k  # noqa: E402

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
Q = ["ev_sb3", "ev_train_mc", "ev_ref_mc", "ev_ref_insample", "verr_train", "verr_ref", "gae_err", "adv_pearson", "adv_spearman",
     "sign_dis", "sign_dis_raw", "ev_post_insample", "extra_epochs", "ev_fit_before", "ev_fit_after", "n_valid"]


def x(p):
    row = one_300k(p); pr = json.loads((p / "protocol.json").read_text())
    row.update(experiment="X4", part=pr["part"], critic_mode=pr["critic_mode"], critic_output_scale=pr.get("critic_output_scale"))
    f = p / "diagnostics/x4.jsonl.gz"
    if row["complete"] and f.exists():
        r = [json.loads(l) for l in gzip.open(f, "rt")]; row["x4_records"] = len(r); body = r[1:]
        for q in Q:
            if q in body[0]:
                v = np.array([b[q] for b in body], float); row["x4_" + q] = float(np.nanmean(v))
                for i, part in enumerate(np.array_split(v, 4)):
                    row[f"x4q{i + 1}_{q}"] = float(np.nanmean(part))
    return row


if __name__ == "__main__":
    with Pool(8) as pool:
        rows = pool.map(x, sorted((BASE / "runs/X4").glob("idx_*")), chunksize=8)
    keys = sorted({k for r in rows for k in r})
    with open(OUT / "X4_runs.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print("X4_runs.csv", len(rows), flush=True)
