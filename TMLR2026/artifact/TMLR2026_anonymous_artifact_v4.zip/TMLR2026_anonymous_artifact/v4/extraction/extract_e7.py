"""Reduce E7 (critic-target scale, moment-matched control) run directories to a per-run CSV.

Usage: extract_e7.py BASE OUTDIR
"""
import csv, json, sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import one_300k  # noqa: E402  (labels, evaluation summary, gradient diagnostics, reward moments)

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)


def e7(p):
    row = one_300k(p); pr = json.loads((p / "protocol.json").read_text()); row["critic_mode"] = pr["critic_mode"]
    if row["complete"]:
        c = json.loads((p / "COMPLETE.json").read_text())
        for k, v in (c.get("M_reward_moments") or {}).items(): row["M_" + k] = v
        f = p / "diagnostics/popart.json"
        if f.exists():
            pa = json.loads(f.read_text())
            row.update(popart_updates=len(pa), popart_sigma_final=pa[-1]["sigma"], popart_mu_final=pa[-1]["mu"],
                       popart_max_drift=max(r["max_output_drift"] for r in pa))
    return row


if __name__ == "__main__":
    dirs = sorted((BASE / "runs/E7").glob("idx_*"))
    with Pool(8) as pool:
        rows = pool.map(e7, dirs, chunksize=8)
    keys = sorted({k for r in rows for k in r})
    with open(OUT / "E7_runs.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print("E7_runs.csv", len(rows), flush=True)
