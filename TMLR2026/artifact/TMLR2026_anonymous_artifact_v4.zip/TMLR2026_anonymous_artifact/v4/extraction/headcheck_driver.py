"""Diagnostic only (not pre-registered, no frozen file edited). Runs a frozen runner, optionally with the critic Adam's
epsilon set to CRITIC_EPS. Under V = c*h with raw returns, S's critic gradient is c^2 times B's, so Adam on S should equal
Adam on B with epsilon/c^2. Usage: CRITIC_EPS=... headcheck_driver.py x4|x6 <runner args>"""
import os, sys
sys.path.insert(0, os.getcwd())
import instrumented_ppo as ipp
E = os.environ.get("CRITIC_EPS")
if E:
    E = float(E); orig = ipp.SeparateNoClipPPO.update_optimizers
    def upd(self):
        orig(self)
        for g in self.critic_optimizer.param_groups: g["eps"] = E
    ipp.SeparateNoClipPPO.update_optimizers = upd
which = sys.argv.pop(1)
if which == "x4":
    import x4_runner as r
else:
    import x6_x8_runner as r
r.main()
