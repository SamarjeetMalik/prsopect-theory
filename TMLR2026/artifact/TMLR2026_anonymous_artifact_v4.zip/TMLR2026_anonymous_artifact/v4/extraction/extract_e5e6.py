"""Reduce E5 (decoupled horizon) and E6 (clipping isolation) run directories to per-run CSVs.

Usage: extract_e5e6.py BASE OUTDIR
"""
import csv, gzip, json, sys
from multiprocessing import Pool
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import one_300k  # noqa: E402  (labels, evaluation summary, gradient diagnostics, reward moments)

BASE, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)


def e5(p):
    pr = json.loads((p / "protocol.json").read_text()); rows = []
    for ck in pr["checkpoints"]:
        f = p / f"evaluation_{ck}.json"
        if not f.exists():
            rows.append(dict(run=p.name, arm=pr["arm"], w=pr["w"], seed=pr["seed"], checkpoint=ck, present=False)); continue
        e = json.loads(f.read_text()); s = e["summary"]
        rows.append(dict(run=p.name, arm=pr["arm"], w=pr["w"], seed=pr["seed"], checkpoint=ck, present=True, design=pr["design"],
                         optimizer_mode=pr["optimizer_mode"], reward_mode=pr["reward_mode"], actual=e.get("actual_agent_transitions"),
                         collapsed=int(s["collapsed"]), profit=s["profit"], mean_S=s["mean_S"], n_eps=len(e["episodes"]),
                         complete=(p / "COMPLETE.json").exists()))
    return rows


def e6(p):
    row = one_300k(p)
    f = p / "diagnostics/param_updates.jsonl.gz"
    if f.exists():
        steps = []
        with gzip.open(f, "rt") as fh:
            for line in fh:
                steps += json.loads(line)["steps"]
        a = {k: np.array([s[k] for s in steps], float) for k in steps[0]}
        n = len(steps); early, late = slice(0, max(1, n // 10)), slice(n - max(1, n // 10), n)
        for k, v in a.items():
            row["pu_" + k] = float(v.mean()); row["pu_" + k + "_early"] = float(v[early].mean()); row["pu_" + k + "_late"] = float(v[late].mean())
        with np.errstate(divide="ignore", invalid="ignore"):
            r = a["actor_update_norm"] / a["applied_actor_grad_norm"]
        row["pu_actor_update_per_grad"] = float(np.nanmean(r[np.isfinite(r)]))
        row["pu_steps"] = n
    return row


def write(name, rows):
    keys = sorted({k for r in rows for k in r})
    with open(OUT / name, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys); w.writeheader(); w.writerows(rows)
    print(name, len(rows), flush=True)


if __name__ == "__main__":
    with Pool(8) as pool:
        write("E5_checkpoints.csv", [r for rs in pool.map(e5, sorted((BASE / "runs/E5").glob("idx_*"))) for r in rs])
        write("E6_runs.csv", pool.map(e6, sorted((BASE / "runs/E6").glob("idx_*")), chunksize=8))
