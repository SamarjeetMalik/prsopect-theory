"""Render v4 tables, figures and macros from v4_prereg/results/*.csv into TMLR2026/generated/v4/.

Usage (from the repository root): python TMLR2026/v4_prereg/analysis/render_v4.py
No number in the v4 manuscript sections is typed by hand; they come from here.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
RES, OUT = ROOT / "v4_prereg/results", ROOT / "generated/v4"
OUT.mkdir(parents=True, exist_ok=True)
CELLS = ["global_clip/raw", "global_clip/vecnormalize", "separate_no_clip/raw", "separate_no_clip/vecnormalize", "eps1e-8/raw"]
CELL_TEX = {"global_clip/raw": "Global clip, raw (default)", "global_clip/vecnormalize": "Global clip, normalized reward",
            "separate_no_clip/raw": "Separate optimizers, raw", "separate_no_clip/vecnormalize": "Separate optimizers, normalized",
            "eps1e-8/raw": r"Global clip, raw, Adam $\epsilon{=}10^{-8}$"}


def num(x, sign=False):
    return f"{x:+.3f}" if sign else f"{x:.3f}"


def iv(lo, hi, sign=False):
    return f"[{num(lo, sign)},\\,{num(hi, sign)}]"


def star(r):
    return r"$^{\ast}$" if (r.ci_low > 0 or r.ci_high < 0) else ""


def stack(cell):
    """Put a trailing confidence interval on its own line inside the cell, so wide tables need no shrinking."""
    if " $[" not in cell:
        return cell
    est, ci = cell.split(" $[", 1)
    return r"\begin{tabular}[t]{@{}c@{}}" + est + r"\\[-1pt]{\scriptsize $[" + ci + r"}\end{tabular}"


def table(path, caption, label, colspec, header, rows, size=r"\small", fit=False, pos="!htbp"):
    body = "\n".join(" & ".join(stack(c) for c in r) + r" \\" for r in rows)
    path.write_text(f"""\\begin{{table}}[{pos}]
\\caption{{{caption}}}
\\label{{{label}}}
\\centering{size}
\\begin{{tabular}}{{{colspec}}}
\\toprule
{header} \\\\
\\midrule
{body}
\\bottomrule
\\end{{tabular}}
\\end{{table}}
""")


# ---------------------------------------------------------------- E1/E2
cr = pd.read_csv(RES / "E1E2_crossings.csv"); co = pd.read_csv(RES / "E1E2_contrasts.csv")
it = pd.read_csv(RES / "E1E2_interactions.csv"); dg = pd.read_csv(RES / "E1E2_diagnostics.csv")
rows = []
for c in CELLS:
    r = [CELL_TEX[c]]
    for a in ["B", "A", "S", "R"]:
        x = cr[(cr.cell == c) & (cr.arm == a)].iloc[0]; r.append(f"${num(x.w50)}$ ${iv(x.ci_low, x.ci_high)}$")
    rows.append(r)
table(OUT / "factorial_crossings.tex",
      r"Optimizer $\times$ reward-normalization factorial (E1) and Adam-$\epsilon$ addendum (E2): crossings $w_{50}$ at 300k with 95\% seed-block intervals. B: curvature only; A: losses $\times7$; S: both branches $\times7$; R: both branches $\times3.451$ (A's pooled RMS ratio). Ten seeds per cell, eight mixture cells, one platform.",
      "tab:factorial_crossings", "@{}lcccc@{}", r"Optimizer / reward & B & A & S & R", rows, size=r"\footnotesize")
rows = []
for c in CELLS:
    r = [CELL_TEX[c]]
    for name in ["A-S", "A-B", "S-B", "R-B"]:
        x = co[(co.cell == c) & (co.contrast == name)].iloc[0]
        r.append(f"${num(x.difference, True)}${star(x)} ${iv(x.ci_low, x.ci_high, True)}$")
    rows.append(r)
table(OUT / "factorial_contrasts.tex",
      r"Paired seed-block contrasts within each optimizer cell. $^{\ast}$: 95\% interval excludes zero. A$-$S is the pre-declared asymmetry contrast; S$-$B and R$-$B are symmetric-scaling effects.",
      "tab:factorial_contrasts", "@{}lcccc@{}", r"Optimizer / reward & A$-$S & A$-$B & S$-$B & R$-$B", rows, size=r"\footnotesize")
rows = []
for c in CELLS[1:]:
    r = [CELL_TEX[c]]
    for name in ["A-S", "A-B", "S-B", "R-B"]:
        x = it[(it.cell == c) & (it.contrast == name)].iloc[0]
        r.append(f"${num(x.change_vs_standard, True)}${star(x)} ${iv(x.ci_low, x.ci_high, True)}$")
    rows.append(r)
table(OUT / "factorial_interactions.tex",
      r"Change in each contrast relative to the default cell (global clip, raw reward), paired by seed. $^{\ast}$: interval excludes zero.",
      "tab:factorial_interactions", "@{}lcccc@{}", r"Intervention & $\Delta$(A$-$S) & $\Delta$(A$-$B) & $\Delta$(S$-$B) & $\Delta$(R$-$B)", rows, size=r"\footnotesize", pos="H")
rows = []
for c in CELLS:
    for a in ["B", "A", "S"]:
        x = dg[(dg.cell == c) & (dg.arm == a)].iloc[0]
        rows.append([CELL_TEX[c] if a == "B" else "", a, f"{x.mb_critic_grad_norm:,.2f}", f"{x.mb_actor_grad_norm:.2f}", f"{x.mb_post_actor_grad_norm:.4f}",
                     f"{x.mb_actor_grad_energy_share:.3f}", f"{x.mb_clip_freq:.3f}", f"{x.reward_transformed_rms:.1f}"])
table(OUT / "factorial_diagnostics.tex",
      r"Optimizer diagnostics (means over runs of per-minibatch means). Pre-clip critic and actor gradient norms, post-clip (applied) actor norm, actor share of squared gradient norm, fraction of minibatches whose norm exceeds 0.5, and transformed-reward RMS. With separate optimizers no clipping is applied, so the applied actor norm equals the pre-clip norm.",
      "tab:factorial_diagnostics", "@{}llrrrrrr@{}", r"Cell & Arm & Critic & Actor & Applied actor & Actor share & Over 0.5 & Reward RMS", rows, size=r"\scriptsize", pos="H")

# Figure: A-S and S-B by cell
fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.1), sharey=True)
for ax, name, title in [(axes[0], "S-B", "S$-$B: symmetric $\\times7$"), (axes[1], "A-S", "A$-$S: losses vs. symmetric $\\times7$")]:
    sub = co[co.contrast == name].set_index("cell").loc[CELLS]
    y = np.arange(len(CELLS))[::-1]
    ax.errorbar(sub.difference, y, xerr=[sub.difference - sub.ci_low, sub.ci_high - sub.difference], fmt="o", color="k", ms=4, capsize=2)
    ax.axvline(0, color="0.6", lw=0.8); ax.set_title(title, fontsize=10); ax.set_xlabel("crossing difference at 300k", fontsize=9)
    ax.tick_params(labelsize=8)
axes[0].set_yticks(np.arange(len(CELLS))[::-1]); axes[0].set_yticklabels([CELL_TEX[c].replace("{=}", "=") for c in CELLS], fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "factorial_contrasts.pdf"); plt.close(fig)

# ---------------------------------------------------------------- E3
h = pd.read_csv(RES / "E3_crossings.csv", keep_default_na=False, na_values=[""]); hc = pd.read_csv(RES / "E3_contrasts.csv")
st = pd.read_csv(RES / "E3_stability.csv", keep_default_na=False, na_values=[""]); rc = pd.read_csv(RES / "E3_recovery.csv", keep_default_na=False, na_values=[""])
COND_TEX = {"null": "Linear", "curvature": "Curvature only", "lambda7": r"$\lambda=7$"}
PRIMARY = [300000, 900000, 1800000, 3600000]; BUD = {300000: "300k", 900000: "900k", 1800000: "1.8M", 3600000: "3.6M"}
rows = []
for cond in ["null", "curvature", "lambda7"]:
    r = [COND_TEX[cond]]
    for ck in PRIMARY:
        x = h[(h.condition == cond) & (h.checkpoint == ck)].iloc[0]; r.append(f"${num(x.w50)}$ ${iv(x.ci_low, x.ci_high)}$")
    rows.append(r)
r = [r"$\lambda7-$curvature"]
for ck in PRIMARY:
    x = hc[(hc.checkpoint == ck) & (hc.contrast == "lambda7-curvature")].iloc[0]; r.append(f"${num(x.difference, True)}${star(x)} ${iv(x.ci_low, x.ci_high, True)}$")
rows.append(r)
table(OUT / "horizon_table.tex",
      r"Refined single-platform horizon cohort (E3), default optimizer configuration (global clip, raw rewards): nine mixture cells $\{.2,.4,.6,.65,.7,.75,.8,.85,1\}$, ten seeds, 270 trajectories trained to 3.6M and evaluated every 150k. Crossings with 95\% seed-block intervals; last row is the paired contrast.",
      "tab:horizon", "@{}lcccc@{}", r"Condition & 300k & 900k & 1.8M & 3.6M", rows, size=r"\footnotesize")
rows = []
for _, x in st.iterrows():
    y = rc[rc.condition == x.condition].iloc[0]
    rows.append([COND_TEX[x.condition], f"${num(x.change_3p6M_minus_1p8M, True)}$ ${iv(x.ci_low, x.ci_high, True)}$", "yes" if x.stable_pm05 else "no",
                 f"{y.recovered_3p6M}/{y.collapsed_300k}", f"{y.relapsed_3p6M}/{y.noncollapsed_300k}"])
table(OUT / "horizon_stability.tex",
      r"Late-budget change and within-policy outcomes (E3). Stability requires the 3.6M$-$1.8M interval to lie within $\pm.05$ (pre-declared for v4). Recovery: collapsed at 300k, not collapsed at 3.6M; relapse: the reverse.",
      "tab:horizon_stability", "@{}lcccc@{}", r"Condition & 3.6M$-$1.8M & Stable & Recovered & Relapsed", rows)
fig, ax = plt.subplots(figsize=(6.0, 3.0))
for cond, m in [("null", "o"), ("curvature", "s"), ("lambda7", "^")]:
    sub = h[h.condition == cond].sort_values("checkpoint"); t = sub.checkpoint / 1e6
    ax.plot(t, sub.w50, marker=m, ms=3.5, lw=1.2, label=COND_TEX[cond]); ax.fill_between(t, sub.ci_low, sub.ci_high, alpha=.15)
ax.set_xlabel("requested agent transitions (millions)", fontsize=10); ax.set_ylabel("crossing $w_{50}$", fontsize=10); ax.tick_params(labelsize=9); ax.legend(fontsize=9, frameon=False)
fig.tight_layout(); fig.savefig(OUT / "horizon_curves.pdf"); plt.close(fig)

# ---------------------------------------------------------------- E4
c4 = pd.read_csv(RES / "E4_crossings.csv"); k4 = pd.read_csv(RES / "E4_contrasts.csv"); d4 = pd.read_csv(RES / "E4_diagnostics.csv")
OPT_TEX = {"global_clip": "Global clip", "separate_no_clip": "Separate, no clip"}
ARM4 = {"linear": "Linear", "curvature": "Curvature", "A": r"A ($\lambda{=}4$)", "S": r"S ($\times4$)"}
def star_id(x):
    """Star only identified contrasts that exclude zero; mark contrasts with an out-of-grid endpoint with a dagger."""
    if not x.identified:
        return r"$^{\dagger}$"
    return star(x)


rows = []
for opt in ["global_clip", "separate_no_clip"]:
    r = [OPT_TEX[opt]]
    for a in ["linear", "curvature", "A", "S"]:
        x = c4[(c4.optimizer == opt) & (c4.arm == a)].iloc[0]
        r.append(f"${num(x.w50)}$" + ("$^{\\dagger}$" if not x.in_grid else "") + f" ${iv(x.ci_low, x.ci_high)}$")
    for name in ["A-S", "A-curvature"]:
        x = k4[(k4.optimizer == opt) & (k4.contrast == name)].iloc[0]; r.append(f"${num(x.difference, True)}${star_id(x)} ${iv(x.ci_low, x.ci_high, True)}$")
    rows.append(r)
table(OUT / "lbf_table.tex",
      r"MAPPO on Level-Based Foraging (E4) at the pre-declared label $\theta=0.626$: crossings and paired contrasts. Ten seeds, ten mixture cells, 2M timesteps, 800 trajectories. A$-$S compares the gain-to-loss ratio at matched loss scale; A$-$curvature isolates the loss-branch multiplier. $^{\dagger}$: point estimate outside the sampled grid (the linear crossing under the global clip), so contrasts that use it are not identified. $^{\ast}$: identified contrast whose interval excludes zero. Threshold sensitivity is in Table~\ref{tab:lbf_theta}.",
      "tab:lbf", "@{}lcccccc@{}", r"Optimizer & Linear & Curvature & A & S & A$-$S & A$-$curvature", rows, size=r"\footnotesize")

ts = pd.read_csv(RES / "E4_theta_sensitivity.csv")
rows = []
for th in sorted(ts.theta.unique()):
    for opt in ["global_clip", "separate_no_clip"]:
        r = [f"{th:.3f}" if opt == "global_clip" else "", OPT_TEX[opt]]
        for q in ["A", "S", "A-S"]:
            x = ts[(ts.theta == th) & (ts.optimizer == opt) & (ts.quantity == q)].iloc[0]
            r.append(f"${num(x.estimate, q == 'A-S')}$ ${iv(x.ci_low, x.ci_high, q == 'A-S')}$")
        x = ts[(ts.theta == th) & (ts.optimizer == opt) & (ts.quantity == "A-S")].iloc[0]; r.append(f"${num(x.isotonic, True)}$")
        rows.append(r)
table(OUT / "lbf_theta.tex",
      r"E4 sensitivity to the collapse threshold $\theta$ (native team return) and to the estimator. The stored run labels used $\theta=0.5$ (deviation D4); the pre-declared $\theta=0.626$ is primary. Last column: difference of decreasing-isotonic crossings.",
      "tab:lbf_theta", "@{}llcccc@{}", r"$\theta$ & Optimizer & A & S & A$-$S (Firth) & A$-$S (isotonic)", rows, size=r"\footnotesize", pos="H")

oc1 = pd.read_csv(RES / "E1E2_loss_occupancy.csv"); oc4 = pd.read_csv(RES / "E4_loss_occupancy.csv")
wcols1 = [c for c in oc1.columns if c not in ("cell", "arm")]
rows = [[CELL_TEX[r.cell] if r.arm == "B" else "", r.arm] + [f"{getattr(r, '_' + str(i + 3)):.2f}" for i in range(len(wcols1))]
        for r in oc1[oc1.cell.isin(["global_clip/raw", "separate_no_clip/vecnormalize"]) & oc1.arm.isin(["B", "A", "S"])].itertuples()]
table(OUT / "loss_occupancy.tex",
      r"Fraction of training rewards on the loss branch ($x-z_0<0$, $z_0=-2.628$), by mixture weight, for the default and the fully decoupled E1 cells. The fraction depends on $w$ and on the learned policy; near the crossings both branches are active.",
      "tab:loss_occupancy", "@{}ll" + "r" * len(wcols1) + "@{}", "Cell & Arm & " + " & ".join(f"$w{{=}}{float(x):g}$" for x in wcols1), rows, size=r"\scriptsize", pos="H")
wcols4 = [c for c in oc4.columns if c not in ("optimizer_mode", "arm")]
rows = [[OPT_TEX[r.optimizer_mode] if r.arm == "A" else "", ARM4[r.arm]] + [f"{getattr(r, '_' + str(i + 3)):.3f}" for i in range(len(wcols4))]
        for r in oc4.itertuples()]
table(OUT / "lbf_occupancy.tex",
      r"E4 fraction of training rewards below zero (reached through the LOAD effort cost), by mixture weight. Under A, agents largely stop attempting loads.",
      "tab:lbf_occupancy", "@{}ll" + "r" * len(wcols4) + "@{}", "Optimizer & Arm & " + " & ".join(f"$w{{=}}{float(x):g}$" for x in wcols4), rows, size=r"\scriptsize", pos="H")

iso_rows = []
c1 = cr.assign(gap=(cr.w50 - cr.isotonic).abs()); iso_rows.append(["E1/E2 (20 fits)", f"{c1[c1.in_grid].gap.max():.3f}", f"{c1[c1.in_grid].gap.median():.3f}"])
h3 = h.assign(gap=(h.w50 - h.isotonic).abs()); iso_rows.append(["E3 (72 fits)", f"{h3.gap.max():.3f}", f"{h3.gap.median():.3f}"])
c4i = c4[c4.in_grid & np.isfinite(c4.isotonic)].assign(gap=lambda d: (d.w50 - d.isotonic).abs())
iso_rows.append([f"E4, $\\theta=0.626$ ({len(c4i)} in-grid fits)", f"{c4i.gap.max():.3f}", f"{c4i.gap.median():.3f}"])
table(OUT / "isotonic_agreement.tex",
      r"Agreement between Firth and decreasing-isotonic crossings for every in-grid fit. LBF collapse proportions are far from the logistic shape for some arms, which is why E4 shows the largest gaps; E4's A$-$S conclusion holds under both estimators (Table~\ref{tab:lbf_theta}).",
      "tab:isotonic", "@{}lrr@{}", r"Experiment & Max $|$Firth$-$isotonic$|$ & Median", iso_rows, pos="H")


# ---------------------------------------------------------------- E5 / E6
c5r = pd.read_csv(RES / "E5_crossings.csv"); k5 = pd.read_csv(RES / "E5_contrasts.csv")
rows = []
for a, lab in [("B", "B (curvature)"), ("A", r"A (losses $\times7$)"), ("S", r"S (both $\times7$)")]:
    r = [lab]
    for ck in PRIMARY:
        x = c5r[(c5r.arm == a) & (c5r.checkpoint == ck)].iloc[0]; r.append(f"${num(x.w50)}$ ${iv(x.ci_low, x.ci_high)}$")
    rows.append(r)
for name in ["A-S", "A-B", "S-B"]:
    r = [name.replace("-", "$-$")]
    for ck in PRIMARY:
        x = k5[(k5.checkpoint == ck) & (k5.contrast == name)].iloc[0]; r.append(f"${num(x.difference, True)}${star(x)} ${iv(x.ci_low, x.ci_high, True)}$")
    rows.append(r)
table(OUT / "e5_table.tex",
      r"Decoupled horizon cohort (E5): separate actor and critic optimizers without clipping and normalized rewards; arms B, A, S; the nine E3 cells; ten seeds; 270 trajectories to 3.6M. Crossings, then paired contrasts. $^{\ast}$: interval excludes zero.",
      "tab:e5", "@{}lcccc@{}", r"Arm or contrast & 300k & 900k & 1.8M & 3.6M", rows, size=r"\footnotesize")
c6r = pd.read_csv(RES / "E6_crossings.csv"); k6 = pd.read_csv(RES / "E6_contrasts.csv"); ur = pd.read_csv(RES / "E6_update_ratios.csv")
MODE_TEX = {"global_clip": "Global clip (default)", "groupwise_clip": "Per-group clip", "separate_no_clip": "No clip"}
rows = []
for mo in ["global_clip", "groupwise_clip", "separate_no_clip"]:
    r = [MODE_TEX[mo]]
    for name in ["S-B", "A-S"]:
        x = k6[(k6["mode"] == mo) & (k6.contrast == name)].iloc[0]; r.append(f"${num(x.difference, True)}${star(x)} ${iv(x.ci_low, x.ci_high, True)}$")
    for q in ["pu_applied_actor_grad_norm", "pu_actor_update_norm"]:
        x = ur[(ur["mode"] == mo) & (ur.ratio == "S/B") & (ur.quantity == q)].iloc[0]; r.append(f"${x.point:.3f}$ $[{x.ci_low:.3f},\\,{x.ci_high:.3f}]$")
    rows.append(r)
table(OUT / "e6_table.tex",
      r"Clipping isolation (E6): one Adam step with a global clip, actor and critic clipped separately, or no clipping; raw rewards; arms B, A, S on the E1 grid; ten seeds; 720 runs at 300k. Crossing contrasts, and seed-paired S/B ratios of the actor's applied (post-clip) gradient norm and of the norm of its actual parameter update. $^{\ast}$: interval excludes zero.",
      "tab:e6", "@{}lcccc@{}", r"Mode & S$-$B & A$-$S & Applied actor gradient S/B & Actor update S/B", rows, size=r"\footnotesize")

# ---------------------------------------------------------------- E7
k7, i7, g7 = (pd.read_csv(RES / f"E7_{n}.csv") for n in ["contrasts", "interactions", "diagnostics"])
PAIRS7 = ["S-B", "A-S", "A-M", "M-B", "A-B"]
MODE7 = {"plain": "Plain", "popart": "PopArt"}
rows = []
for mo in ["plain", "popart"]:
    rows.append([MODE7[mo]] + [f"${num(x.difference, True)}${star(x)} ${iv(x.ci_low, x.ci_high, True)}$"
                               for x in (k7[(k7["mode"] == mo) & (k7.contrast == n)].iloc[0] for n in PAIRS7)])
rows.append([r"PopArt$-$plain"] + [f"${num(x.change, True)}${star(x)} ${iv(x.ci_low, x.ci_high, True)}$"
                                          for x in (i7[i7.contrast == n].iloc[0] for n in PAIRS7[:3])] + ["", ""])
table(OUT / "e7_table.tex",
      r"Critic-target normalization and a moment-matched control (E7): separate actor and critic optimizers without clipping, raw rewards, the E1 grid, ten seeds, 300k. M is the affine map $a_w r_{\mathrm{B}}+b_w$ of B's reward with constants frozen to give A's E1 training-reward mean and SD. The plain-critic B, A and S runs are E1's. Crossing contrasts with paired 95\% seed-block intervals; the bottom row is the change in each contrast from the plain to the PopArt critic. $^{\ast}$: interval excludes zero.",
      "tab:e7", "@{}lccccc@{}", r"Critic & S$-$B & A$-$S & A$-$M & M$-$B & A$-$B", rows, size=r"\footnotesize")

# ---------------------------------------------------------------- E8
k8a, k8b, m8 = (pd.read_csv(RES / f) for f in ["E8A_contrasts.csv", "E8B_contrasts.csv", "E8A_matching.csv"])
cell8 = lambda x: f"${num(x.difference, True)}${star(x)} ${iv(x.ci_low, x.ci_high, True)}$"
rows = []
for mo in ["plain", "popart"]:
    rows.append([MODE7[mo]] + [cell8(k8a[(k8a["mode"] == mo) & (k8a.contrast == n)].iloc[0]) for n in ["A-M_on", "M_on-B", "M_on-M", "A-S"]])
pri = k8b[k8b.cohort.str.startswith("seeds")]; poo = k8b[k8b.cohort.str.startswith("pooled")]
rowsb = [[lab] + [cell8(f[f.quantity == q].iloc[0]) for q in ["plain S-B", "popart S-B", "d(S-B) popart - plain"]]
         for lab, f in [("Seeds 52--61 (primary)", pri), ("Seeds 42--61 (secondary)", poo)]]
body = "\n".join(" & ".join(stack(c) for c in r) + r" \\" for r in rows)
bodyb = "\n".join(" & ".join(stack(c) for c in r) + r" \\" for r in rowsb)
(OUT / "e8_table.tex").write_text(r"""\begin{table}[!htbp]
\caption{Online moment-matched control and fresh-seed replication (E8): separate optimizers without clipping, raw rewards, the E1 grid, 300k. Top: M$_{\mathrm{on}}$ is an affine map of B's reward whose constants are reset every rollout so that its training-reward mean and SD track A's under its own policy; A, B, S and the static control M are the E1 and E7 runs on the same seeds (42--51). Bottom: S$-$B with fresh seeds 52--61 (pre-declared primary) and pooled with E1/E7's seeds 42--51 (secondary), and its change from the plain to the PopArt critic. Paired 95\% seed-block intervals; $^{\ast}$: interval excludes zero.}
\label{tab:e8}
\centering\footnotesize
\begin{tabular}{@{}lcccc@{}}
\toprule
Critic & A$-$M$_{\mathrm{on}}$ & M$_{\mathrm{on}}-$B & M$_{\mathrm{on}}-$M & A$-$S \\
\midrule
""" + body + r"""
\midrule
Cohort & Plain S$-$B & PopArt S$-$B & Change, PopArt$-$plain & \\
\midrule
""" + bodyb + r"""
\bottomrule
\end{tabular}
\end{table}
""")

# ---------------------------------------------------------------- cell-count tables
def cell_header(cells_str):
    return [c.split(":")[0] for c in cells_str.split()]
g1 = cell_header(cr.iloc[0].cells)
rows = [[CELL_TEX[c] if a == "B" else "", a] + [c2.split(":")[1].split("/")[0] for c2 in cr[(cr.cell == c) & (cr.arm == a)].iloc[0].cells.split()]
        for c in CELLS for a in ["B", "A", "S", "R"]]
table(OUT / "factorial_cells.tex", r"E1/E2 observed collapsed runs out of ten seeds per mixture cell at 300k.", "tab:factorial_cells",
      "@{}ll" + "r" * len(g1) + "@{}", "Cell & Arm & " + " & ".join(f"$w{{=}}{x}$" for x in g1), rows, size=r"\scriptsize", pos="H")
g3 = cell_header(h.iloc[0].cells)
rows = [[COND_TEX[cond] if ck == PRIMARY[0] else "", BUD[ck]] + [c2.split(":")[1].split("/")[0] for c2 in h[(h.condition == cond) & (h.checkpoint == ck)].iloc[0].cells.split()]
        for cond in ["null", "curvature", "lambda7"] for ck in PRIMARY]
table(OUT / "horizon_cells.tex", r"E3 observed collapsed trajectories out of ten seeds per mixture cell at the four primary budgets. Full checkpoint records are in the archive.", "tab:horizon_cells",
      "@{}ll" + "r" * len(g3) + "@{}", "Condition & Budget & " + " & ".join(f"$w{{=}}{x}$" for x in g3), rows, size=r"\scriptsize", pos="H")
g4 = [c.split(":")[0] for c in c4.iloc[0].cells.split()]
rows = [[OPT_TEX[opt] if a == "linear" else "", ARM4[a]] + [c2.split(":")[1] for c2 in c4[(c4.optimizer == opt) & (c4.arm == a)].iloc[0].cells.split()]
        for opt in ["global_clip", "separate_no_clip"] for a in ["linear", "curvature", "A", "S"]]
table(OUT / "lbf_cells.tex", r"E4 observed collapsed runs out of ten seeds per mixture cell (2M timesteps).", "tab:lbf_cells",
      "@{}ll" + "r" * len(g4) + "@{}", "Optimizer & Arm & " + " & ".join(f"$w{{=}}{x}$" for x in g4), rows, size=r"\scriptsize", pos="H")

# ---------------------------------------------------------------- macros
def mac(name, v): return f"\\newcommand{{\\{name}}}{{{v}}}\n"
def cv(df, **kw):
    q = df
    for k, v in kw.items(): q = q[q[k] == v]
    x = q.iloc[0]; d = x.difference if "difference" in x else x.w50
    return f"${num(d, True)}$ ${iv(x.ci_low, x.ci_high, True)}$"
e1 = pd.read_csv(RES / "E1E2_diagnostics.csv")
m = ""
m += mac("VfourSymStd", cv(co, cell="global_clip/raw", contrast="S-B"))
m += mac("VfourAsymStd", cv(co, cell="global_clip/raw", contrast="A-S"))
m += mac("VfourAsymBoth", cv(co, cell="separate_no_clip/vecnormalize", contrast="A-S"))
m += mac("VfourSymBoth", cv(co, cell="separate_no_clip/vecnormalize", contrast="S-B"))
m += mac("VfourLossBoth", cv(co, cell="separate_no_clip/vecnormalize", contrast="A-B"))
m += mac("VfourAsymNorm", cv(co, cell="global_clip/vecnormalize", contrast="A-S"))
m += mac("VfourAsymSep", cv(co, cell="separate_no_clip/raw", contrast="A-S"))
m += mac("VfourSymSep", cv(co, cell="separate_no_clip/raw", contrast="S-B"))
m += mac("VfourSymNorm", cv(co, cell="global_clip/vecnormalize", contrast="S-B"))
m += mac("VfourSymEps", cv(co, cell="eps1e-8/raw", contrast="S-B"))
m += mac("VfourSymEpsChange", f"${num(it[(it.cell == 'eps1e-8/raw') & (it.contrast == 'S-B')].iloc[0].change_vs_standard, True)}$ ${iv(*it[(it.cell == 'eps1e-8/raw') & (it.contrast == 'S-B')].iloc[0][['ci_low', 'ci_high']], True)}$")
m += mac("VfourLBFAsymGlobal", cv(k4, optimizer="global_clip", contrast="A-S"))
m += mac("VfourLBFAsymSep", cv(k4, optimizer="separate_no_clip", contrast="A-S"))
m += mac("VfourHorizonEnd", cv(hc, checkpoint=3600000, contrast="lambda7-curvature"))
m += mac("VfourHorizonStart", cv(hc, checkpoint=300000, contrast="lambda7-curvature"))
bstd = cr[(cr.cell == "global_clip/raw") & (cr.arm == "B")].iloc[0]; bothers = cr[(cr.cell != "global_clip/raw") & (cr.arm == "B")].w50
m += mac("VfourBaselineStd", f"${num(bstd.w50)}$"); m += mac("VfourBaselineRange", f"${bothers.min():.2f}$--${bothers.max():.2f}$")
ps = e1[(e1.cell == "global_clip/raw")].set_index("arm")
m += mac("VfourAppliedActorB", f"{ps.loc['B'].mb_post_actor_grad_norm:.4f}"); m += mac("VfourAppliedActorS", f"{ps.loc['S'].mb_post_actor_grad_norm:.4f}")
m += mac("VfourCriticNormB", f"{ps.loc['B'].mb_critic_grad_norm:,.0f}"); m += mac("VfourCriticNormS", f"{ps.loc['S'].mb_critic_grad_norm:,.0f}")
lbf_share = d4[d4.optimizer_mode == "global_clip"].mb_actor_grad_energy_share
m += mac("VfourLBFActorShare", f"{lbf_share.min():.2f}--{lbf_share.max():.2f}")
xp = pd.read_csv(RES / "crossplatform.csv")
a, b = xp.iloc[0], xp.iloc[1]
m += mac("VfourAgreeControl", f"{a.agree}/{a.total} ({100 * a.agree / a.total:.1f}\\%)")
m += mac("VfourBitControl", f"{int(a.bit_identical_profit)}/{a.total}")
m += mac("VfourAgreeHorizon", f"{b.agree:,}/{b.total:,} ({100 * b.agree / b.total:.1f}\\%)")
cp = pd.read_csv(RES / "compute_v4.csv")
m += mac("VfourTrajectories", f"{cp.trajectories.sum():,}"); m += mac("VfourCoreHours", f"{cp.single_core_hours.sum():,.0f}")
DESC = {"E1": "Optimizer $\\times$ normalization factorial, 300k", "E2": "Adam-$\\epsilon$ addendum, 300k",
        "E3": "Refined horizon cohort to 3.6M", "E4": "MAPPO on LBF, 2M timesteps",
        "E5": "Decoupled horizon cohort to 3.6M", "E6": "Clipping isolation, 300k",
        "E7": "Critic-target normalization and moment control, 300k",
        "E8": "Online moment control; fresh-seed replication, 300k"}
table(OUT / "compute_table.tex",
      r"Measured v4 compute: completed Slurm array tasks, one CPU core each (single-thread PyTorch), summed elapsed time. Runs were executed at most eight concurrently.",
      "tab:compute_v4", "@{}llrrr@{}", r"ID & Experiment & Trajectories & Core-hours & Mean minutes per run",
      [[r.experiment, DESC[r.experiment], f"{r.trajectories:,}", f"{r.single_core_hours:,.1f}", f"{r.mean_minutes:.1f}"] for r in cp.itertuples()]
      + [["", "Total", f"{cp.trajectories.sum():,}", f"{cp.single_core_hours.sum():,.1f}", ""]], pos="H")
evd = pd.read_csv(RES / "E1E2_explained_variance.csv").set_index(["cell", "arm"]).explained_variance_last
m += mac("VfourEVSepRawB", f"{evd[('separate_no_clip/raw', 'B')]:.2f}"); m += mac("VfourEVSepRawS", f"{evd[('separate_no_clip/raw', 'S')]:.2f}")
m += mac("VfourEVNormB", f"{evd[('separate_no_clip/vecnormalize', 'B')]:.2f}"); m += mac("VfourEVNormS", f"{evd[('separate_no_clip/vecnormalize', 'S')]:.2f}")
m += mac("VfourLBFLossOnly", cv(k4, optimizer="separate_no_clip", contrast="A-curvature"))
m += mac("VfourLBFLossOnlyGlobal", cv(k4, optimizer="global_clip", contrast="A-curvature"))
m += mac("VfourIsoMaxSupply", f"{max(c1[c1.in_grid].gap.max(), h3.gap.max()):.3f}")
g5 = lambda ck, n: cv(k5, checkpoint=ck, contrast=n)
m += mac("VfiveAsymStart", g5(300000, "A-S")); m += mac("VfiveAsymEnd", g5(3600000, "A-S")); m += mac("VfiveSymEnd", g5(3600000, "S-B"))
m += mac("VfiveSymStart", g5(300000, "S-B"))
it6 = pd.read_csv(RES / "E6_interactions.csv")
m += mac("VsixSymGroup", cv(k6, mode="groupwise_clip", contrast="S-B")); m += mac("VsixAsymGroup", cv(k6, mode="groupwise_clip", contrast="A-S"))
x = it6[(it6["mode"] == "groupwise_clip") & (it6.contrast == "S-B")].iloc[0]
m += mac("VsixSymGroupChange", f"${num(x.change_vs_global, True)}$ ${iv(x.ci_low, x.ci_high, True)}$")
gr6 = lambda mo, q: ur[(ur["mode"] == mo) & (ur.ratio == "S/B") & (ur.quantity == q)].iloc[0]
m += mac("VsixUpdGlobal", f"{gr6('global_clip', 'pu_actor_update_norm').point:.2f}"); m += mac("VsixUpdGroup", f"{gr6('groupwise_clip', 'pu_actor_update_norm').point:.2f}")
m += mac("VsixUpdNone", f"{gr6('separate_no_clip', 'pu_actor_update_norm').point:.2f}"); m += mac("VsixGradGlobal", f"{gr6('global_clip', 'pu_applied_actor_grad_norm').point:.2f}")
rp = pd.read_csv(RES / "E6_reproduction.csv").iloc[0]; m += mac("VsixRepro", f"{rp.agree}/{rp.total}")
c7 = lambda mo, n: cv(k7, mode=mo, contrast=n)
for mo, tag in [("plain", "Plain"), ("popart", "Pop")]:
    for n, nm in [("S-B", "Sym"), ("A-S", "Asym"), ("A-M", "AM"), ("M-B", "MB"), ("A-B", "AB")]:
        m += mac(f"Vseven{nm}{tag}", c7(mo, n))
for n, nm in [("S-B", "Sym"), ("A-S", "Asym"), ("A-M", "AM")]:
    x = i7[i7.contrast == n].iloc[0]; m += mac(f"Vseven{nm}Change", f"${num(x.change, True)}$ ${iv(x.ci_low, x.ci_high, True)}$")
gd = g7.set_index(["mode", "arm"])
for mo, tag in [("plain", "Plain"), ("popart", "Pop")]:
    for a in "BAS":
        m += mac(f"VsevenEV{tag}{a}", f"{gd.loc[(mo, a)].explained_variance_last:.2f}")
    for a in "AM":
        m += mac(f"VsevenMean{tag}{a}", f"${gd.loc[(mo, a)].train_reward_mean:.1f}$"); m += mac(f"VsevenSD{tag}{a}", f"{gd.loc[(mo, a)].train_reward_sd:.1f}")
m += mac("VsevenSigmaRange", f"{g7[g7['mode'] == 'popart'].popart_sigma_final.min():.0f}--{g7[g7['mode'] == 'popart'].popart_sigma_final.max():.0f}")
g8 = lambda mo, n: k8a[(k8a["mode"] == mo) & (k8a.contrast == n)].iloc[0]
for mo, tag in [("plain", "Plain"), ("popart", "Pop")]:
    for n, nm in [("A-M_on", "AMon"), ("M_on-B", "MonB"), ("M_on-M", "MonM")]:
        x = g8(mo, n); m += mac(f"Veight{nm}{tag}", f"${num(x.difference, True)}$ ${iv(x.ci_low, x.ci_high, True)}$")
x = g8("plain", "A-M_on"); m += mac("VeightAMonPlainNine", f"${iv(x.ci_low_99, x.ci_high_99, True)}$")
mm = m8.set_index("mode")
for mo, tag in [("plain", "Plain"), ("popart", "Pop")]:
    m += mac(f"VeightMatchMean{tag}", f"{100 * mm.loc[mo].rel_mean:.0f}\\%"); m += mac(f"VeightMatchSd{tag}", f"{100 * mm.loc[mo].rel_sd:.0f}\\%")
    m += mac(f"VeightMonMean{tag}", f"${mm.loc[mo].Mon_mean:.1f}$"); m += mac(f"VeightMonSd{tag}", f"{mm.loc[mo].Mon_sd:.1f}")
q8 = lambda c, qn: k8b[k8b.cohort.str.startswith(c) & (k8b.quantity == qn)].iloc[0]
for c, ctag in [("seeds", "B"), ("pooled", "Pool")]:
    for qn, nm in [("plain S-B", "SymPlain"), ("popart S-B", "SymPop"), ("d(S-B) popart - plain", "Change")]:
        x = q8(c, qn); m += mac(f"Veight{ctag}{nm}", f"${num(x.difference, True)}$ ${iv(x.ci_low, x.ci_high, True)}$")
    x = q8(c, "d(S-B) popart - plain"); m += mac(f"Veight{ctag}ChangeNine", f"${iv(x.ci_low_99, x.ci_high_99, True)}$")
(OUT / "v4_numbers.tex").write_text(m)
print("wrote", sorted(p.name for p in OUT.iterdir()))
