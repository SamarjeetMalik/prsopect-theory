# Anonymous TMLR reproducibility artifact (v4)

This archive supports *Optimizer Coupling Masks Loss-Asymmetric Shifts in Finite-Budget Coordination-Collapse
Crossings*.

## Rebuild everything with one command
Create a Python environment compatible with `AAMAS2027/analysis/requirements.lock`, make sure `latexmk` is
available, and run from the archive root:

```bash
python TMLR2026/v4_prereg/analysis/rebuild_v4.py
```

The command runs four steps:
1. It re-analyses E1–E3 from the per-run tables (`phase3.py`).
2. It re-analyses E4 (`phase3_e4.py`).
3. It renders every v4 table, figure and macro into `TMLR2026/generated/v4/` (`render_v4.py`).
4. It runs the legacy rebuild (`AAMAS2027/analysis/rebuild_tmlr.py`), which re-analyses the legacy sweeps and
   compiles `TMLR2026/build/main.pdf`.

## What is here

### v4 experiments (E1–E4, one platform, pre-registered)
- **`TMLR2026/v4_prereg/`:**
  - `PREREGISTRATION_v4.md`: designs, predictions and interpretation rules, written before any outcome.
  - `HASHES.sha256`: source and design hashes frozen before launch; the E4 runner was frozen after its timing
    smoke.
  - `DEVIATIONS.md`: one pre-execution source fix.
  - `PHASE0_REPORT.md`: environment, tests, equality gate.
  - `RESULT.md`: pre-declared rules applied to the outcomes.
  - `results/`: every reported estimate, contrast, diagnostic, cross-platform comparison and the scheduler
    compute record (`compute_v4.csv`, an input, not recomputed).
  - `analysis/`: analysis, rendering and rebuild scripts.
- **`v4/runs/`:** one row per trajectory.
  - `E1_runs.csv` and `E2_runs.csv`: 1,280 + 320 at 300k.
  - `E3_checkpoints.csv`: 270 trajectories × 24 checkpoints.
  - `E4_runs.csv`: 800 LBF runs.

  Each row holds the run's protocol, collapse label, evaluation summary, per-minibatch gradient-norm means and
  reward moments.
- **`v4/executed_source/`:** the executed source.
  - `optimizer_factorial_source_v2/`: `optimizer_factorial.py` (E1), `eps_addendum.py` (E2), `e4_lbf.py` (E4),
    the instrumented PPO update, and the environment and reward wrappers.
  - `orchestration_v4_e3/`: E3 design and orchestrator, run on `executed_source/instrumented_source_v2`.
  - `optimizer_factorial_v2/`: the frozen factorial design and protocol.
- **`v4/extraction/`:** the scripts that reduced the raw run directories to `v4/runs/`.

Raw per-minibatch diagnostics and checkpoints (about 45 GB) are not included and are available on request.

**Path mapping.** `HASHES.sha256` lists paths in the authors' repository layout.
- `AAMAS2027/optimizer_factorial_source_v2/…` corresponds to `v4/executed_source/optimizer_factorial_source_v2/…`.
- `AAMAS2027/optimizer_factorial_v2/…` and `AAMAS2027/orchestration_v4_e3/…` likewise sit under
  `v4/executed_source/`.

Three hashed files were redacted for anonymity after the runs. `REDACTIONS.md` gives their original and
redacted hashes and the category of each substitution.

### Earlier material (carried over from v3)
- **`executed_source/instrumented_source_v2/`:** the hash-verified source for the earlier longitudinal
  confirmation and direct control.
- **`AAMAS2027/new_runs/deadline_confirmation_v1/`:** the earlier 150 longitudinal and 240 direct-control
  trajectories, used in v4 only for the cross-platform label comparison.
- **`AAMAS2027/new_runs/scale_calibration_*`:** the reference-point calibration records behind
  z₀ = −2.6281398333.
- **`docs/`:** audited per-run CSV records of the legacy supply-PPO sweeps (300k decomposition, cross-sectional
  horizons). Their original execution environment was not preserved.

## Integrity
`MANIFEST.sha256` lists every archived file and its SHA-256. Paths and records contain no author names,
institution, machine names or usernames.
