# Anonymous TMLR reproducibility artifact (v4)

This archive supports *Symmetric Reward Scaling Moves Finite-Budget Coordination-Collapse Crossings in Two PPO
Implementations with an Unnormalized Critic*.

## Rebuild everything with one command
Create a Python environment compatible with `AAMAS2027/analysis/requirements.lock`, make sure `latexmk` is
available, and run from the archive root:

```bash
python TMLR2026/v4_prereg/analysis/rebuild_v4.py
```

The command regenerates every analysis, table, figure and number, and the PDF, from the per-run tables in
`v4/runs/`. It does not retrain any policy; the executed source and frozen designs allow any run to be repeated.
It runs twenty-three steps:
1. It re-analyses E1–E3 (`phase3.py`).
2. It re-analyses E4 (`phase3_e4.py`).
3. It re-analyses E5 and E6 (`phase3_e5e6.py`).
4. It re-analyses E7 (`phase3_e7.py`).
5. It re-analyses E8 (`phase3_e8.py`).
6. It re-analyses E9–E12 (`phase3_e9_e12.py`).
7. It recomputes every E1–E12 interval as a seed-level jackknife-t interval (`jackknife_all.py`; revision, not
   pre-registered). It re-executes each frozen script above with its bootstrap weights replaced by leave-one-seed-out
   weights, and writes `TMLR2026/v4_prereg/results_jt/`, where `ci_*` holds the jackknife-t interval and `pct_*` the
   pre-declared percentile interval. The pre-declared outputs in `results/` are not changed. The manuscript reports
   the jackknife-t intervals.
8. It re-analyses X1 and X2 (`phase3_x1x2.py`).
9. It re-analyses X3 (`phase3_x3.py`).
10. It re-analyses X4 (`phase3_x4.py`).
11. It re-analyses X5 (`phase3_x5.py`).
12. It re-analyses X6, X7 and X8 (`phase3_x6_x8.py`).
13. It runs the exploratory X1+X3 pooled comparison (`explore_x13_pooled.py`; not pre-registered).
14. It builds the review figures and the leave-one-seed-out table (`review_figures.py`).
15. It runs the estimator checks (`stat_checks.py`, about four minutes): every principal contrast is re-derived from
   the per-run tables and asserted equal to the stored result; an independent 10,000-draw bootstrap; and a simulation
   of interval coverage at this design; and a Holm adjustment across the principal contrasts. These checks were
   added in revision and are not pre-registered.
16. It summarizes the E7 training-reward and critic-target distributions and checks the E4 per-episode returns
   (`dist_audit.py analyse`).
17. It checks the shared-clip formula (Eq. 2) on every logged minibatch of the default cell and E6 (`eq2_check.py`).
18. It computes the seed-level jackknife-t intervals and Holm adjustment for the principal contrasts and the
   between-condition changes (`jackknife_v5.py`).
19. It summarizes the calibration simulation from its per-replicate outputs in `v4/calibration/`
   (`calibration_summarize.py`), writing `TMLR2026/v4_prereg/results_v5/calibration_summary.csv` and
   `calibration_scenarios.csv` (see the note below on rerunning the simulation itself).
20. It builds the revision figures and tables (`revision_figures.py`).
21. It draws the six-panel mechanism figure (`mechanism_v5.py`).
22. It renders every v4 table, figure and macro into `TMLR2026/generated/v4/` (`render_v4.py`), and asserts
   that `jackknife_all.py` and `jackknife_v5.py` give the same interval wherever both compute one.
23. It runs the legacy rebuild (`AAMAS2027/analysis/rebuild_tmlr.py`), which re-analyses the legacy sweeps and
   compiles `TMLR2026/build/main.pdf`.

The interval-calibration study (`TMLR2026/v4_prereg/analysis/calibration_v5.py`, 27 scenarios × 10,000
replicates, about 7.4 single-core hours) is not re-run by the rebuild, which summarizes its archived per-replicate
outputs (step 19). `python TMLR2026/v4_prereg/analysis/calibration_v5.py N OUT_DIR` regenerates scenario N (0–26;
`--list` names them) into OUT_DIR; use a directory other than `v4/calibration/` to compare against the archived
outputs. The data-generating model and its assumptions are stated in the paper's Appendix B ("The simulation model")
and in the `scenarios` and `simulate` functions of that script. The study was added in revision and is not
pre-registered.

Label tests: `python -m pytest TMLR2026/v4_prereg/tests` (needs `pytest`). Every analysis checks or recomputes collapse labels
through `TMLR2026/v4_prereg/analysis/labels.py`, which asserts each declared threshold against the pre-registration
text, rejects undeclared thresholds and out-of-range inputs, and aborts if any stored supply-chain label disagrees
with the declared rule.

The included `tmlr.sty`, `tmlr.bst` and `fancyhdr.sty` are unmodified copies of the official TMLR template.

## What is here

### Pre-registered experiments E1–E12 and X1–X8 (one platform)

| ID | Experiment | Trajectories | Per-run table |
|---|---|---|---|
| E1 | optimizer × reward-normalization factorial, 300k | 1,280 | `v4/runs/E1_runs.csv` |
| E2 | Adam-ε addendum, 300k | 320 | `v4/runs/E2_runs.csv` |
| E3 | refined horizon cohort (default optimizer), 3.6M × 24 checkpoints | 270 | `v4/runs/E3_checkpoints.csv` |
| E4 | MAPPO on Level-Based Foraging, 2M | 800 | `v4/runs/E4_runs.csv` |
| E5 | decoupled horizon cohort (separate optimizers + reward normalization), 3.6M × 24 | 270 | `v4/runs/E5_checkpoints.csv` |
| E6 | clipping isolation with parameter-update logging, 300k | 720 | `v4/runs/E6_runs.csv` |
| E7 | critic-target normalization (plain vs PopArt critic) and moment-matched control arm M, 300k | 400 | `v4/runs/E7_runs.csv` |
| E8 | online moment-matched control M_on (both critics); B and S on fresh seeds 52–61 (both critics), 300k | 480 | `v4/runs/E8_runs.csv` |
| E9 | clip-threshold dose-response (default learner, τ ∈ {300, 3000, 10⁴, 3·10⁴}; B, S), 300k | 640 | `v4/runs/E9E10_runs.csv` |
| E10 | critic-target replication (plain vs PopArt; B, S) on fresh seeds 62–81, 300k | 640 | `v4/runs/E9E10_runs.csv` |
| E11 | second PPO implementation (CleanRL-style port; raw, per-group clip, reward normalization; B, A, S), 300k | 720 | `v4/runs/E11_runs.csv` |
| E12 | local observations with agent identity (default and decoupled learners; B, A, S), 300k | 480 | `v4/runs/E12_runs.csv` |
| X1 | fresh-seed replication of E6's clipping modes with Adam-moment logging (B, S; seeds 82–101), 300k | 960 | `v4/runs/X1_runs.csv` |
| X2 | fresh-seed replication of E11's raw and per-group modes (B, S; seeds 82–101), 300k | 640 | `v4/runs/X2_runs.csv` |
| X3 | actor-clipped × critic-clipped factorial, one Adam step (B, S; seeds 102–121), 300k | 1,280 | `v4/runs/X3_runs.csv` |
| X4 | critic target scale and fit: plain vs PopArt critic vs output fixed-scaled to the reward multiplier, advantage-quality logging against an out-of-sample Monte-Carlo reference critic (B, S; seeds 122–161), 300k | 1,920 | `v4/runs/X4_runs.csv` |
| X5 | decentralized execution: one actor network per node on its local view and identifier, centralized critic; X4's three critics and logging (B, S; seeds 162–201), 300k | 1,920 | `v4/runs/X5_runs.csv` |
| X6 | local critics: one actor and one critic per node on its local view and identifier, separate Adam, no clip; plain vs fixed-scale head (B, S; seeds 202–241), 300k | 1,280 | `v4/runs/X6_runs.csv` |
| X7 | shared clip under decentralized execution: X5's architecture, one Adam; plain vs normalized-loss head vs normalized-loss PopArt vs per-group clip (B, S; seeds 242–281), 300k | 2,560 | `v4/runs/X7_runs.csv` |
| X8 | critic fit at fixed target scale: X4's controller, no clip; B with critic learning rate × 1/8 (B, S, Bdeg; seeds 282–321), 300k | 960 | `v4/runs/X8_runs.csv` |

Two audit tables, added in revision, are reduced from the raw run directories by `v4/extraction/audit_dist_e4.py`
followed by `dist_audit.py reduce`. The intermediate per-rollout file (45 MB) is not archived.
- `v4/runs/E7_reward_distributions.csv`: per-run averages of per-rollout training-reward and critic-target statistics
  for E7 and the reused E1 arms.
- `v4/runs/E4_label_audit.csv`: E4 per-episode native team returns with the stored mean and label.
- `v4/runs/E1E6_eq2_minibatch.csv`: per-run summaries of every logged minibatch's pre-clip actor, critic and total
  gradient norms and post-clip actor norm, for E1's default cell (B, S) and all E6 runs
  (`v4/extraction/eq2_minibatch.py`).

- **Per-run tables.** Each row holds the run's protocol, collapse label, evaluation summary, per-minibatch
  gradient-norm means, reward moments and, for E6, parameter-update norms.
  `E7_runs.csv` also holds the PopArt rescale record (final σ and μ, largest output drift) and, for arm M,
  the achieved training-reward moments. E7's 240 plain-critic B, A and S cells are E1 runs, reused under the
  pre-launch gate, and are read from `E1_runs.csv`.
- **`TMLR2026/v4_prereg/`:**
  - `PREREGISTRATION_v4.md` (E1–E4), `PREREGISTRATION_E5.md`, `PREREGISTRATION_E6.md`, `PREREGISTRATION_E7.md`, `PREREGISTRATION_E8.md`,
    `PREREGISTRATION_E9_E10.md`, `PREREGISTRATION_E11_E12.md`, `PREREGISTRATION_X1_X2.md`, `PREREGISTRATION_X3.md`, `PREREGISTRATION_X4.md`, `PREREGISTRATION_X5.md`, `PREREGISTRATION_X6_X8.md`:
    designs, predictions and interpretation rules, each written before its experiment's outcomes.
  - `HASHES.sha256`: source and design hashes frozen before each launch.
  - `DEVIATIONS.md`: every departure, including D4, the E4 labels recomputed at the declared threshold.
  - `PHASE0_REPORT.md`: environment, tests, equality gates.
  - `PREREGISTRATION_E8.md`: E8's design and predictions, frozen before its gate (runner `e8_online_moments.py`,
    `e8_design.json`, `e8_targets.json`).
  - `tests/`: label-generation tests.
  - `RESULT.md`: pre-declared rules applied to E1–E12 and X1–X8. For E7–E12 and X1–X8 they are applied, prediction
    by prediction, in `results/phase3_e7_report.txt`, `results/phase3_e8_report.txt`, `results/phase3_e9_e12_report.txt`,
    `results/phase3_x1x2_report.txt`, `results/phase3_x3_report.txt`, `results/phase3_x4_report.txt` and `results/phase3_x5_report.txt`.
  - `results/`: every reported estimate, contrast, diagnostic, cross-platform comparison and compute record.
  - `results_jt/`: the same E1–E12 tables with jackknife-t intervals (`ci_*`), the reported interval, and the
    pre-declared percentile intervals (`pct_*`).
    `compute_v4.csv` comes from the scheduler; it is an input and is not recomputed.
  - `analysis/`: analysis, rendering and rebuild scripts.
- **`v4/executed_source/`:** the executed source.
  - `optimizer_factorial_source_v2/AAMAS2027/experiments/` holds `optimizer_factorial.py` (E1),
    `eps_addendum.py` (E2), `e4_lbf.py` (E4), `e5_decoupled_horizon.py` (E5), `e6_clip_isolation.py` (E6) and
    `e7_critic_scale.py` with `e7_design.json` (E7) and
    `e8_online_moments.py` with `e8_design.json` and `e8_targets.json` (E8),
    `e9_e10_runner.py` with `e9_e10_design.json` (E9, E10), `e11_cleanrl.py` with `e11_design.json` (E11) and
    `e12_localobs.py` with `e12_design.json` (E12), `x1_x2_runner.py` with `x1_x2_design.json` (X1, X2) and
    `x3_runner.py` with `x3_design.json` (X3), `x4_runner.py` with `x4_design.json` (X4), `x5_runner.py` with `x5_design.json` (X5), `x6_x8_runner.py` with `x6_x8_design.json` (X6–X8), plus the instrumented PPO update and the environment and reward wrappers.
  - `orchestration_v4_e3/` holds the E3 design and orchestrator, run on `executed_source/instrumented_source_v2`.
  - `optimizer_factorial_v2/` holds the frozen factorial design and protocol.
- **`v4/calibration/`:** the calibration simulation's per-replicate outputs, one `cal_NN.csv.gz` (10,000
  replicates) and one `cal_NN.json` (scenario parameters, true crossings, settings) per scenario.
- **`v4/extraction/`:** the scripts that reduced the raw run directories to `v4/runs/`.

Raw per-minibatch diagnostics and checkpoints (tens of GB) are not included and are available on request.

**Path mapping.** `HASHES.sha256` lists paths in the authors' repository layout.
- `AAMAS2027/optimizer_factorial_source_v2/…` corresponds to `v4/executed_source/optimizer_factorial_source_v2/…`.
- `AAMAS2027/optimizer_factorial_v2/…` and `AAMAS2027/orchestration_v4_e3/…` likewise sit under
  `v4/executed_source/`.

Files that had identifying strings redacted after the runs are listed in `REDACTIONS.md`, with original and
redacted hashes.

### Earlier material (carried over from v3)
- **`executed_source/instrumented_source_v2/`:** hash-verified source for the earlier longitudinal confirmation
  and direct control.
- **`AAMAS2027/new_runs/deadline_confirmation_v1/`:** the earlier 150 longitudinal and 240 direct-control
  trajectories, used in v4 only for the cross-platform label comparison.
- **`AAMAS2027/new_runs/scale_calibration_*`:** the reference-point calibration records behind
  z₀ = −2.6281398333.
- **`docs/`:** audited per-run CSV records of the legacy supply-PPO sweeps. Their original execution environment
  was not preserved.

## Integrity
`MANIFEST.sha256` lists every archived file and its SHA-256. Paths and records contain no author names,
institution, machine names or usernames.
