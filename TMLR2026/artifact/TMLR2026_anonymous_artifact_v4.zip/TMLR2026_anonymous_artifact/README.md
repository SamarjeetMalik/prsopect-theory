# Anonymous TMLR reproducibility artifact (v4)

This archive supports *Shared Gradient Clipping Alters the Effects of Reward Scaling on Finite-Budget
Coordination-Collapse Crossings in PPO*.

## Rebuild everything with one command
Create a Python environment compatible with `AAMAS2027/analysis/requirements.lock`, make sure `latexmk` is
available, and run from the archive root:

```bash
python TMLR2026/v4_prereg/analysis/rebuild_v4.py
```

The command regenerates every analysis, table, figure and number, and the PDF, from the per-run tables in
`v4/runs/`. It does not retrain any policy; the executed source and frozen designs allow any run to be repeated.
It runs nine steps:
1. It re-analyses E1–E3 (`phase3.py`).
2. It re-analyses E4 (`phase3_e4.py`).
3. It re-analyses E5 and E6 (`phase3_e5e6.py`).
4. It re-analyses E7 (`phase3_e7.py`).
5. It builds the review figures and the leave-one-seed-out table (`review_figures.py`).
6. It runs the estimator checks (`stat_checks.py`, about four minutes): every principal contrast is re-derived from
   the per-run tables and asserted equal to the stored result; an independent 10,000-draw bootstrap; and a simulation
   of interval coverage at this design. These checks were added in revision and are not pre-registered.
7. It builds the revision figures and tables (`revision_figures.py`).
8. It renders every v4 table, figure and macro into `TMLR2026/generated/v4/` (`render_v4.py`).
9. It runs the legacy rebuild (`AAMAS2027/analysis/rebuild_tmlr.py`), which re-analyses the legacy sweeps and
   compiles `TMLR2026/build/main.pdf`.

Label tests: `python -m pytest TMLR2026/v4_prereg/tests` (needs `pytest`). Every analysis checks or recomputes collapse labels
through `TMLR2026/v4_prereg/analysis/labels.py`, which asserts each declared threshold against the pre-registration
text, rejects undeclared thresholds and out-of-range inputs, and aborts if any stored supply-chain label disagrees
with the declared rule.

The included `tmlr.sty`, `tmlr.bst` and `fancyhdr.sty` are unmodified copies of the official TMLR template.

## What is here

### Pre-registered experiments E1–E7 (one platform)

| ID | Experiment | Trajectories | Per-run table |
|---|---|---|---|
| E1 | optimizer × reward-normalization factorial, 300k | 1,280 | `v4/runs/E1_runs.csv` |
| E2 | Adam-ε addendum, 300k | 320 | `v4/runs/E2_runs.csv` |
| E3 | refined horizon cohort (default optimizer), 3.6M × 24 checkpoints | 270 | `v4/runs/E3_checkpoints.csv` |
| E4 | MAPPO on Level-Based Foraging, 2M | 800 | `v4/runs/E4_runs.csv` |
| E5 | decoupled horizon cohort (separate optimizers + reward normalization), 3.6M × 24 | 270 | `v4/runs/E5_checkpoints.csv` |
| E6 | clipping isolation with parameter-update logging, 300k | 720 | `v4/runs/E6_runs.csv` |
| E7 | critic-target normalization (plain vs PopArt critic) and moment-matched control arm M, 300k | 400 | `v4/runs/E7_runs.csv` |

- **Per-run tables.** Each row holds the run's protocol, collapse label, evaluation summary, per-minibatch
  gradient-norm means, reward moments and, for E6, parameter-update norms.
  `E7_runs.csv` also holds the PopArt rescale record (final σ and μ, largest output drift) and, for arm M,
  the achieved training-reward moments. E7's 240 plain-critic B, A and S cells are E1 runs, reused under the
  pre-launch gate, and are read from `E1_runs.csv`.
- **`TMLR2026/v4_prereg/`:**
  - `PREREGISTRATION_v4.md` (E1–E4), `PREREGISTRATION_E5.md`, `PREREGISTRATION_E6.md`, `PREREGISTRATION_E7.md`:
    designs, predictions and interpretation rules, each written before its experiment's outcomes.
  - `HASHES.sha256`: source and design hashes frozen before each launch.
  - `DEVIATIONS.md`: every departure, including D4, the E4 labels recomputed at the declared threshold.
  - `PHASE0_REPORT.md`: environment, tests, equality gates.
  - `PREREGISTRATION_E8.md`: an outstanding experiment (online moment-matched control; independent-seed
    replication of E7 P1), drafted with its runner (`e8_online_moments.py`, `e8_design.json`), extraction and
    analysis scripts. **It has not been run, and no result from it appears in the paper.**
  - `tests/`: label-generation tests.
  - `RESULT.md`: pre-declared rules applied to E1–E6. For E7 they are applied, prediction by prediction, in
    `results/phase3_e7_report.txt`.
  - `results/`: every reported estimate, contrast, diagnostic, cross-platform comparison and compute record.
    `compute_v4.csv` comes from the scheduler; it is an input and is not recomputed.
  - `analysis/`: analysis, rendering and rebuild scripts.
- **`v4/executed_source/`:** the executed source.
  - `optimizer_factorial_source_v2/AAMAS2027/experiments/` holds `optimizer_factorial.py` (E1),
    `eps_addendum.py` (E2), `e4_lbf.py` (E4), `e5_decoupled_horizon.py` (E5), `e6_clip_isolation.py` (E6) and
    `e7_critic_scale.py` with `e7_design.json` (E7), plus the instrumented PPO update and the environment and reward wrappers.
  - `orchestration_v4_e3/` holds the E3 design and orchestrator, run on `executed_source/instrumented_source_v2`.
  - `optimizer_factorial_v2/` holds the frozen factorial design and protocol.
- **`v4/extraction/`:** the scripts that reduced the raw run directories to `v4/runs/`.

Raw per-minibatch diagnostics and checkpoints (tens of GB) are not included and are available on request.

**Path mapping.** `HASHES.sha256` lists paths in the authors' repository layout.
- `AAMAS2027/optimizer_factorial_source_v2/…` corresponds to `v4/executed_source/optimizer_factorial_source_v2/…`.
- `AAMAS2027/optimizer_factorial_v2/…` and `AAMAS2027/orchestration_v4_e3/…` likewise sit under
  `v4/executed_source/`.

Files that had identifying strings redacted after the runs are listed in `REDACTIONS.md`, with original and
redacted hashes.

### Earlier material (carried over from v3)
- **`executed_source/instrumented_source_v2/`:** hash-verified source for the earlier longitudinal confirmation
  and direct control.
- **`AAMAS2027/new_runs/deadline_confirmation_v1/`:** the earlier 150 longitudinal and 240 direct-control
  trajectories, used in v4 only for the cross-platform label comparison.
- **`AAMAS2027/new_runs/scale_calibration_*`:** the reference-point calibration records behind
  z₀ = −2.6281398333.
- **`docs/`:** audited per-run CSV records of the legacy supply-PPO sweeps. Their original execution environment
  was not preserved.

## Integrity
`MANIFEST.sha256` lists every archived file and its SHA-256. Paths and records contain no author names,
institution, machine names or usernames.
